import { BlockData, Log } from "@subsquid/evm-processor";
import { BaseEventData, DutchCreationData, EVM } from "../types";
import * as dutchFactory from "../abi/dutch-factory";
import { LiquidityDetails } from "../model";

export const processDutchAuctionFactory = (
  log: Log,
  baseEventData: BaseEventData,
  blocks: BlockData[]
) => {
  const _topic = log.topics[0];
  const { DutchAuctionCreated } = dutchFactory.events;

  if (_topic === DutchAuctionCreated.topic) {
    const {
      id,
      dutchAuction,
      info: {
        startTime,
        endTime,
        startPrice,
        endPrice,
        finalizeTime,
        maxBuyLimit,
        publicSaleTime,
        softCap,
        hardCap,
        minBuyLimit,
        totalSaleAmount,
        token,
        decreaseInterval,
      },
      liq: { router, liquidityPercent, lockTime, locker, liquidityAdded },
      refundType
    } = DutchAuctionCreated.decode(log);

    // Vesting Details: done it this way becuse contract writer forget to give event name.
    const { TGEPercent, cycleInterval, cyclePercent, isVestingEnable } =
      DutchAuctionCreated.decode(log)[2];


    let fundToken: string = "";

    if ((log as unknown as EVM).transaction.input) {
      const { _fundToken } = dutchFactory.functions.createDutchAuction.decode(
        (log as unknown as EVM).transaction.input
      );
      fundToken = _fundToken;

    } else {
      const txBlock = blocks.find((x) => x.transactions.length > 0)!;
      fundToken = (txBlock.transactions as EVM["transaction"][]).find(
        (x) => x.input
      )?.input!;
    }

    const data: DutchCreationData = {
      ...baseEventData,
      type: "DutchAuctionCreated",
      item: {
        id: id.toString(),
        name: "DutchAuction",
        contractAddress: dutchAuction.toLowerCase(),
        owner: log.transaction?.from!,
        token,
        softCap,
        hardCap,
        startPrice,
        endPrice,
        startTime,
        endTime,
        isCancelled: false,
        refundType,
        investors: [],
        minBuyLimit,
        fundTokenAddress: fundToken,
        maxBuyLimit,
        investedAmount: 0n,
        totalSaleAmount,
        decreaseInterval,
        router,
        liquidityPercent,
        lockTime,
        locker,
        liquidityAdded,
        finalizeTime,
        publicSaleTime,
        TGEPercent,
        cycleInterval,
        cyclePercent,
        isVestingEnable,
      },
    };

    return data;
  }

  return null as never;
};
