import { BlockData, Log, Transaction } from "@subsquid/evm-processor";
import * as dutch from "../abi/dutch";
import * as fairlaunch from "../abi/fairlaunch";
import * as launchpad from "../abi/launchpad";
import * as launchpadFactory from "../abi/launchpad-factory";
import * as subscription from "../abi/subscription";
import {
  BaseEventData,
  EVM,
  LaunchpadCreationData,
  PoolCancelledLaunchpads,
  PoolFinalizedLaunchpads,
  TokenPurchasedDutch,
  TokenPurchasedFairlaunch,
  TokenPurchasedLaunchpad,
  TokenPurchasedSubscription,
} from "../types";
import { EntityManager } from "../utils/entityManager";
import { Block } from "../processor";

export const processLaunchpadFactory = (
  log: Log,
  baseEventData: BaseEventData,
  blocks: BlockData[]
) => {
  const { LaunchpadCreated } = launchpadFactory.events;

  if (log.topics[0] === LaunchpadCreated.topic.toLowerCase()) {
    const {
      info: {
        startTime,
        endTime,
        publicSaleTime,
        sellPrice,
        finalizeTime,
        listingPrice,
        softCap,
        hardCap,
        minBuyLimit,
        maxBuyLimit,
        token,
      },
      liq: {
        isAutolisting,
        locker,
        lockTime,
        liquidityAdded,
        liquidityPercent,
        router,
      },
      vesting: { TGEPercent, cycleInterval, cyclePercent, isVestingEnable },
      launchpad: launchpadAddress,
      id, refundType
    } = launchpadFactory.events.LaunchpadCreated.decode(log);

    let fundToken: string = "";
    if ((log as unknown as EVM).transaction.input) {
      const { _fundToken } =
        launchpadFactory.functions.createLaunchpad.decode(
          (log as unknown as EVM).transaction.input
        );
      fundToken = _fundToken;
    } else {
      const txBlock = blocks.find((x) => x.transactions.length > 0)!;
      fundToken = (txBlock.transactions as EVM["transaction"][]).find(
        (x) => x.input
      )?.input!;
    }

    const data: LaunchpadCreationData = {
      ...baseEventData,
      type: "LaunchpadCreated",
      item: {
        id: id.toString(),
        owner: log.transaction?.from!,
        token,
        name: "LaunchPad",
        isAffiliate: false,
        sellPrice: sellPrice,
        listingPrice: listingPrice,
        investedAmount: 0n,
        refundType,
        softCap: softCap,
        hardCap: hardCap,
        investors: [],
        minBuyLimit: minBuyLimit,
        maxBuyLimit: maxBuyLimit,
        startTime: startTime,
        endTime: endTime,
        isCancelled: false,
        finalizeTime: finalizeTime,
        publicSaleTime: publicSaleTime,
        router: router,
        fundTokenAddress: fundToken,
        liquidityPercent: liquidityPercent,
        lockTime: lockTime,
        locker: locker,
        liquidityAdded: liquidityAdded,
        isAutoListing: isAutolisting,
        isVestingEnable: isVestingEnable,
        tgePercent: TGEPercent,
        cyclePercent: cyclePercent,
        cycleInterval: cycleInterval,
        contractAddress: launchpadAddress.toLowerCase(),
      },
    };

    return data;
  }

  return null as never;
};

export const processLaunchpadsContract = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const _topic = log.topics[0];
  const {
    Purchased: launchpadPurchased,
    Finalized: launchpadFinalized,
    Cancelled: launchpadCancelled,
  } = launchpad.events;
  const {
    Purchased: fairlaunchPurchased,
    Finalized: fairlaunchFinalized,
    Cancelled: FairlaunchCancelled,
  } = fairlaunch.events;
  const {
    Purchased: subscriptionPurchased,
    Finalized: subscriptionFinalized,
    Cancelled: subscriptionCancelled,
  } = subscription.events;
  const {
    Purchased: dutchPurchased,
    Finalized: dutchFinalized,
    Cancelled: dutchCancelled,
  } = dutch.events;

  // Purchased
  if (_topic === launchpadPurchased.topic) {
    return processPurchasedLaunchpad(log, em, baseEventData);
  }

  if (_topic === fairlaunchPurchased.topic) {
    return processPurchasedFairlaunch(log, em, baseEventData);
  }
  if (_topic === subscriptionPurchased.topic) {
    return processPurchasedSubscription(log, em, baseEventData);
  }
  if (_topic === dutchPurchased.topic) {
    return processPurchasedDutch(log, em, baseEventData);
  }

  // Finalized
  if (_topic === launchpadFinalized.topic) {
    return processFinalizedLaunchpad(log, em, baseEventData);
  }

  if (_topic === fairlaunchFinalized.topic) {
    return processFinalizedFairlaunch(log, em, baseEventData);
  }

  if (_topic === subscriptionFinalized.topic) {
    return processFinalizedSubscription(log, em, baseEventData);
  }

  if (_topic === dutchFinalized.topic) {
    return processFinalizedDutch(log, em, baseEventData);
  }

  // Cancelled
  if (_topic === launchpadCancelled.topic) {
    return processCancelledLaunchpad(log, em, baseEventData);
  }
  if (_topic === FairlaunchCancelled.topic) {
    return processCancelledFairlaunch(log, em, baseEventData);
  }
  if (_topic === dutchCancelled.topic) {
    return processCancelledDutchAuction(log, em, baseEventData);
  }
  if (_topic === subscriptionCancelled.topic) {
    return processCancelledSubscriptionPool(log, em, baseEventData);
  }

  return null as never;
};

export const processCancelledLaunchpad = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { id, status, time } = launchpad.events.Cancelled.decode(log);
  const data: PoolCancelledLaunchpads = {
    ...baseEventData,
    type: "PoolCancelledLaunchpad",
    item: {
      id: id.toString(),
      status,
      token: "",
    },
  };

  return data;
};

export const processCancelledFairlaunch = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, status } = fairlaunch.events.Cancelled.decode(log);
  const data: PoolCancelledLaunchpads = {
    ...baseEventData,
    type: "PoolCancelledLaunchpad",
    item: {
      id: Id.toString(),
      status,
      token: "",
    },
  };

  return data;
};

export const processCancelledDutchAuction = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { id, status, time } = dutch.events.Cancelled.decode(log);
  const data: PoolCancelledLaunchpads = {
    ...baseEventData,
    type: "PoolCancelledLaunchpad",
    item: {
      id: id.toString(),
      status,
      token: "",
    },
  };

  return data;
};

export const processCancelledSubscriptionPool = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, status } = subscription.events.Cancelled.decode(log);
  const data: PoolCancelledLaunchpads = {
    ...baseEventData,
    type: "PoolCancelledLaunchpad",
    item: {
      id: Id.toString(),
      status,
      token: "",
    },
  };

  return data;
};

export const processFinalizedLaunchpad = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, finzlizeTime, status } = launchpad.events.Finalized.decode(log);

  const data: PoolFinalizedLaunchpads = {
    ...baseEventData,
    type: "PoolFinalizedLaunchpad",
    item: {
      name: "LaunchPad",
      id: Id.toString(),
      status,
      finalizeTime: finzlizeTime,
      token: "",
    },
  };

  return data;
};
export const processFinalizedFairlaunch = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, finzlizeTime, status } = fairlaunch.events.Finalized.decode(log);

  const data: PoolFinalizedLaunchpads = {
    ...baseEventData,
    type: "PoolFinalizedLaunchpad",
    item: {
      name: "LaunchPad",
      id: Id.toString(),
      status,
      finalizeTime: finzlizeTime,
      token: "",
    },
  };

  return data;
};
export const processFinalizedSubscription = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, finzlizeTime, status } =
    subscription.events.Finalized.decode(log);

  const data: PoolFinalizedLaunchpads = {
    ...baseEventData,
    type: "PoolFinalizedLaunchpad",
    item: {
      name: "LaunchPad",
      id: Id.toString(),
      status,
      finalizeTime: finzlizeTime,
      token: "",
    },
  };

  return data;
};
export const processFinalizedDutch = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, finzlizeTime, status } = dutch.events.Finalized.decode(log);

  const data: PoolFinalizedLaunchpads = {
    ...baseEventData,
    type: "PoolFinalizedLaunchpad",
    item: {
      name: "LaunchPad",
      id: Id.toString(),
      status,
      finalizeTime: finzlizeTime,
      token: "",
    },
  };

  return data;
};

export const processPurchasedLaunchpad = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, sender, _amount, amount } =
    launchpad.events.Purchased.decode(log);

  console.log({ Id, sender, _amount, amount });

  const data: TokenPurchasedLaunchpad = {
    ...baseEventData,
    type: "TokenPurchasedLaunchpad",
    item: {
      name: "LaunchPad",
      id: Id.toString(),
      tokenAmount: _amount,
      currencyAmount: amount,
      owner: sender,
      token: "",
    },
  };

  return data;
};

export const processPurchasedFairlaunch = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { id, sender, _amount } = fairlaunch.events.Purchased.decode(log);

  const data: TokenPurchasedFairlaunch = {
    ...baseEventData,
    type: "TokenPurchasedFairlaunch",
    item: {
      name: "Fairlaunch",
      id: id.toString(),
      currencyAmount: _amount,
      owner: sender,
      token: "",
    },
  };

  return data;
};

export const processPurchasedSubscription = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { Id, sender, _amount } = subscription.events.Purchased.decode(log);

  const data: TokenPurchasedSubscription = {
    ...baseEventData,
    type: "TokenPurchasedSubscription",
    item: {
      name: "SubscriptionPool",
      id: Id.toString(),
      currencyAmount: _amount,
      owner: sender,
      token: "",
    },
  };

  return data;
};

export const processPurchasedDutch = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
) => {
  const { id, amount, sender, _amount } = dutch.events.Purchased.decode(log);

  const data: TokenPurchasedDutch = {
    ...baseEventData,
    type: "TokenPurchasedDutch",
    item: {
      name: "DutchAuction",
      id: id.toString(),
      tokenAmount: amount,
      currencyAmount: _amount,
      owner: sender,
      token: "",
    },
  };

  return data;
};
