import { Log } from "@subsquid/evm-processor";
import { EntityManager } from "../utils/entityManager";
import {
  BaseEventData,
  PrivateSaleCancelled,
  PrivateSaleFundsDeposited,
  PrivateSaleWhitelistAdded,
  PrivateSaleWhitelistRemoved,
} from "../types";
import * as privateSale from "../abi/private-sale";
import { PrivateSale } from "../model";

export const processPrivateSaleContract = async (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): Promise<
  | PrivateSaleWhitelistAdded
  | PrivateSaleWhitelistRemoved
  | PrivateSaleFundsDeposited
  | PrivateSaleCancelled
> => {
  const _topic = log.topics[0];
  const { WhitelistAdded, WhitelistRemoved, FundsDeposited, Cancelled } =
    privateSale.events;

  if (_topic === WhitelistAdded.topic) {
    return await processWhitelistAdded(log, em, baseEventData);
  }

  if (_topic === WhitelistRemoved.topic) {
    return await processWhitelistRemoved(log, em, baseEventData);
  }

  if (_topic === FundsDeposited.topic) {
    return await processFundedDeposited(log, em, baseEventData);
  }

  if (_topic === Cancelled.topic) {
    return await processSaleCancelled(log, em, baseEventData);
  }

  return null as never;
};

const processSaleCancelled = async (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): Promise<PrivateSaleCancelled> => {
  const ps = await em.get(PrivateSale, log.address);
  if (!ps) return null as never;

  const { Id, status } = privateSale.events.Cancelled.decode(log);

  const data: PrivateSaleCancelled = {
    ...baseEventData,
    type: "PrivateSaleCancelled",
    item: {
      id: ps.id,
      status,
    },
  };

  return data;
};

const processFundedDeposited = async (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): Promise<PrivateSaleFundsDeposited> => {
  const ps = await em.get(PrivateSale, log.address);
  if (!ps) return null as never;

  const { sender, amount, Id } = privateSale.events.FundsDeposited.decode(log);

  const data: PrivateSaleFundsDeposited = {
    ...baseEventData,
    type: "PrivateSaleFundsDeposited",
    item: {
      id: ps.id,
      amount,
      sender,
    },
  };

  return data;
};

const processWhitelistAdded = async (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): Promise<PrivateSaleWhitelistAdded> => {
  const ps = await em.get(PrivateSale, log.address);
  if (!ps) return null as never;

  const { account } = privateSale.events.WhitelistAdded.decode(log);

  const data: PrivateSaleWhitelistAdded = {
    ...baseEventData,
    type: "PrivateSaleWhitelistAdded",
    item: {
      id: ps.id,
      users: account,
    },
  };

  return data;
};

const processWhitelistRemoved = async (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): Promise<PrivateSaleWhitelistRemoved> => {
  const ps = await em.get(PrivateSale, log.address);
  if (!ps) return null as never;

  const { account } = privateSale.events.WhitelistRemoved.decode(log);

  const data: PrivateSaleWhitelistRemoved = {
    ...baseEventData,
    type: "PrivateSaleWhitelistRemoved",
    item: {
      id: ps.id,
      users: account,
    },
  };

  return data;
};
