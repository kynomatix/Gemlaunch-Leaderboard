import { BlockData, Log } from "@subsquid/evm-processor";
import { BaseEventData, EVM, SubscriptionCreationData } from "../types";
import * as subscriptionFactory from "../abi/subscription-factory";

export const processSubscriptionFactory = (
  log: Log,
  baseEventData: BaseEventData,
  blocks: BlockData[]
): SubscriptionCreationData => {
  const _topic = log.topics[0];
  const { SubscriptionPoolCreated } = subscriptionFactory.events;

  if (_topic === SubscriptionPoolCreated.topic) {
    const {
      id,
      _info: {
        endTime,
        sellRate,
        startTime,
        softCap,
        hardCap,
        userHardCap,
        finalizeTime,
        listingRate,
        publicSaleTime,
        token,
      },
      liq: { liquidityAdded, liquidityPercent, lockTime, locker, router },
      subscriptionPool,
      refundType
    } = SubscriptionPoolCreated.decode(log);

    let fundToken: string = "";
    if ((log as unknown as EVM).transaction.input) {
      const { _fundToken } =
        subscriptionFactory.functions.createSubscriptionPool.decode(
          (log as unknown as EVM).transaction.input
        );
      fundToken = _fundToken;
    } else {
      const txBlock = blocks.find((x) => x.transactions.length > 0)!;
      console.log({ txBlock })
      fundToken = (txBlock.transactions as EVM["transaction"][]).find(
        (x) => x.input
      )?.input!;
    }

    const data: SubscriptionCreationData = {
      ...baseEventData,
      type: "SubscriptionPoolCreated",
      item: {
        id: id.toString(),
        name: "SubscriptionPool",
        owner: log.transaction?.from!,
        token: token,
        contractAddress: subscriptionPool.toLowerCase(),
        startTime,
        endTime,
        isCancelled: false,
        finalizeTime,
        hardCap,
        liquidityAdded,
        liquidityPercent,
        refundType,
        fundTokenAddress: fundToken,
        listingRate,
        investedAmount: 0n,
        locker,
        lockTime,
        investors: [],
        publicSaleTime,
        router,
        sellRate,
        softCap,
        userHardCap,
      },
    };

    return data;
  }

  return null as never;
};
