import { Log } from "@subsquid/evm-processor";
import {
  AirdropAddParticipantsData,
  AirdropAllocationsRemovedData,
  AirdropCancelledData,
  AirdropEventData,
  AirdropStartedData,
  AirdropTokensClaimedData,
  AirdropVestingInfoSetData,
  BaseEventData,
} from "../types";
import * as airdropAbi from "../abi/airdrop";
import { EntityManager } from "../utils/entityManager";
import { Airdrop, Allocation } from "../model";
import { LogEvent } from "../abi/abi.support";

export const processAirdropContract = (
  log: Log,
  em: EntityManager,
  baseEventData: BaseEventData
): AirdropEventData => {
  const _topic = log.topics[0];
  const {
    VestingInfoSet,
    AirdropCancelled,
    ParticipantsAdded,
    AirdropStarted,
    TokensCalimed,
    AllocationsRemoved,
  } = airdropAbi.events;

  if (_topic === VestingInfoSet.topic) {
    return processVestingInfoSet(log, baseEventData);
  }

  if (_topic === AirdropCancelled.topic) {
    return processAirdropCancelled(log, baseEventData, em);
  }

  if (_topic === ParticipantsAdded.topic) {
    return processParticipantsAdded(log, baseEventData);
  }

  if (_topic === AirdropStarted.topic) {
    return processAirdropStarted(log, baseEventData);
  }

  if (_topic === TokensCalimed.topic) {
    return processTokensCalimed(log, baseEventData);
  }

  if (_topic === AllocationsRemoved.topic) {
    return processAllocationsRemoved(log, baseEventData);
  }

  return null as never;
};

export const processAllocationsRemoved = (
  log: Log,
  baseEventData: BaseEventData
) => {
  const { sender, participants, id } =
    airdropAbi.events.AllocationsRemoved.decode(log);
  const data: AirdropAllocationsRemovedData = {
    ...baseEventData,
    type: "AirdropAllocationsRemoved",
    item: {
      id: id.toString(),
      sender,
      participants,
      token: "",
    },
  };

  return data;
};

export const processTokensCalimed = (
  log: Log,
  baseEventData: BaseEventData
) => {
  const { amount, claimTime, id } = airdropAbi.events.TokensCalimed.decode(log);

  const data: AirdropTokensClaimedData = {
    ...baseEventData,
    type: "AirdropTokensClaimed",
    item: {
      id: id.toString(),
      amount,
      claimTime,
      token: "",
    },
  };

  return data;
};

export const processAirdropStarted = (
  log: Log,
  baseEventData: BaseEventData
) => {
  const { id, status, startTime } =
    airdropAbi.events.AirdropStarted.decode(log);

  const data: AirdropStartedData = {
    ...baseEventData,
    type: "AirdropStarted",
    item: {
      id: id.toString(),
      status,
      startTime,
      token: "",
    },
  };

  return data;
};

export const processParticipantsAdded = (
  log: Log,
  baseEventData: BaseEventData
) => {
  const { receiver, tokenAmount, id } =
    airdropAbi.events.ParticipantsAdded.decode(log);

  const data: AirdropAddParticipantsData = {
    ...baseEventData,
    type: "AirdropAddParticipants",
    item: {
      id: id.toString(),
      receivers: receiver,
      tokenAmounts: tokenAmount,
      token: "",
    },
  };

  return data;
};

export const processAirdropCancelled = (
  log: Log,
  baseEventData: BaseEventData,
  em: EntityManager
) => {
  const { currentStatus, timestamp, tokenBalance, id } =
    airdropAbi.events.AirdropCancelled.decode(log);

  const data: AirdropCancelledData = {
    ...baseEventData,
    type: "AirdropCancelled",
    item: {
      id: id.toString(),
      status: currentStatus,
      timeStamp: timestamp,
      tokenBalance,
      token: "",
    },
  };

  return data;
};

export const processVestingInfoSet = (
  log: Log,
  baseEventData: BaseEventData
): AirdropVestingInfoSetData => {
  const { cycle, interval, isVesting, tge, id } =
    airdropAbi.events.VestingInfoSet.decode(log);

  const data: AirdropVestingInfoSetData = {
    ...baseEventData,
    type: "AirdropVestingInfoSet",
    item: {
      id: id.toString(),
      cycle,
      tge,
      interval,
      isVesting,
      token: "",
    },
  };

  return data;
};
