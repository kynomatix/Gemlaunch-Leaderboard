import { BlockData, Log } from "@subsquid/evm-processor";
import { BaseEventData, EVM, FairlaunchCreationData } from "../types";
import * as fairlaunchFactory from "../abi/fairlaunch-factory";
import * as fairlaunch from "../abi/fairlaunch";
import { LiquidityDetails } from "../model";
import { EntityManager } from "../utils/entityManager";

export const processFairlaunchFactory = (
  log: Log,
  baseEventData: BaseEventData,
  blocks: BlockData[],
): FairlaunchCreationData => {
  const _topic = log.topics[0];
  const { FairLaunchCreated } = fairlaunchFactory.events;

  if (_topic === FairLaunchCreated.topic) {
    const {
      id,
      fairLaunch,
      _info: {
        affiliateReward,
        isAffiliate,
        isMaxLimit,
        endTime,
        startTime,
        finalizeTime,
        maxBuyLimit,
        publicSaleTime,
        softCap,
        token,
        totalsellTokens,
      },
      liq: { router, liquidityPercent, lockTime, locker, liquidityAdded },
    } = FairLaunchCreated.decode(log);


    let fundToken: string = "";
    if ((log as unknown as EVM).transaction.input) {
      const { _fundToken } = fairlaunchFactory.functions.createFairLaunch.decode(
        (log as unknown as EVM).transaction.input
      );
      fundToken = _fundToken;
    } else {
      const txBlock = blocks.find((x) => x.transactions.length > 0)!;
      fundToken = (txBlock.transactions as EVM["transaction"][]).find(
        (x) => x.input
      )?.input!;
    }

    const data: FairlaunchCreationData = {
      ...baseEventData,
      type: "FairlaunchCreated",
      item: {
        id: id.toString(),
        token,
        owner: log.transaction?.from!,
        name: "Fairlaunch",
        contractAddress: fairLaunch,
        affiliateReward,
        startTime,
        endTime,
        isCancelled: false,
        finalizeTime,
        investors: [],
        investedAmount: 0n,
        isAffiliate,
        fundTokenAddress: fundToken,
        isMaxLimit,
        liquidityAdded,
        liquidityPercent,
        locker,
        lockTime,
        router,
        maxBuyLimit,
        publicSaleTime,
        softCap,
        totalSellTokens: totalsellTokens,
      },
    };

    return data;
  }

  return null as never;
};
