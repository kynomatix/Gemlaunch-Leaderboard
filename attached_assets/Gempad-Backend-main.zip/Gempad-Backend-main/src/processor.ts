import {
  BlockHeader,
  DataHandlerContext,
  EvmBatchProcessor,
  EvmBatchProcessorFields,
  Log as _Log,
  Transaction as _Transaction,
} from "@subsquid/evm-processor";

import {
  AIRDROP_FACTORY,
  ANTIBOT,
  ARCHIVE,
  BABY_TOKEN_FACTORY,
  BUYBACK_TOKEN_FACTORY,
  DATASOURCE,
  GEM_TOKEN_ADDRESSES,
  LIQUIDITY_TOKEN_FACTORY,
  LAUNCHPAD_FACTORY,
  PRIVATE_SALE_FACTORY,
  RANGE_AIRDROP_FACTORY,
  RANGE_ANTIBOT,
  RANGE_LAUNCHPAD_FACTORY,
  RANGE_LOCKER,
  RANGE_PRIVATE_SALE,
  RANGE_STANDARD_TOKEN,
  STANDARD_TOKEN_FACTORY,
  RANGE_FAIRLAUNCH_FACTORY,
  FAIRLAUNCH_FACTORY,
  DUTCH_FACTORY,
  RANGE_DUTCH_FACTORY,
  SUBSCRIPTION_FACTORY,
  RANGE_SUBSCRIPTION_FACTORY,
  LOCKER,
  LAUNCHPAD_CONTRACT,
  FAIRLAUNCH_CONTRACT,
  DUTCH_CONTRACT,
  SUBSCRIPTION_CONTRACT,
  RPC_ENDPOINT,
} from "./constants";

import * as gempadTokenLockerVesting from "./abi/locker";

import * as antibot from "./abi/antibot";

import * as aidropFactory from "./abi/airdrop-factory";
import * as airdropAbi from "./abi/airdrop";

import * as privateSaleFactory from "./abi/private-sale-factory";
import * as privateSale from "./abi/private-sale";

import * as standardTokenFactoryAbi from "./abi/standard-token-factory";
import * as liquidityTokenFactoryAbi from "./abi/liquidity-token-factory";
import * as babyTokenFactoryAbi from "./abi/baby-token-factory";
import * as buybackBabyTokenFactoryAbi from "./abi/buyback-baby-token";

import * as antibotStandardTokenFactoryAbi from "./abi/antibot-standard-token-factory";
import * as antibotLiquidityTokenFactoryAbi from "./abi/antibot-liquidity-token-factory";
import * as antibotBabyTokenFactoryAbi from "./abi/antibot-baby-token-factory";
import * as antibotBuybackBabyTokenFactoryAbi from "./abi/antibot-buyback-baby-token-factory";

import * as launchpadFactory from "./abi/launchpad-factory";
import * as launchpad from "./abi/launchpad";

import * as fairlaunchFactory from "./abi/fairlaunch-factory";
import * as fairlaunch from "./abi/fairlaunch";

import * as dutchFactory from "./abi/dutch-factory";
import * as dutch from "./abi/dutch";

import * as subscriptionFactory from "./abi/subscription-factory";
import * as subscription from "./abi/subscription";

if (!ARCHIVE) {
  throw new Error(`'ARCHIVE' env variable is missing`);
}

if (!DATASOURCE) {
  throw new Error(`'${ARCHIVE}' sqd dataSource is not defined`);
}

console.log("CURRENT ARCHIVE:", ARCHIVE);

export const processor = new EvmBatchProcessor()
  .setDataSource(DATASOURCE)
  .setFinalityConfirmation(75)
  .setRpcEndpoint(RPC_ENDPOINT)
  // .useArchiveOnly(true)
  // .setFields({
  //   transaction: {
  //     from: true,
  //     value: true,
  //     hash: true,
  //     input: true,
  //   },
  // })
  // .setBlockRange({
  //   from: 6_000_000,
  // })
  .setFields({
    log: {
      topics: true,
      data: true,
      transactionHash: true,
      address: true,
    },
    transaction: {
      chainId: true,
      from: true,
      gas: true,
      gasPrice: true,
      hash: true,
      input: true,
      to: true,
      value: true,
      log: true,
    },
  })
  .addLog({
    address: GEM_TOKEN_ADDRESSES,
    range: RANGE_STANDARD_TOKEN,
    topic0: [
      standardTokenFactoryAbi.events.TokenCreated.topic,
      antibotStandardTokenFactoryAbi.events.TokenCreated.topic,
      liquidityTokenFactoryAbi.events.TokenCreated.topic,
      antibotLiquidityTokenFactoryAbi.events.TokenCreated.topic,
      babyTokenFactoryAbi.events.TokenCreated.topic,
      antibotBabyTokenFactoryAbi.events.TokenCreated.topic,
      buybackBabyTokenFactoryAbi.events.TokenCreated.topic,
      antibotBuybackBabyTokenFactoryAbi.events.TokenCreated.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [LOCKER],
    range: RANGE_LOCKER,
    topic0: [
      gempadTokenLockerVesting.events.LockAdded.topic,
      gempadTokenLockerVesting.events.LockUpdated.topic,
      gempadTokenLockerVesting.events.LockRemoved.topic,
      gempadTokenLockerVesting.events.LockVested.topic,
      gempadTokenLockerVesting.events.VestingLockAdded.topic,
      gempadTokenLockerVesting.events.LockUpdated.topic,
      gempadTokenLockerVesting.events.LockOwnerChanged.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [ANTIBOT],
    range: RANGE_ANTIBOT,
    topic0: [antibot.events.Blacklist.topic, antibot.events.Whitelist.topic],
    transaction: true,
  })
  .addLog({
    address: [AIRDROP_FACTORY],
    range: RANGE_AIRDROP_FACTORY,
    topic0: [
      aidropFactory.events.GempadAirdropCreated.topic,
      aidropFactory.events.OwnershipTransferred.topic,
    ],
    transaction: true,
  })
  .addLog({
    range: RANGE_AIRDROP_FACTORY,
    topic0: [
      airdropAbi.events.VestingInfoSet.topic,
      airdropAbi.events.AirdropCancelled.topic,
      airdropAbi.events.AirdropStarted.topic,
      airdropAbi.events.ParticipantsAdded.topic,
      airdropAbi.events.AllocationsRemoved.topic,
      airdropAbi.events.TokensCalimed.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [PRIVATE_SALE_FACTORY],
    range: RANGE_PRIVATE_SALE,
    topic0: [privateSaleFactory.events.PrivateSaleCreated.topic],
    transaction: true,
  })
  .addLog({
    range: RANGE_PRIVATE_SALE,
    topic0: [
      privateSale.events.WhitelistAdded.topic,
      privateSale.events.WhitelistRemoved.topic,
      privateSale.events.AntibotInfoAdded.topic,
      privateSale.events.FundsDeposited.topic,
      privateSale.events.Cancelled.topic,
      privateSale.events.PublicSaleEnabled.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [LAUNCHPAD_FACTORY],
    range: RANGE_LAUNCHPAD_FACTORY,
    topic0: [launchpadFactory.events.LaunchpadCreated.topic],
    transaction: true,
  })
  .addLog({
    range: RANGE_LAUNCHPAD_FACTORY,
    topic0: [
      launchpad.events.Purchased.topic,
      launchpad.events.Finalized.topic,
      launchpad.events.Cancelled.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [FAIRLAUNCH_FACTORY],
    range: RANGE_FAIRLAUNCH_FACTORY,
    topic0: [fairlaunchFactory.events.FairLaunchCreated.topic],
    transaction: true,
  })
  .addLog({
    range: RANGE_FAIRLAUNCH_FACTORY,
    topic0: [
      fairlaunch.events.Purchased.topic,
      fairlaunch.events.Finalized.topic,
      fairlaunch.events.Cancelled.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [DUTCH_FACTORY],
    range: RANGE_DUTCH_FACTORY,
    topic0: [dutchFactory.events.DutchAuctionCreated.topic],
    transaction: true,
  })
  .addLog({
    range: RANGE_FAIRLAUNCH_FACTORY,
    topic0: [
      dutch.events.Purchased.topic,
      dutch.events.Finalized.topic,
      dutch.events.Cancelled.topic,
    ],
    transaction: true,
  })
  .addLog({
    address: [SUBSCRIPTION_FACTORY],
    range: RANGE_SUBSCRIPTION_FACTORY,
    topic0: [subscriptionFactory.events.SubscriptionPoolCreated.topic],
    transaction: true,
  })
  .addLog({
    range: RANGE_SUBSCRIPTION_FACTORY,
    topic0: [
      subscription.events.Purchased.topic,
      subscription.events.Finalized.topic,
      subscription.events.Cancelled.topic,
    ],
    transaction: true,
  })
  .addTransaction({
    to: [LAUNCHPAD_FACTORY],
    range: RANGE_LAUNCHPAD_FACTORY,
    sighash: [launchpadFactory.functions.createLaunchpad.sighash],
    logs: true,
  })
  .addTransaction({
    to: [FAIRLAUNCH_FACTORY],
    range: RANGE_FAIRLAUNCH_FACTORY,
    sighash: [fairlaunchFactory.functions.createFairLaunch.sighash],
    logs: true,
  })
  .addTransaction({
    to: [SUBSCRIPTION_FACTORY],
    range: RANGE_SUBSCRIPTION_FACTORY,
    sighash: [subscriptionFactory.functions.createSubscriptionPool.sighash],
    logs: true,
  })
  .addTransaction({
    to: [DUTCH_FACTORY],
    range: RANGE_DUTCH_FACTORY,
    sighash: [dutchFactory.functions.createDutchAuction.sighash],
    logs: true,
  });

export type Fields = EvmBatchProcessorFields<typeof processor>;
export type Block = BlockHeader<Fields>;
export type Log = _Log<Fields>;
export type Transaction = _Transaction<Fields>;
export type ProcessorContext<Store> = DataHandlerContext<Store, Fields>;
