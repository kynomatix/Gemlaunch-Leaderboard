import dotenv from "dotenv";
dotenv.config();

import { TypeormDatabase } from "@subsquid/typeorm-store";
import { processor } from "./processor";
import { EntityManager } from "./utils/entityManager";
import { PretechFactory } from "./mappings/prefetchFactory";
import {
  Aggregation,
  Lock,
  LockStatus,
  Token,
  Transaction,
  User,
  LockTemp,
  Airdrop,
  PrivateSale,
  Antibot,
  GemlaunchToken,
  LaunchPad,
  VestingDetails,
  LiquidityDetails,
  LaunchpadTemp,
  FundToken,
} from "./model";
import { CHAIN_ID } from "./constants";
import { Transaction as EvmTransaction } from "./processor";
import { In } from "typeorm";
import { sortBy } from "lodash";

import {
  addToBlacklist,
  addToWhitelist,
  removeFromBlacklist,
  removeFromWhitelist,
} from "./utils/antibot";

import {
  addParticipants,
  cancelAirdrop,
  createAirdrop,
  removeAllParticipants,
  startAirdrop,
  updateAirdropVestingInfo,
} from "./utils/airdrop";

import {
  handleAddedToWhitelist,
  handleFundsDeposited,
  handlePrivateSaleCancelled,
  handlePrivateSaleCreated,
  handleRemovedFromWhitelist,
} from "./utils/privateSale";
import { getLpToken, updateTokenPairCounts } from "./utils/token";
import {
  handleLockAdded,
  handleLockOwnerChanged,
  handleLockRemoved,
  handleLockUpdated,
  handleLockVested,
} from "./utils/locker";
import { handleGemTokenCreation } from "./utils/gemToken";
import {
  handleCreateLaunchpad,
  handlePoolCancelledLaunchpad,
  handlePoolFinalizedLaunchpad,
  handleTokenPurchased,
} from "./utils/launchpad";

processor.run(new TypeormDatabase({ supportHotBlocks: true }), async (ctx) => {
  const em = new EntityManager(ctx.store);
  const factory = new PretechFactory(ctx, em);

  await factory.prefetch();

  if (!em.hasData()) return;

  const createTransaction = async (
    transaction: EvmTransaction,
    lock: Lock
  ): Promise<void> => {
    const { hash, from, to, value, gas, gasPrice, transactionIndex, block } =
      transaction;

    em.add(
      new Transaction({
        id: hash.toLowerCase(),
        hash: hash.toLowerCase(),
        chainId: CHAIN_ID,
        index: transactionIndex,
        from: from?.toLowerCase(),
        to: to?.toLowerCase(),
        value,
        gas,
        gasPrice,
        blockNumber: block.height,
        lock: lock instanceof Lock ? lock : undefined,
        createdAt: new Date(block.timestamp),
      })
    );
  };

  const createAntibotTransaction = async (
    transaction: EvmTransaction
  ): Promise<void> => {
    const { hash, from, to, value, gas, gasPrice, transactionIndex, block } =
      transaction;

    const tx = new Transaction({
      id: hash.toLowerCase(),
      hash: hash.toLowerCase(),
      chainId: CHAIN_ID,
      index: transactionIndex,
      from: from.toLowerCase(),
      to: to?.toLowerCase(),
      value,
      gas,
      gasPrice,
      blockNumber: block.height,
      createdAt: new Date(block.timestamp),
    });

    em.add(tx);
  };

  const createNewTransaction = async (
    transaction: EvmTransaction
  ): Promise<void> => {
    const { hash, from, to, value, gas, gasPrice, transactionIndex, block } =
      transaction;

    const tx = new Transaction({
      id: hash.toLowerCase(),
      hash: hash.toLowerCase(),
      chainId: CHAIN_ID,
      index: transactionIndex,
      from: from.toLowerCase(),
      to: to?.toLowerCase(),
      value,
      gas,
      gasPrice,
      blockNumber: block.height,
      createdAt: new Date(block.timestamp),
    });

    em.add(tx);
  };

  // Airdrops
  for (const e of factory.airdropEventData) {
    const {
      item,
      type,
      transaction: { block, ...transaction },
    } = e;

    if (type === "AirdropCreated") {
      await createAirdrop(item, { block, ...transaction }, em, ctx);
    }

    if (type === "AirdropVestingInfoSet") {
      await updateAirdropVestingInfo(item, em);
    }
    if (type === "AirdropCancelled") {
      await cancelAirdrop(item, em);
    }
    if (type === "AirdropAddParticipants") {
      await addParticipants(item, em);
    }

    if (type === "AirdropStarted") {
      await startAirdrop(item, em);
    }

    if (type === "AirdropAllocationsRemoved") {
      await removeAllParticipants(item, em);
    }

    switch (type) {
      case "AirdropCreated":
      case "AirdropVestingInfoSet":
      case "AirdropAddParticipants":
      case "AirdropCancelled":
      case "AirdropAllocationsRemoved":
      case "AirdropStarted":
        createNewTransaction({ block, ...transaction });
        break;
      default:
        break;
    }
  }

  // Locker
  for (const e of factory.lockerEventData) {
    const {
      item,
      type,
      transaction: { block, ...transaction },
    } = e;

    // Lock Added
    if (type === "LockAdded") {
      await handleLockAdded(item, { block, ...transaction }, em);
    }

    // Lock Vested
    if (type === "VestingLockAdded") {
      await handleLockVested(item, { block, ...transaction }, em);
    }

    // Lock Owner Changed
    if (type === "LockOwnerChanged") {
      handleLockOwnerChanged(item, em);
    }

    // Lock Updated
    if (type === "LockUpdated") {
      handleLockUpdated(item, em);
    }

    // Lock Removed (withdrawn)
    if (type === "LockRemoved") {
      handleLockRemoved(item, em);
    }

    switch (type) {
      case "LockAdded":
      case "LockUpdated":
      case "LockRemoved":
      case "LockTransfer":
      case "VestingLockAdded":
      case "LockOwnerChanged":
        createTransaction({ block, ...transaction }, new Lock({ id: item.id }));
        break;
      default:
        break;
    }
  }

  // PrivateSale
  for (const e of factory.privateSaleEventData) {
    const {
      item,
      type,
      transaction: { block, ...transaction },
    } = e;

    if (type === "PrivateSaleAdded") {
      await handlePrivateSaleCreated(item, { block, ...transaction }, em);
    }

    if (type === "PrivateSaleFundsDeposited") {
      handleFundsDeposited(item, em);
    }

    if (type === "PrivateSaleWhitelistAdded") {
      handleAddedToWhitelist(item, em);
    }

    if (type === "PrivateSaleWhitelistRemoved") {
      handleRemovedFromWhitelist(item, em);
    }

    if (type === "PrivateSaleCancelled") {
      handlePrivateSaleCancelled(item, em);
    }

    switch (type) {
      case "PrivateSaleAdded":
      case "PrivateSaleWhitelistAdded":
      case "PrivateSaleWhitelistRemoved":
        createNewTransaction({ block, ...transaction });
        break;
      default:
        break;
    }
  }

  // Antibots
  for (const e of factory.antibotEventData) {
    const { item, type, transaction } = e;

    if (type === "AddRemoveToBlacklist") {
      console.log("inside main antibot");

      const { status } = item;
      if (status) {
        await addToBlacklist(item, em);
      }

      if (!status) {
        await removeFromBlacklist(item, em);
      }
    }

    if (type === "AddRemoveToWhitelist") {
      console.log("inside main whitelist");
      const { status } = item;
      if (status) {
        await addToWhitelist(item, em);
      }

      if (!status) {
        await removeFromWhitelist(item, em);
      }
    }

    switch (type) {
      case "AddRemoveToBlacklist":
      case "AddRemoveToWhitelist":
        createAntibotTransaction(transaction);
        break;
      default:
        break;
    }
  }

  // Gemlaunch tokens
  for (const e of factory.gemlaunchTokenEventData) {
    const { item, type, transaction } = e;
    if (type === "GemlaunchTokenCreated") {
      await handleGemTokenCreation(item, transaction, em, factory.blockCtx);
    }
  }

  // LaunchpadFactory
  for (const e of factory.launchpadsEventData) {
    const { item, type, transaction } = e;

    if (
      type === "LaunchpadCreated" ||
      type === "FairlaunchCreated" ||
      type === "DutchAuctionCreated" ||
      type === "SubscriptionPoolCreated"
    ) {
      await handleCreateLaunchpad(item, transaction, em, ctx, factory.blockCtx);
    }

    if (
      type === "TokenPurchasedLaunchpad" ||
      type === "TokenPurchasedDutch" ||
      type === "TokenPurchasedFairlaunch" ||
      type === "TokenPurchasedSubscription"
    ) {
      await handleTokenPurchased(item, transaction, em, ctx);
    }

    if (type === "PoolFinalizedLaunchpad") {
      await handlePoolFinalizedLaunchpad(item, transaction, em, ctx);
    }

    if (type === "PoolCancelledLaunchpad") {
      await handlePoolCancelledLaunchpad(item, transaction, em, ctx);
    }

    const { block, ...leftTransaction } = transaction;
    switch (type) {
      case "LaunchpadCreated":
      case "FairlaunchCreated":
      case "DutchAuctionCreated":
      case "SubscriptionPoolCreated":
        createNewTransaction({ block, ...leftTransaction });
        break;
      default:
        break;
    }
  }

  // Methods
  await ctx.store.save(em.values(User));
  await ctx.store.save(em.values(GemlaunchToken));
  await ctx.store.save(sortBy(em.values(Token), (x) => x.isLiquidityToken));
  await ctx.store.save(em.values(Lock));
  await ctx.store.save(em.values(Airdrop));
  await ctx.store.save(em.values(PrivateSale));
  await ctx.store.save(em.values(Antibot));
  await ctx.store.save(em.values(LaunchPad));

  // update nextUnlock prop tokens
  const tokens = await Promise.all(
    em.values(Token).map(async (token) => {
      const lpToken = await getLpToken(token.id, em, ctx);

      const nextUnlock = await ctx.store
        .findOne(Lock, {
          where: {
            token: { id: In([token.id, lpToken?.id].filter((x) => x)) } as any, // TODO: Remove any
          },
          order: { unlockDate: "desc" },
        })
        .then((x) => x?.unlockDate);

      return new Token({
        ...token,
        nextUnlock,
      });
    })
  );

  await Promise.all([
    ctx.store.save(tokens),
    ctx.store.save(em.values(Transaction)),
    ctx.store.save(em.values(Aggregation)),
  ]);
});
