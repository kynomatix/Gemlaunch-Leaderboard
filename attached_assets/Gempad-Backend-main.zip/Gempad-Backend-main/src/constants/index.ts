import * as dotenv from "dotenv";
dotenv.config();
import { KnownArchivesEVM, lookupArchive } from "@subsquid/archive-registry";
import { Range } from "@subsquid/util-internal-range";
import { Archives } from "../types";
import { DataHandlerContext, DataSource } from "@subsquid/evm-processor";
import { Store } from "@subsquid/typeorm-store";
import { EntityManager } from "../utils/entityManager";
import { RpcClient } from "@subsquid/evm-processor/lib/interfaces/chain";

export const ADDRESS_ZERO = "0x0000000000000000000000000000000000000000";
export const MULTICALL_ADDRESS = "0xcA11bde05977b3631167028862bE2a173976CA11"; // "0x5ba1e12693dc8f9c48aad8770482f4739beed696";

export enum FundTokenCurrency {
  NATIVE,
  USDT,
  USDC,
}

// export const ARCHIVE: KnownArchivesEVM = process.env
//   .ARCHIVE! as KnownArchivesEVM;
export const ARCHIVE: KnownArchivesEVM = "binance-testnet" as KnownArchivesEVM;

const DATASOURCES: Archives<DataSource> = {
  // ["eth-goerli"]: {
  //   archive: lookupArchive("eth-goerli"),
  //   chain: {
  //     url: process.env.RPC_ENDPOINT_GOERLI!,
  //     rateLimit: 20,
  //   },
  // },
  ["binance-testnet"]: {
    archive: lookupArchive("binance-testnet"),
    chain: {
      url: process.env.RPC_ENDPOINT_BINANCE_TEST!,
      rateLimit: 20,
    },
  },
  ["fantom-testnet"]: {
    archive: lookupArchive("fantom-testnet"),
    chain: {
      url: process.env.RPC_ENDPOINT_FANTOM_TEST!,
      rateLimit: 20,
    },
  },
};

const RPC_ENDPOINTS: Archives = {
  ["binance-testnet"]: process.env.RPC_ENDPOINT_BINANCE_TEST!,
};

const LOCKERS: Archives = {
  ["eth-goerli"]: "0x77350a508dDcD98E06b95d5ddB8f0F5b6BEb9B2E".toLowerCase(),
  ["binance-testnet"]:
    "0xD7bEf1D72417019597764209514FFB71DF1a868E".toLowerCase(),
  ["fantom-testnet"]:
    "0x9D15134f188e98BCd5F5053A864D88CfCBb1ce36".toLowerCase(),
};

const ANTIBOTS: Archives = {
  ["eth-goerli"]: "0x7D5742B2dD8A6827493d95AEB4a2e532F39638a9".toLowerCase(),
  ["binance-testnet"]:
    "0xFF314895Cb5E7470cBD138F5B8c0F19044DC1b3e".toLowerCase(),
  ["fantom-testnet"]:
    "0x48D463762f8f141429f4E06FaF7D96e377135403".toLowerCase(),
};

const AIRDROP_FACTORYS: Archives = {
  ["eth-goerli"]: "0x234b137Da6BD58467DF0809B9B45D9fE84B713e5".toLowerCase(),
  ["binance-testnet"]:
    "0xF5c3eDe95b0892289dDd261244d979bDe4b3D578".toLowerCase(),
  ["fantom-testnet"]:
    "0x3312E22aef0Bb65F82A51D714b881Aba47572Fc8".toLowerCase(),
};

const AIRDROP_CONTRACTS: Archives = {
  ["eth-goerli"]: "0xe893a8d177F744e80Aee12B8e57AA6ebe07f9C16".toLowerCase(),
  ["binance-testnet"]:
    "0x73aDBb46615007d0E7efcA88f2109805399ea7cC".toLowerCase(),
  ["fantom-testnet"]:
    "0x9616EF08b443b056874eB3f6c95AB6c25A8Bdd4a".toLowerCase(),
};

const STANDARD_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0x2124479Cae74bDde24816794e48312D58DA2F82d".toLowerCase(),
  ["fantom-testnet"]:
    "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
};
const LIQUIDITY_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0x1D38dCE9c2B602D869eB17557FD4425C8ECE2BA0".toLowerCase(),
  ["fantom-testnet"]:
    "0x44fC1596a1aA5c0D0123100A126D73Ce8F07B146".toLowerCase(),
};
const BABY_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0xA99374d1702Ea1B703d04E99178134e5ed2cDA53".toLowerCase(),
  ["fantom-testnet"]:
    "0xBaAF5100d9A4C3C18f80bac01Ad863Ef8F1df7AF".toLowerCase(),
};
const BUYBACK_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0x14304c3a48c8affF7C76dF6C72BbDC405712e42d".toLowerCase(),
  ["fantom-testnet"]:
    "0x414e494C0ffC973a4911742cd178934F1A6DF97B".toLowerCase(),
};

export const ANTIBOT_STANDARD_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0x0fE9Baa4d3B6e438FFaf9aEf98e601AeEC32fc81".toLowerCase(),
  ["fantom-testnet"]:
    "0x414e494C0ffC973a4911742cd178934F1A6DF97B".toLowerCase(),
};
export const ANTIBOT_LIQUIDITY_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0xcfeac0DD6Aa05FEa3F98a406476D634e99188080".toLowerCase(),
  ["fantom-testnet"]:
    "0x414e494C0ffC973a4911742cd178934F1A6DF97B".toLowerCase(),
};
export const ANTIBOT_BABY_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0x684B21a353bFD4c3f98564b5AdB9AEf831A591F8".toLowerCase(),
  ["fantom-testnet"]:
    "0x414e494C0ffC973a4911742cd178934F1A6DF97B".toLowerCase(),
};
export const ANTIBOT_BUYBACK_TOKEN_FACTORYS: Archives = {
  ["eth-goerli"]: "0xA19f8919eb220836eae44dF9a0B7C40089102FD1".toLowerCase(),
  ["binance-testnet"]:
    "0xE21f5Ffc4a72D5d4c8069521d98bCFD94D70bF74".toLowerCase(),
  ["fantom-testnet"]:
    "0x414e494C0ffC973a4911742cd178934F1A6DF97B".toLowerCase(),
};

const PRIVATE_SALE_FACTORYS: Archives = {
  ["eth-goerli"]: "0x2Cf13C66A9Fe16C9EAead68521dCb326e6cCFe66".toLowerCase(),
  ["binance-testnet"]:
    "0xC343F72Cc5edFA13c6Cf5823Df5AbAbdBAAE4106".toLowerCase(),
  ["fantom-testnet"]:
    "0x2ce0053BB40EC5e4082f2DBE3eb3A514c2EF4506".toLowerCase(),
};

const PRIVATE_SALE_CONTRACTS: Archives = {
  ["eth-goerli"]: "0xE9232AcD46B9aA6EC816f689fF0176dD89538bbC".toLowerCase(),
  ["binance-testnet"]:
    "0x7BC337A6A9BAE842A6F0ab9596f53E5056466753".toLowerCase(),
  ["fantom-testnet"]:
    "0x48D463762f8f141429f4E06FaF7D96e377135403".toLowerCase(),
};

const LAUNCHPAD_FACTORYS: Archives = {
  ["eth-goerli"]: "0x5134d16E2760fb3b23879ef13912B4d1116524Cb",
  ["binance-testnet"]: "0xbffc8a6E823C1d705E2f5162c49f56a01b8eB0Fd",
  ["fantom-testnet"]: "0x00295c2140dfC456Db8b3f3b01BF381AD3906Fc2",
};

const LAUNCHPAD_CONTRACTS: Archives = {
  ["eth-goerli"]: "0x5134d16E2760fb3b23879ef13912B4d1116524Cb",
  ["binance-testnet"]: "0x683CBC01d232fbbD6f4b07eCCE2aaD6ABB412eC1",
  ["fantom-testnet"]: "0xcb8866c9Af22D9902e06274761CB0Ad089AC000c",
};

const FAIRLAUNCH_FACTORYS: Archives = {
  ["eth-goerli"]: "0x7581700989152A3bF524caf7C0357AdE1857A1A1",
  ["binance-testnet"]: "0xA8B9616F6f8A9191404d63976307da0e80DA9E0B",
  ["fantom-testnet"]: "0x30f0D2EbcD8676c6242ED45E5686410564f2b94b",
};
const FAIRLAUNCH_CONTRACTS: Archives = {
  ["eth-goerli"]: "0x7581700989152A3bF524caf7C0357AdE1857A1A1",
  ["binance-testnet"]: "0x48d3BaC248Be25446E06BA1516c626A454A7d2c9",
  ["fantom-testnet"]: "0x85009c2334CDdC60D3f13a845e6BB4AD35eBCE73",
};

const DUTCH_FACTORYS: Archives = {
  ["eth-goerli"]: "0x7581700989152A3bF524caf7C0357AdE1857A1A1",
  ["binance-testnet"]: "0x1E176E9d228fE4e373610b608288bf7902cC3995", // new
  ["fantom-testnet"]: "0xE0a7e2961FB9Ff46C9dA5e7d78d51Cc7481544B8",
};

const DUTCH_CONTRACTS: Archives = {
  ["eth-goerli"]: "0x7581700989152A3bF524caf7C0357AdE1857A1A1",
  ["binance-testnet"]: "0x8D6813dcD2Cee696Dbe0A53F1ceDD4e95b29f23b", // new
  ["fantom-testnet"]: "0x870C0356C016E8b2d260A7169d39890CAA259363",
};

const SUBSCRIPTION_FACTORYS: Archives = {
  ["eth-goerli"]: "0xdeaDC218E5fac656b567c9C45e850114fd048228",
  ["binance-testnet"]: "0x0cAe00Bdf196F0Aa4a40706878e30156368Ae9AA", // new
  ["fantom-testnet"]: "0x6eD9572e6E327D66EFb7cDd00112D17D534E9C0e",
};

const SUBSCRIPTION_CONTRACTS: Archives = {
  ["eth-goerli"]: "0xdeaDC218E5fac656b567c9C45e850114fd048228",
  ["binance-testnet"]: "0x11ADaB86cE65a167a5a672b102d39C3C36d7600d", // new
  ["fantom-testnet"]: "0xDaef2A3e283f1187ccf9AC3e19B4AE630dBd396c",
};

const BLOCK_RANGES_STANDARD_TOKENS: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24344764 },
};

const BLOCK_RANGES_LAUNCHPAD_FACTORYS: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24756633 },
};

const BLOCK_RANGES_FAIRLAUNCH_FACTORYS: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24756633 },
};

const BLOCK_RANGES_DUTCH_FACTORYS: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 }, // new
  ["fantom-testnet"]: { from: 24756633 },
};

const BLOCK_RANGES_SUBSCRIPTION_FACTORYS: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24756633 },
};

const BLOCK_RANGES_LOCKER: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24508070 },
};

const BLOCK_RANGES_ANTIBOT: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
  ["fantom-testnet"]: { from: 24124570 },
};

const BLOCK_RANGES_AIRDROP_FACTORY: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
};

const BLOCK_RANGES_PRIVATE_SALES: Archives<Range> = {
  ["binance-testnet"]: { from: 40576394 },
};

// 38965463 old blocks for binance-testnet
const CHAIN_IDS: Archives<number> = {
  ["binance-testnet"]: 97,
};

// export const FUND_TOKEN: Record<`0x${string}`, FundTokenCurrency> = {
//   "0x0000000000000000000000000000000000000000": FundTokenCurrency.NATIVE,
//   "0xB12a6f31F80405cAe7fC11499F53EDBeC237b65C": FundTokenCurrency.USDC,
//   "0xAf4DB11839dD39fB4715d8942aA2EC72a842e648": FundTokenCurrency.USDT,
// };

export const FUND_TOKEN: Record<
  number,
  Record<`0x${string}`, FundTokenCurrency>
> = {
  [97]: {
    "0x0000000000000000000000000000000000000000": FundTokenCurrency.NATIVE,
    "0xB12a6f31F80405cAe7fC11499F53EDBeC237b65C": FundTokenCurrency.USDC,
    "0xAf4DB11839dD39fB4715d8942aA2EC72a842e648": FundTokenCurrency.USDT,
  },
}; // TODO: add multiple chains

export const DATASOURCE = DATASOURCES[ARCHIVE]!;
export const RPC_ENDPOINT = RPC_ENDPOINTS[ARCHIVE]!;

export const LAUNCHPAD_FACTORY = LAUNCHPAD_FACTORYS[ARCHIVE]!;
export const LAUNCHPAD_CONTRACT = LAUNCHPAD_CONTRACTS[ARCHIVE]!;

export const FAIRLAUNCH_FACTORY = FAIRLAUNCH_FACTORYS[ARCHIVE]!;
export const FAIRLAUNCH_CONTRACT = FAIRLAUNCH_CONTRACTS[ARCHIVE]!;

export const DUTCH_FACTORY = DUTCH_FACTORYS[ARCHIVE]!;
export const DUTCH_CONTRACT = DUTCH_CONTRACTS[ARCHIVE]!;

export const SUBSCRIPTION_FACTORY = SUBSCRIPTION_FACTORYS[ARCHIVE]!;
export const SUBSCRIPTION_CONTRACT = SUBSCRIPTION_CONTRACTS[ARCHIVE]!;

export const AIRDROP_FACTORY = AIRDROP_FACTORYS[ARCHIVE]!;
export const AIRDROP_CONTRACT = AIRDROP_CONTRACTS[ARCHIVE]!;

export const PRIVATE_SALE_FACTORY = PRIVATE_SALE_FACTORYS[ARCHIVE]!;
export const PRIVATE_SALE_CONTRACT = PRIVATE_SALE_CONTRACTS[ARCHIVE]!;

export const STANDARD_TOKEN_FACTORY = STANDARD_TOKEN_FACTORYS[ARCHIVE]!;
export const LIQUIDITY_TOKEN_FACTORY = LIQUIDITY_TOKEN_FACTORYS[ARCHIVE]!;
export const BABY_TOKEN_FACTORY = BABY_TOKEN_FACTORYS[ARCHIVE]!;
export const BUYBACK_TOKEN_FACTORY = BUYBACK_TOKEN_FACTORYS[ARCHIVE]!;

export const ANTIBOT_STANDARD_TOKEN_FACTORY =
  ANTIBOT_STANDARD_TOKEN_FACTORYS[ARCHIVE]!;
export const ANTIBOT_LIQUIDITY_TOKEN_FACTORY =
  ANTIBOT_LIQUIDITY_TOKEN_FACTORYS[ARCHIVE]!;
export const ANTIBOT_BABY_TOKEN_FACTORY = ANTIBOT_BABY_TOKEN_FACTORYS[ARCHIVE]!;
export const ANTIBOT_BUYBACK_TOKEN_FACTORY =
  ANTIBOT_BUYBACK_TOKEN_FACTORYS[ARCHIVE]!;

export const GEM_TOKEN_ADDRESSES = [
  STANDARD_TOKEN_FACTORY,
  ANTIBOT_STANDARD_TOKEN_FACTORY,
  LIQUIDITY_TOKEN_FACTORY,
  ANTIBOT_LIQUIDITY_TOKEN_FACTORY,
  BABY_TOKEN_FACTORY,
  ANTIBOT_BABY_TOKEN_FACTORY,
  ANTIBOT_BUYBACK_TOKEN_FACTORY,
];

export const LOCKER = LOCKERS[ARCHIVE]!;
export const ANTIBOT = ANTIBOTS[ARCHIVE]!;

export const RANGE_LAUNCHPAD_FACTORY =
  BLOCK_RANGES_LAUNCHPAD_FACTORYS[ARCHIVE]!;
export const RANGE_FAIRLAUNCH_FACTORY =
  BLOCK_RANGES_FAIRLAUNCH_FACTORYS[ARCHIVE]!;
export const RANGE_DUTCH_FACTORY = BLOCK_RANGES_DUTCH_FACTORYS[ARCHIVE]!;
export const RANGE_SUBSCRIPTION_FACTORY =
  BLOCK_RANGES_SUBSCRIPTION_FACTORYS[ARCHIVE]!;

export const RANGE_LOCKER = BLOCK_RANGES_LOCKER[ARCHIVE]!;
export const RANGE_ANTIBOT = BLOCK_RANGES_ANTIBOT[ARCHIVE]!;
export const RANGE_AIRDROP_FACTORY = BLOCK_RANGES_AIRDROP_FACTORY[ARCHIVE]!;
export const RANGE_PRIVATE_SALE = BLOCK_RANGES_PRIVATE_SALES[ARCHIVE]!;
export const RANGE_STANDARD_TOKEN = BLOCK_RANGES_STANDARD_TOKENS[ARCHIVE]!;

export const CHAIN_ID = CHAIN_IDS[ARCHIVE]!;
