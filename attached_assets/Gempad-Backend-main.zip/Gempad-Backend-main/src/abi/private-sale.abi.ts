export const ABI_JSON = [
    {
        "type": "event",
        "anonymous": false,
        "name": "AntibotInfoAdded",
        "inputs": [
            {
                "type": "uint256",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "mode",
                "indexed": false
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Cancelled",
        "inputs": [
            {
                "type": "uint256",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Finalized",
        "inputs": [
            {
                "type": "uint256",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "finalizeTime",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "FundsDeposited",
        "inputs": [
            {
                "type": "uint256",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Initialized",
        "inputs": [
            {
                "type": "uint8",
                "name": "version",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "PublicSaleEnabled",
        "inputs": [
            {
                "type": "uint256",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "saleTime",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "WhitelistAdded",
        "inputs": [
            {
                "type": "address[]",
                "name": "account"
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "WhitelistRemoved",
        "inputs": [
            {
                "type": "address[]",
                "name": "account"
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "function",
        "name": "Id",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "__GempadPrivateSale_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_id"
            },
            {
                "type": "address",
                "name": "_owner"
            },
            {
                "type": "tuple",
                "name": "info",
                "components": [
                    {
                        "type": "string",
                        "name": "name"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_vesting",
                "components": [
                    {
                        "type": "uint256",
                        "name": "initialRelease"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "uint8",
                "name": "_mode"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            },
            {
                "type": "address",
                "name": "_fundToken"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "__ServicePayer_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "address",
                "name": "receiver"
            },
            {
                "type": "string",
                "name": "serviceName"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "addWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "antibotToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "cancel",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimRefund",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimTokens",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimableTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "claimedAmount",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "depositOf",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "enableAntibotMode",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_token"
            },
            {
                "type": "uint256",
                "name": "_amount"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "enablePublicSale",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_startTime"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "finalize",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "fundByTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "fundToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllInvestors",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentMode",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "mode"
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentStatus",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "status"
            }
        ]
    },
    {
        "type": "function",
        "name": "investFunds",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_amount"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "isInitialized",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "isWhitelisted",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_address"
            }
        ],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "removeWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "saleInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "string",
                "name": "name"
            },
            {
                "type": "uint256",
                "name": "softCap"
            },
            {
                "type": "uint256",
                "name": "hardCap"
            },
            {
                "type": "uint256",
                "name": "minBuyLimit"
            },
            {
                "type": "uint256",
                "name": "maxBuyLimit"
            },
            {
                "type": "uint256",
                "name": "startTime"
            },
            {
                "type": "uint256",
                "name": "endTime"
            },
            {
                "type": "uint256",
                "name": "finalizeTime"
            },
            {
                "type": "uint256",
                "name": "publicSaleTime"
            }
        ]
    },
    {
        "type": "function",
        "name": "totalSale",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "vesting",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": "initialRelease"
            },
            {
                "type": "uint256",
                "name": "cyclePercent"
            },
            {
                "type": "uint256",
                "name": "cycleInterval"
            }
        ]
    }
]
