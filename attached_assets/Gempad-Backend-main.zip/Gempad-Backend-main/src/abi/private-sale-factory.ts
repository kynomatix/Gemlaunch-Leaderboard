import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './private-sale-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    PrivateSaleCreated: new LogEvent<([id: bigint, info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), mode: number, fundToken: string, privateSale: string] & {id: bigint, info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), mode: number, fundToken: string, privateSale: string})>(
        abi, '0xf7fca9057eaacc83ab30c9529c28c9793d51299272bc98c5fe1629bdd6729b5f'
    ),
}

export const functions = {
    IdCounter: new Func<[], {}, bigint>(
        abi, '0xae227ad4'
    ),
    createPrivateSale: new Func<[info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), mode: number, feeReceiver: string, fundToken: string], {info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), mode: number, feeReceiver: string, fundToken: string}, []>(
        abi, '0x39c235cb'
    ),
    getAllPrivateSales: new Func<[], {}, Array<string>>(
        abi, '0xe4ca9330'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getPrivateSaleBeacon: new Func<[], {}, string>(
        abi, '0x45c2067d'
    ),
    getUserPrivateSales: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0xd0cd87c8'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    IdCounter(): Promise<bigint> {
        return this.eth_call(functions.IdCounter, [])
    }

    getAllPrivateSales(): Promise<Array<string>> {
        return this.eth_call(functions.getAllPrivateSales, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getPrivateSaleBeacon(): Promise<string> {
        return this.eth_call(functions.getPrivateSaleBeacon, [])
    }

    getUserPrivateSales(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserPrivateSales, [_user])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
