export const ABI_JSON = [
    {
        "type": "event",
        "anonymous": false,
        "name": "LockAdded",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": true
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "isLpToken",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "unlockDate",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LockDescriptionChanged",
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LockOwnerChanged",
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LockRemoved",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": true
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "unlockedAt",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LockUpdated",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": true
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "newAmount",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "newUnlockDate",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LockVested",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": true
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "total",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "timestamp",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Paused",
        "inputs": [
            {
                "type": "address",
                "name": "account",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Unpaused",
        "inputs": [
            {
                "type": "address",
                "name": "account",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "VestingLockAdded",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": true
            },
            {
                "type": "address",
                "name": "token",
                "indexed": false
            },
            {
                "type": "address",
                "name": "owner",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "isLpToken",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "TGE",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "cycleShare",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "interval",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "unlockDate",
                "indexed": false
            }
        ]
    },
    {
        "type": "function",
        "name": "allLpTokenLockedCount",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "allNormalTokenLockedCount",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "cumulativeLockInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "address",
                "name": "factory"
            },
            {
                "type": "uint256",
                "name": "amount"
            }
        ]
    },
    {
        "type": "function",
        "name": "editLock",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            },
            {
                "type": "uint256",
                "name": "newAmount"
            },
            {
                "type": "uint256",
                "name": "newUnlockDate"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "editLockDescription",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            },
            {
                "type": "string",
                "name": "description"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "getCumulativeLpTokenLockInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "start"
            },
            {
                "type": "uint256",
                "name": "end"
            }
        ],
        "outputs": [
            {
                "type": "tuple[]",
                "name": "",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "factory"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getCumulativeLpTokenLockInfoAt",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "index"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "factory"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getCumulativeNormalTokenLockInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "start"
            },
            {
                "type": "uint256",
                "name": "end"
            }
        ],
        "outputs": [
            {
                "type": "tuple[]",
                "name": "",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "factory"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getCumulativeNormalTokenLockInfoAt",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "index"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "factory"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getLockAt",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "index"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getLockById",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getLocksForToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "uint256",
                "name": "start"
            },
            {
                "type": "uint256",
                "name": "end"
            }
        ],
        "outputs": [
            {
                "type": "tuple[]",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getTotalLockCount",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "lock",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "owner"
            },
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "bool",
                "name": "isLpToken"
            },
            {
                "type": "uint256",
                "name": "amount"
            },
            {
                "type": "uint256",
                "name": "unlockDate"
            },
            {
                "type": "string",
                "name": "description"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": "id"
            }
        ]
    },
    {
        "type": "function",
        "name": "lpLockCountForUser",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "lpLockForUserAtIndex",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            },
            {
                "type": "uint256",
                "name": "index"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "lpLocksForUser",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            }
        ],
        "outputs": [
            {
                "type": "tuple[]",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "multipleVestingLock",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "owners"
            },
            {
                "type": "uint256[]",
                "name": "amounts"
            },
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "bool",
                "name": "isLpToken"
            },
            {
                "type": "uint256",
                "name": "tgeDate"
            },
            {
                "type": "uint256",
                "name": "tgeBps"
            },
            {
                "type": "uint256",
                "name": "cycle"
            },
            {
                "type": "uint256",
                "name": "cycleBps"
            },
            {
                "type": "string",
                "name": "description"
            }
        ],
        "outputs": [
            {
                "type": "uint256[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "normalLockCountForUser",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "normalLockForUserAtIndex",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            },
            {
                "type": "uint256",
                "name": "index"
            }
        ],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "normalLocksForUser",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            }
        ],
        "outputs": [
            {
                "type": "tuple[]",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "id"
                    },
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "address",
                        "name": "owner"
                    },
                    {
                        "type": "uint256",
                        "name": "amount"
                    },
                    {
                        "type": "uint256",
                        "name": "lockDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeDate"
                    },
                    {
                        "type": "uint256",
                        "name": "tgeBps"
                    },
                    {
                        "type": "uint256",
                        "name": "cycle"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleBps"
                    },
                    {
                        "type": "uint256",
                        "name": "unlockedAmount"
                    },
                    {
                        "type": "string",
                        "name": "description"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "paused",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "renounceLockOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "totalLockCountForToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "token"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalLockCountForUser",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "user"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalTokenLockedCount",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "transferLockOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            },
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "unlock",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "vestingLock",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "owner"
            },
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "bool",
                "name": "isLpToken"
            },
            {
                "type": "uint256",
                "name": "amount"
            },
            {
                "type": "uint256",
                "name": "tgeDate"
            },
            {
                "type": "uint256",
                "name": "tgeBps"
            },
            {
                "type": "uint256",
                "name": "cycle"
            },
            {
                "type": "uint256",
                "name": "cycleBps"
            },
            {
                "type": "string",
                "name": "description"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": "id"
            }
        ]
    },
    {
        "type": "function",
        "name": "withdrawableTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "lockId"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    }
]
