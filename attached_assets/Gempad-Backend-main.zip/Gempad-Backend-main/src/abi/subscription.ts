import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './subscription.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    Cancelled: new LogEvent<([Id: string, status: number] & {Id: string, status: number})>(
        abi, '0xc8cdfb493c47eb0b3574be79de84863f2982c30ad3b2365d8064e9b1f1957d8f'
    ),
    Finalized: new LogEvent<([Id: string, finzlizeTime: bigint, status: number] & {Id: string, finzlizeTime: bigint, status: number})>(
        abi, '0x6a314f706983136e56fb80718294d65722af282cc5804f4eb28ae503cb529dc6'
    ),
    Initialized: new LogEvent<([version: number] & {version: number})>(
        abi, '0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    PublicSaleEnabled: new LogEvent<([Id: string, time: bigint] & {Id: string, time: bigint})>(
        abi, '0x1e8e6101440b5b2a6f0c6d8acd4de1b2aeed1ffdc69cf975600307b4b7d8b5c8'
    ),
    Purchased: new LogEvent<([Id: string, sender: string, _amount: bigint] & {Id: string, sender: string, _amount: bigint})>(
        abi, '0x3938ed494a2ac43205578f4190dcbdd61333ef5924e2db9ff8e6c3a204f840a6'
    ),
    UpdateTime: new LogEvent<([Id: string, start: bigint, end: bigint] & {Id: string, start: bigint, end: bigint})>(
        abi, '0xf80ef49d950f117083f540297f930bf980c275b4c11f784e0ab708289b3c5225'
    ),
    WhitelistUpdated: new LogEvent<([account: Array<string>, sender: string] & {account: Array<string>, sender: string})>(
        abi, '0x0c5a12c037597c1d2258bba4cf82c514e4e02fa76d7af223e59064e1d87e26aa'
    ),
    liquidityAdded: new LogEvent<([Id: string, pair: string, liquidity: bigint] & {Id: string, pair: string, liquidity: bigint})>(
        abi, '0x6b664bc3d1cb0e2df0092587ea712f1fe4aae5fe1acae3714deea67aa9aa0374'
    ),
}

export const functions = {
    Id: new Func<[], {}, bigint>(
        abi, '0x39a090c9'
    ),
    __GempadSubscriptionPool_init: new Func<[_id: bigint, info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _fundToken: string, _isPrivateMode: boolean, _isRefund: boolean, _feeReceiver: string, _owner: string], {_id: bigint, info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _fundToken: string, _isPrivateMode: boolean, _isRefund: boolean, _feeReceiver: string, _owner: string}, []>(
        abi, '0xf217c709'
    ),
    __ServicePayer_init: new Func<[receiver: string, serviceName: string], {receiver: string, serviceName: string}, []>(
        abi, '0xa35e3aec'
    ),
    addWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0xedac985b'
    ),
    buyToken: new Func<[_amount: bigint], {_amount: bigint}, []>(
        abi, '0x2d296bf1'
    ),
    calculateShare: new Func<[_totalTokens: bigint, _totalFunds: bigint, _contributors: Array<string>, _amounts: Array<bigint>], {_totalTokens: bigint, _totalFunds: bigint, _contributors: Array<string>, _amounts: Array<bigint>}, []>(
        abi, '0x288f6c5e'
    ),
    canCalculate: new Func<[], {}, boolean>(
        abi, '0xb7a12677'
    ),
    canFinalize: new Func<[], {}, boolean>(
        abi, '0x71e28126'
    ),
    cancel: new Func<[], {}, []>(
        abi, '0xea8a1af0'
    ),
    claimTokens: new Func<[], {}, []>(
        abi, '0x48c54b9d'
    ),
    claimUserRefund: new Func<[], {}, []>(
        abi, '0xa7e993eb'
    ),
    currentStatus: new Func<[], {}, number>(
        abi, '0xef8a9235'
    ),
    enablePublicSale: new Func<[_startTime: bigint], {_startTime: bigint}, []>(
        abi, '0xcfed032a'
    ),
    finalize: new Func<[], {}, []>(
        abi, '0x4bb278f3'
    ),
    fundByTokens: new Func<[], {}, boolean>(
        abi, '0x00fed700'
    ),
    fundToken: new Func<[], {}, string>(
        abi, '0x50adcdb7'
    ),
    getAllInvestors: new Func<[], {}, Array<string>>(
        abi, '0xd0a2f2c4'
    ),
    getCurrentMode: new Func<[], {}, number>(
        abi, '0x15370598'
    ),
    getCurrentStatus: new Func<[], {}, number>(
        abi, '0xa3dd2619'
    ),
    getDistribution: new Func<[], {}, [_: bigint, _: bigint, _: bigint]>(
        abi, '0x1cced51b'
    ),
    getSurplusData: new Func<[], {}, ([totalAllocated: bigint, surplusTokens: bigint, totalSurplusFunds: bigint, leftInvestors: Array<string>, amounts: Array<bigint>] & {totalAllocated: bigint, surplusTokens: bigint, totalSurplusFunds: bigint, leftInvestors: Array<string>, amounts: Array<bigint>})>(
        abi, '0x448a550a'
    ),
    getUserRemainingFunds: new Func<[], {}, bigint>(
        abi, '0x01634c30'
    ),
    isInitialized: new Func<[], {}, boolean>(
        abi, '0x392e53cd'
    ),
    isWhitelisted: new Func<[_address: string], {_address: string}, boolean>(
        abi, '0x3af32abf'
    ),
    liquidity: new Func<[], {}, ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint})>(
        abi, '0x1a686502'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    pool: new Func<[], {}, ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})>(
        abi, '0x16f0115b'
    ),
    removeWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0x23245216'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    setTime: new Func<[_startTime: bigint, _endTime: bigint], {_startTime: bigint, _endTime: bigint}, []>(
        abi, '0xa0355eca'
    ),
    totalClaimed: new Func<[], {}, bigint>(
        abi, '0xd54ad2a1'
    ),
    totalContribution: new Func<[], {}, bigint>(
        abi, '0x0dcf4b8f'
    ),
    totalRaised: new Func<[], {}, bigint>(
        abi, '0xc5c4744c'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    updateCalculation: new Func<[_contributors: Array<string>], {_contributors: Array<string>}, [_: bigint, _: bigint, _: Array<string>, _: Array<bigint>]>(
        abi, '0x68423808'
    ),
    userInfo: new Func<[_: string], {}, ([userInvest: bigint, userDeposit: bigint, userAllocation: bigint, userClaimed: bigint] & {userInvest: bigint, userDeposit: bigint, userAllocation: bigint, userClaimed: bigint})>(
        abi, '0x1959a002'
    ),
}

export class Contract extends ContractBase {

    Id(): Promise<bigint> {
        return this.eth_call(functions.Id, [])
    }

    canCalculate(): Promise<boolean> {
        return this.eth_call(functions.canCalculate, [])
    }

    canFinalize(): Promise<boolean> {
        return this.eth_call(functions.canFinalize, [])
    }

    currentStatus(): Promise<number> {
        return this.eth_call(functions.currentStatus, [])
    }

    fundByTokens(): Promise<boolean> {
        return this.eth_call(functions.fundByTokens, [])
    }

    fundToken(): Promise<string> {
        return this.eth_call(functions.fundToken, [])
    }

    getAllInvestors(): Promise<Array<string>> {
        return this.eth_call(functions.getAllInvestors, [])
    }

    getCurrentMode(): Promise<number> {
        return this.eth_call(functions.getCurrentMode, [])
    }

    getCurrentStatus(): Promise<number> {
        return this.eth_call(functions.getCurrentStatus, [])
    }

    getDistribution(): Promise<[_: bigint, _: bigint, _: bigint]> {
        return this.eth_call(functions.getDistribution, [])
    }

    getSurplusData(): Promise<([totalAllocated: bigint, surplusTokens: bigint, totalSurplusFunds: bigint, leftInvestors: Array<string>, amounts: Array<bigint>] & {totalAllocated: bigint, surplusTokens: bigint, totalSurplusFunds: bigint, leftInvestors: Array<string>, amounts: Array<bigint>})> {
        return this.eth_call(functions.getSurplusData, [])
    }

    getUserRemainingFunds(): Promise<bigint> {
        return this.eth_call(functions.getUserRemainingFunds, [])
    }

    isInitialized(): Promise<boolean> {
        return this.eth_call(functions.isInitialized, [])
    }

    isWhitelisted(_address: string): Promise<boolean> {
        return this.eth_call(functions.isWhitelisted, [_address])
    }

    liquidity(): Promise<([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint})> {
        return this.eth_call(functions.liquidity, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    pool(): Promise<([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})> {
        return this.eth_call(functions.pool, [])
    }

    totalClaimed(): Promise<bigint> {
        return this.eth_call(functions.totalClaimed, [])
    }

    totalContribution(): Promise<bigint> {
        return this.eth_call(functions.totalContribution, [])
    }

    totalRaised(): Promise<bigint> {
        return this.eth_call(functions.totalRaised, [])
    }

    userInfo(arg0: string): Promise<([userInvest: bigint, userDeposit: bigint, userAllocation: bigint, userClaimed: bigint] & {userInvest: bigint, userDeposit: bigint, userAllocation: bigint, userClaimed: bigint})> {
        return this.eth_call(functions.userInfo, [arg0])
    }
}
