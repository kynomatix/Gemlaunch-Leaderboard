import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './antibot-buyback-baby-token-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    TokenCreated: new LogEvent<([owner: string, token: string, tokenType: number] & {owner: string, token: string, tokenType: number})>(
        abi, '0x49fab9e82f453b3b0e1b0e507a645552d8b351f9b3cb0c9a7b4df572780c6b2f'
    ),
}

export const functions = {
    create: new Func<[name_: string, symbol_: string, totalSupply_: bigint, rewardToken_: string, router_: string, antiBot_: string, feeSettings_: Array<bigint>], {name_: string, symbol_: string, totalSupply_: bigint, rewardToken_: string, router_: string, antiBot_: string, feeSettings_: Array<bigint>}, string>(
        abi, '0x7de7514f'
    ),
    factoryManager: new Func<[], {}, string>(
        abi, '0x032b5a73'
    ),
    feeTo: new Func<[], {}, string>(
        abi, '0x017e7e58'
    ),
    flatFee: new Func<[], {}, bigint>(
        abi, '0xd9eb5947'
    ),
    implementation: new Func<[], {}, string>(
        abi, '0x5c60da1b'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    setFeeTo: new Func<[feeReceivingAddress: string], {feeReceivingAddress: string}, []>(
        abi, '0xf46901ed'
    ),
    setFlatFee: new Func<[fee: bigint], {fee: bigint}, []>(
        abi, '0x23fa495a'
    ),
    setImplementation: new Func<[implementation_: string], {implementation_: string}, []>(
        abi, '0xd784d426'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    factoryManager(): Promise<string> {
        return this.eth_call(functions.factoryManager, [])
    }

    feeTo(): Promise<string> {
        return this.eth_call(functions.feeTo, [])
    }

    flatFee(): Promise<bigint> {
        return this.eth_call(functions.flatFee, [])
    }

    implementation(): Promise<string> {
        return this.eth_call(functions.implementation, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
