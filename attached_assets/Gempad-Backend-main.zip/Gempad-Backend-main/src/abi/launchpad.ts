import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './launchpad.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    Cancelled: new LogEvent<([id: string, status: number, time: bigint] & {id: string, status: number, time: bigint})>(
        abi, '0x678b187c15ead9db4b77ec501801aef56fb50972dd72220cc46a570a3a4e4ca3'
    ),
    ClaimTimeUpdate: new LogEvent<([Id: string, time: bigint, sender: string] & {Id: string, time: bigint, sender: string})>(
        abi, '0xaf9e6c16ca7fe86abd83ca04a89d94ef0ee1757f8cc471185cde580fd20d4821'
    ),
    Finalized: new LogEvent<([Id: string, finzlizeTime: bigint, status: number] & {Id: string, finzlizeTime: bigint, status: number})>(
        abi, '0x6a314f706983136e56fb80718294d65722af282cc5804f4eb28ae503cb529dc6'
    ),
    Initialized: new LogEvent<([version: number] & {version: number})>(
        abi, '0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    PublicSaleEnabled: new LogEvent<([Id: string, time: bigint] & {Id: string, time: bigint})>(
        abi, '0x1e8e6101440b5b2a6f0c6d8acd4de1b2aeed1ffdc69cf975600307b4b7d8b5c8'
    ),
    Purchased: new LogEvent<([Id: string, sender: string, _amount: bigint, amount: bigint] & {Id: string, sender: string, _amount: bigint, amount: bigint})>(
        abi, '0xa326259ec721617acd3cb2a00bcbeac91eefe409880e49aa2bbf473ed648da49'
    ),
    RewardsCalimed: new LogEvent<([Id: string, receiver: string, share: bigint] & {Id: string, receiver: string, share: bigint})>(
        abi, '0x6f34c456d23677a6849f4cbaa263fd0beafa71d5fc974548d652936f1f4e4cf5'
    ),
    Transfer: new LogEvent<([Id: string, receiver: string, token: bigint] & {Id: string, receiver: string, token: bigint})>(
        abi, '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'
    ),
    UpdateReward: new LogEvent<([Id: string, reward: bigint, sender: string] & {Id: string, reward: bigint, sender: string})>(
        abi, '0x927b04056419909f8447e9638542a08678274ee5324ec4d137520829298e93f2'
    ),
    UpdateTime: new LogEvent<([Id: string, start: bigint, end: bigint] & {Id: string, start: bigint, end: bigint})>(
        abi, '0xf80ef49d950f117083f540297f930bf980c275b4c11f784e0ab708289b3c5225'
    ),
    WhitelistUpdated: new LogEvent<([account: Array<string>, sender: string] & {account: Array<string>, sender: string})>(
        abi, '0x0c5a12c037597c1d2258bba4cf82c514e4e02fa76d7af223e59064e1d87e26aa'
    ),
    liquidityAdded: new LogEvent<([Id: string, pair: string, liquidity: bigint] & {Id: string, pair: string, liquidity: bigint})>(
        abi, '0x6b664bc3d1cb0e2df0092587ea712f1fe4aae5fe1acae3714deea67aa9aa0374'
    ),
}

export const functions = {
    Id: new Func<[], {}, bigint>(
        abi, '0x39a090c9'
    ),
    __GempadLaunchpad_init: new Func<[_id: bigint, info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isPrivateMode: boolean, _isAffiliate: boolean, _affiliateReward: bigint, _refundType: boolean, _feeReceiver: string, _owner: string], {_id: bigint, info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isPrivateMode: boolean, _isAffiliate: boolean, _affiliateReward: bigint, _refundType: boolean, _feeReceiver: string, _owner: string}, []>(
        abi, '0xdb36137e'
    ),
    __ServicePayer_init: new Func<[receiver: string, serviceName: string], {receiver: string, serviceName: string}, []>(
        abi, '0xa35e3aec'
    ),
    addWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0xedac985b'
    ),
    affiliateReward: new Func<[], {}, bigint>(
        abi, '0xbb490daa'
    ),
    buyToken: new Func<[_amount: bigint, _referrer: string], {_amount: bigint, _referrer: string}, []>(
        abi, '0x9134709e'
    ),
    cancel: new Func<[], {}, []>(
        abi, '0xea8a1af0'
    ),
    claimReward: new Func<[], {}, []>(
        abi, '0xb88a802f'
    ),
    claimTime: new Func<[], {}, bigint>(
        abi, '0x27b3bf11'
    ),
    claimTokens: new Func<[], {}, []>(
        abi, '0x48c54b9d'
    ),
    claimUserRefund: new Func<[], {}, []>(
        abi, '0xa7e993eb'
    ),
    claimableTokens: new Func<[], {}, bigint>(
        abi, '0xbab8fe40'
    ),
    currentStatus: new Func<[], {}, number>(
        abi, '0xef8a9235'
    ),
    enablePublicSale: new Func<[_startTime: bigint], {_startTime: bigint}, []>(
        abi, '0xcfed032a'
    ),
    finalize: new Func<[], {}, []>(
        abi, '0x4bb278f3'
    ),
    fundByTokens: new Func<[], {}, boolean>(
        abi, '0x00fed700'
    ),
    fundToken: new Func<[], {}, string>(
        abi, '0x50adcdb7'
    ),
    getAllInvestors: new Func<[], {}, Array<string>>(
        abi, '0xd0a2f2c4'
    ),
    getAllReferrers: new Func<[], {}, Array<string>>(
        abi, '0xb9a9f739'
    ),
    getCurrentMode: new Func<[], {}, number>(
        abi, '0x15370598'
    ),
    getCurrentStatus: new Func<[], {}, number>(
        abi, '0xa3dd2619'
    ),
    getTotalSaleTokens: new Func<[], {}, bigint>(
        abi, '0x111f0cd8'
    ),
    getTotalTokensSold: new Func<[], {}, bigint>(
        abi, '0x94c33163'
    ),
    getUserRemainingClaimable: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0x02226b08'
    ),
    getUserTokens: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0x519dc8d2'
    ),
    isAffiliate: new Func<[], {}, boolean>(
        abi, '0x44f75cbd'
    ),
    isWhitelisted: new Func<[_address: string], {_address: string}, boolean>(
        abi, '0x3af32abf'
    ),
    liquidity: new Func<[], {}, ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean})>(
        abi, '0x1a686502'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    pool: new Func<[], {}, ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})>(
        abi, '0x16f0115b'
    ),
    removeWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0x23245216'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    rewardInfo: new Func<[_: string], {}, ([referralInvest: bigint, rewardShare: bigint] & {referralInvest: bigint, rewardShare: bigint})>(
        abi, '0xcbecf6b5'
    ),
    setAffiliation: new Func<[_reward: bigint], {_reward: bigint}, []>(
        abi, '0x824f3473'
    ),
    setClaimTime: new Func<[_time: bigint], {_time: bigint}, []>(
        abi, '0x421cc337'
    ),
    setTime: new Func<[_startTime: bigint, _endTime: bigint], {_startTime: bigint, _endTime: bigint}, []>(
        abi, '0xa0355eca'
    ),
    tokenFee: new Func<[], {}, bigint>(
        abi, '0x45599136'
    ),
    totalClaimed: new Func<[], {}, bigint>(
        abi, '0xd54ad2a1'
    ),
    totalRaised: new Func<[], {}, bigint>(
        abi, '0xc5c4744c'
    ),
    totalReferralInvest: new Func<[], {}, bigint>(
        abi, '0xd18f0a69'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    userInfo: new Func<[_: string], {}, ([userInvest: bigint, userCalimed: bigint, lastClaimTime: bigint, intervalClaimed: bigint] & {userInvest: bigint, userCalimed: bigint, lastClaimTime: bigint, intervalClaimed: bigint})>(
        abi, '0x1959a002'
    ),
    vesting: new Func<[], {}, ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint})>(
        abi, '0x44c63eec'
    ),
    withdrawTokens: new Func<[], {}, []>(
        abi, '0x8d8f2adb'
    ),
}

export class Contract extends ContractBase {

    Id(): Promise<bigint> {
        return this.eth_call(functions.Id, [])
    }

    affiliateReward(): Promise<bigint> {
        return this.eth_call(functions.affiliateReward, [])
    }

    claimTime(): Promise<bigint> {
        return this.eth_call(functions.claimTime, [])
    }

    claimableTokens(): Promise<bigint> {
        return this.eth_call(functions.claimableTokens, [])
    }

    currentStatus(): Promise<number> {
        return this.eth_call(functions.currentStatus, [])
    }

    fundByTokens(): Promise<boolean> {
        return this.eth_call(functions.fundByTokens, [])
    }

    fundToken(): Promise<string> {
        return this.eth_call(functions.fundToken, [])
    }

    getAllInvestors(): Promise<Array<string>> {
        return this.eth_call(functions.getAllInvestors, [])
    }

    getAllReferrers(): Promise<Array<string>> {
        return this.eth_call(functions.getAllReferrers, [])
    }

    getCurrentMode(): Promise<number> {
        return this.eth_call(functions.getCurrentMode, [])
    }

    getCurrentStatus(): Promise<number> {
        return this.eth_call(functions.getCurrentStatus, [])
    }

    getTotalSaleTokens(): Promise<bigint> {
        return this.eth_call(functions.getTotalSaleTokens, [])
    }

    getTotalTokensSold(): Promise<bigint> {
        return this.eth_call(functions.getTotalTokensSold, [])
    }

    getUserRemainingClaimable(_user: string): Promise<bigint> {
        return this.eth_call(functions.getUserRemainingClaimable, [_user])
    }

    getUserTokens(_user: string): Promise<bigint> {
        return this.eth_call(functions.getUserTokens, [_user])
    }

    isAffiliate(): Promise<boolean> {
        return this.eth_call(functions.isAffiliate, [])
    }

    isWhitelisted(_address: string): Promise<boolean> {
        return this.eth_call(functions.isWhitelisted, [_address])
    }

    liquidity(): Promise<([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean})> {
        return this.eth_call(functions.liquidity, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    pool(): Promise<([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})> {
        return this.eth_call(functions.pool, [])
    }

    rewardInfo(arg0: string): Promise<([referralInvest: bigint, rewardShare: bigint] & {referralInvest: bigint, rewardShare: bigint})> {
        return this.eth_call(functions.rewardInfo, [arg0])
    }

    tokenFee(): Promise<bigint> {
        return this.eth_call(functions.tokenFee, [])
    }

    totalClaimed(): Promise<bigint> {
        return this.eth_call(functions.totalClaimed, [])
    }

    totalRaised(): Promise<bigint> {
        return this.eth_call(functions.totalRaised, [])
    }

    totalReferralInvest(): Promise<bigint> {
        return this.eth_call(functions.totalReferralInvest, [])
    }

    userInfo(arg0: string): Promise<([userInvest: bigint, userCalimed: bigint, lastClaimTime: bigint, intervalClaimed: bigint] & {userInvest: bigint, userCalimed: bigint, lastClaimTime: bigint, intervalClaimed: bigint})> {
        return this.eth_call(functions.userInfo, [arg0])
    }

    vesting(): Promise<([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint})> {
        return this.eth_call(functions.vesting, [])
    }
}
