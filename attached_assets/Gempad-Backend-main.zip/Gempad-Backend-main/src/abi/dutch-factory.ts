import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './dutch-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    DutchAuctionCreated: new LogEvent<([id: string, info: ([token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint] & {token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint}), _: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), dutchAuction: string, refundType: boolean] & {id: string, info: ([token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint] & {token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), dutchAuction: string, refundType: boolean})>(
        abi, '0x78282f8c562ba19d3a2ba0611b60b52cac553b99fc6852b0298c4c6dfb1058bc'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
}

export const functions = {
    IdCounter: new Func<[], {}, bigint>(
        abi, '0xae227ad4'
    ),
    createDutchAuction: new Func<[info: ([token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint] & {token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isPrivateMode: boolean, _refundType: boolean, _feeReceiver: string], {info: ([token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint] & {token: string, totalSaleAmount: bigint, startPrice: bigint, endPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, decreaseInterval: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isPrivateMode: boolean, _refundType: boolean, _feeReceiver: string}, []>(
        abi, '0x4e8396a0'
    ),
    dutchAuctions: new Func<[_: bigint], {}, string>(
        abi, '0xf2ab2fc0'
    ),
    getAllDutchAuctions: new Func<[], {}, Array<string>>(
        abi, '0x280fc057'
    ),
    getDutchAuction: new Func<[], {}, string>(
        abi, '0x4b2e3ccb'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getUserDutchAuctions: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0x59738b86'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    IdCounter(): Promise<bigint> {
        return this.eth_call(functions.IdCounter, [])
    }

    dutchAuctions(arg0: bigint): Promise<string> {
        return this.eth_call(functions.dutchAuctions, [arg0])
    }

    getAllDutchAuctions(): Promise<Array<string>> {
        return this.eth_call(functions.getAllDutchAuctions, [])
    }

    getDutchAuction(): Promise<string> {
        return this.eth_call(functions.getDutchAuction, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getUserDutchAuctions(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserDutchAuctions, [_user])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
