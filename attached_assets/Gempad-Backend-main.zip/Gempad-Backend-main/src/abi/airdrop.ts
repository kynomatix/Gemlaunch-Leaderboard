import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './airdrop.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    AirdropCancelled: new LogEvent<([id: bigint, currentStatus: number, tokenBalance: bigint, timestamp: bigint] & {id: bigint, currentStatus: number, tokenBalance: bigint, timestamp: bigint})>(
        abi, '0xb79be9fadb6787ee00a0d259c3e53dbaeddc6c7bf0a439417e5835bfb2c4ea22'
    ),
    AirdropStarted: new LogEvent<([id: bigint, startTime: bigint, status: number] & {id: bigint, startTime: bigint, status: number})>(
        abi, '0xaacdfa5f2d702967189507d91768d26cc6580b8633d4bd0ca460cf2476d6ea17'
    ),
    AllocationsRemoved: new LogEvent<([id: bigint, participants: Array<string>, sender: string] & {id: bigint, participants: Array<string>, sender: string})>(
        abi, '0x900b9f9f27c0b6862db86176b81c975a5b127ae2dc979cd2d058be1613d5cab4'
    ),
    ExactAmountDisabled: new LogEvent<([id: bigint, caller: string, status: boolean] & {id: bigint, caller: string, status: boolean})>(
        abi, '0xcfa9f63a805485c8ddaf9338b84edb0a35277a40dc333ce048a23859d3521c01'
    ),
    Initialized: new LogEvent<([version: number] & {version: number})>(
        abi, '0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    ParticipantsAdded: new LogEvent<([id: bigint, receiver: Array<string>, tokenAmount: Array<bigint>] & {id: bigint, receiver: Array<string>, tokenAmount: Array<bigint>})>(
        abi, '0xee9f17d3c10021364ed6d265397327067e370cdd2a8c1f5ee25d7435360d3773'
    ),
    TokensCalimed: new LogEvent<([id: bigint, amount: bigint, fee: bigint, claimTime: bigint] & {id: bigint, amount: bigint, fee: bigint, claimTime: bigint})>(
        abi, '0x6845b0fbe444755f9273e33efeb08a427144c1846f168d3ad31090d6fe535432'
    ),
    VestingInfoSet: new LogEvent<([id: bigint, tge: bigint, cycle: bigint, interval: bigint, isVesting: boolean] & {id: bigint, tge: bigint, cycle: bigint, interval: bigint, isVesting: boolean})>(
        abi, '0x33d1fd2e2ac088ee2fa101f5598cfe326114ec4f73f0090cba1ecea8efc55744'
    ),
}

export const functions = {
    __GempadAirdrop_init: new Func<[_id: bigint, _owner: string, _tokenAddress: string, _airdropName: string, _feeReceiver: string], {_id: bigint, _owner: string, _tokenAddress: string, _airdropName: string, _feeReceiver: string}, []>(
        abi, '0xa656401b'
    ),
    __ServicePayer_init: new Func<[receiver: string, serviceName: string], {receiver: string, serviceName: string}, []>(
        abi, '0xa35e3aec'
    ),
    addParticipantsAndAllocation: new Func<[receivers: Array<string>, tokenAmounts: Array<bigint>], {receivers: Array<string>, tokenAmounts: Array<bigint>}, []>(
        abi, '0x7217b406'
    ),
    airdropName: new Func<[], {}, string>(
        abi, '0x6c9533d1'
    ),
    cancelAirdrop: new Func<[], {}, []>(
        abi, '0xf715c99e'
    ),
    claimTokens: new Func<[], {}, []>(
        abi, '0x48c54b9d'
    ),
    disbableEnsureExactAmount: new Func<[], {}, []>(
        abi, '0x8d58740b'
    ),
    ensureExactAmount: new Func<[], {}, boolean>(
        abi, '0x4c5ca8c8'
    ),
    getClaimInfo: new Func<[_user: string], {_user: string}, ([claimed: bigint, userAllocation: bigint, lastClaimTime: bigint] & {claimed: bigint, userAllocation: bigint, lastClaimTime: bigint})>(
        abi, '0x0835fe47'
    ),
    getClaimable: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0xa583024b'
    ),
    getClaimedAmount: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0x8df40be8'
    ),
    getCurrentStatus: new Func<[], {}, number>(
        abi, '0xa3dd2619'
    ),
    getParticipants: new Func<[], {}, Array<string>>(
        abi, '0x5aa68ac0'
    ),
    getRemainingClaimabaleAmount: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0xb0e9f43c'
    ),
    getUserAllocation: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0xb920ade2'
    ),
    id: new Func<[], {}, bigint>(
        abi, '0xaf640d0f'
    ),
    initialized: new Func<[], {}, boolean>(
        abi, '0x158ef93e'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    removeAllocations: new Func<[], {}, []>(
        abi, '0xcd7816df'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    setVestingInfo: new Func<[_TGEPercent: bigint, _cyclePercent: bigint, _cycleInterval: bigint], {_TGEPercent: bigint, _cyclePercent: bigint, _cycleInterval: bigint}, []>(
        abi, '0x00414ffd'
    ),
    startAirdrop: new Func<[_startTime: bigint], {_startTime: bigint}, []>(
        abi, '0xbeae207f'
    ),
    startTime: new Func<[], {}, bigint>(
        abi, '0x78e97925'
    ),
    token: new Func<[], {}, string>(
        abi, '0xfc0c546a'
    ),
    totalClaimedTokens: new Func<[], {}, bigint>(
        abi, '0xfcb56f47'
    ),
    totalTokens: new Func<[], {}, bigint>(
        abi, '0x7e1c0c09'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    vestingInfo: new Func<[], {}, ([TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint, isVestingEnabled: boolean] & {TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint, isVestingEnabled: boolean})>(
        abi, '0x20df1344'
    ),
}

export class Contract extends ContractBase {

    airdropName(): Promise<string> {
        return this.eth_call(functions.airdropName, [])
    }

    ensureExactAmount(): Promise<boolean> {
        return this.eth_call(functions.ensureExactAmount, [])
    }

    getClaimInfo(_user: string): Promise<([claimed: bigint, userAllocation: bigint, lastClaimTime: bigint] & {claimed: bigint, userAllocation: bigint, lastClaimTime: bigint})> {
        return this.eth_call(functions.getClaimInfo, [_user])
    }

    getClaimable(_user: string): Promise<bigint> {
        return this.eth_call(functions.getClaimable, [_user])
    }

    getClaimedAmount(_user: string): Promise<bigint> {
        return this.eth_call(functions.getClaimedAmount, [_user])
    }

    getCurrentStatus(): Promise<number> {
        return this.eth_call(functions.getCurrentStatus, [])
    }

    getParticipants(): Promise<Array<string>> {
        return this.eth_call(functions.getParticipants, [])
    }

    getRemainingClaimabaleAmount(_user: string): Promise<bigint> {
        return this.eth_call(functions.getRemainingClaimabaleAmount, [_user])
    }

    getUserAllocation(_user: string): Promise<bigint> {
        return this.eth_call(functions.getUserAllocation, [_user])
    }

    id(): Promise<bigint> {
        return this.eth_call(functions.id, [])
    }

    initialized(): Promise<boolean> {
        return this.eth_call(functions.initialized, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    startTime(): Promise<bigint> {
        return this.eth_call(functions.startTime, [])
    }

    token(): Promise<string> {
        return this.eth_call(functions.token, [])
    }

    totalClaimedTokens(): Promise<bigint> {
        return this.eth_call(functions.totalClaimedTokens, [])
    }

    totalTokens(): Promise<bigint> {
        return this.eth_call(functions.totalTokens, [])
    }

    vestingInfo(): Promise<([TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint, isVestingEnabled: boolean] & {TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint, isVestingEnabled: boolean})> {
        return this.eth_call(functions.vestingInfo, [])
    }
}
