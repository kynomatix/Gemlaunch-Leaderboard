import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './antibot.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    Blacklist: new LogEvent<([token: string, users: Array<string>, status: boolean] & {token: string, users: Array<string>, status: boolean})>(
        abi, '0xab277a8e804be6591e4c17675214635e4db41816ad42301f8daba34aeff350c7'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    Whitelist: new LogEvent<([token: string, users: Array<string>, status: boolean] & {token: string, users: Array<string>, status: boolean})>(
        abi, '0x1214c14e7b9401eed7a8f53252e63357621ed442a8217862110cd8dcb3d6ff74'
    ),
}

export const functions = {
    addBlackLists: new Func<[_token: string, _blacklists: Array<string>], {_token: string, _blacklists: Array<string>}, []>(
        abi, '0xbe67a142'
    ),
    addWhiteLists: new Func<[_token: string, _whitelists: Array<string>], {_token: string, _whitelists: Array<string>}, []>(
        abi, '0x329ef04c'
    ),
    blacklists: new Func<[_: string, _: string], {}, boolean>(
        abi, '0x00848674'
    ),
    configs: new Func<[_: string], {}, ([router: string, pair: string, limitAmount: bigint, amountPerBlock: bigint, limitTime: bigint, startBlock: bigint, disableBlock: bigint, preTransferTime: bigint] & {router: string, pair: string, limitAmount: bigint, amountPerBlock: bigint, limitTime: bigint, startBlock: bigint, disableBlock: bigint, preTransferTime: bigint})>(
        abi, '0xfce89878'
    ),
    getCurrrentBlock: new Func<[], {}, bigint>(
        abi, '0x73119c2f'
    ),
    isConfigSet: new Func<[_: string], {}, boolean>(
        abi, '0x594f918d'
    ),
    minBlockLimit: new Func<[], {}, bigint>(
        abi, '0xbbc39824'
    ),
    onPreTransferCheck: new Func<[from: string, to: string, amount: bigint], {from: string, to: string, amount: bigint}, boolean>(
        abi, '0x48760858'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    removeWhiteLists: new Func<[_token: string, _whitelists: Array<string>], {_token: string, _whitelists: Array<string>}, []>(
        abi, '0x29a70532'
    ),
    removeblackLists: new Func<[_token: string, _blacklists: Array<string>], {_token: string, _blacklists: Array<string>}, []>(
        abi, '0x85ce3344'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    saveConfig: new Func<[_token: string, _router: string, _pair: string, _limitAmount: bigint, _amountPerBlock: bigint, _limitTime: bigint, _disableBlock: bigint], {_token: string, _router: string, _pair: string, _limitAmount: bigint, _amountPerBlock: bigint, _limitTime: bigint, _disableBlock: bigint}, []>(
        abi, '0x334af0c8'
    ),
    setMinBlockLimit: new Func<[_minBlockLimit: bigint], {_minBlockLimit: bigint}, []>(
        abi, '0xd175e247'
    ),
    setTokenOwner: new Func<[owner: string], {owner: string}, []>(
        abi, '0x18e02bd9'
    ),
    token_owner: new Func<[_: string], {}, string>(
        abi, '0x687510d6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    whitelists: new Func<[_: string, _: string], {}, boolean>(
        abi, '0x16b22e94'
    ),
}

export class Contract extends ContractBase {

    blacklists(arg0: string, arg1: string): Promise<boolean> {
        return this.eth_call(functions.blacklists, [arg0, arg1])
    }

    configs(arg0: string): Promise<([router: string, pair: string, limitAmount: bigint, amountPerBlock: bigint, limitTime: bigint, startBlock: bigint, disableBlock: bigint, preTransferTime: bigint] & {router: string, pair: string, limitAmount: bigint, amountPerBlock: bigint, limitTime: bigint, startBlock: bigint, disableBlock: bigint, preTransferTime: bigint})> {
        return this.eth_call(functions.configs, [arg0])
    }

    getCurrrentBlock(): Promise<bigint> {
        return this.eth_call(functions.getCurrrentBlock, [])
    }

    isConfigSet(arg0: string): Promise<boolean> {
        return this.eth_call(functions.isConfigSet, [arg0])
    }

    minBlockLimit(): Promise<bigint> {
        return this.eth_call(functions.minBlockLimit, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    token_owner(arg0: string): Promise<string> {
        return this.eth_call(functions.token_owner, [arg0])
    }

    whitelists(arg0: string, arg1: string): Promise<boolean> {
        return this.eth_call(functions.whitelists, [arg0, arg1])
    }
}
