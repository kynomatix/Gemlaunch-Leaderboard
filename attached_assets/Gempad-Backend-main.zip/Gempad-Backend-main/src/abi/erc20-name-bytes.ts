import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './erc20-name-bytes.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const functions = {
    name: new Func<[], {}, string>(
        abi, '0x06fdde03'
    ),
}

export class Contract extends ContractBase {

    name(): Promise<string> {
        return this.eth_call(functions.name, [])
    }
}
