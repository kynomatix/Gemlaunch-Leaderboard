import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './fairlaunch.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    Cancelled: new LogEvent<([Id: string, status: number, time: bigint] & {Id: string, status: number, time: bigint})>(
        abi, '0x678b187c15ead9db4b77ec501801aef56fb50972dd72220cc46a570a3a4e4ca3'
    ),
    Finalized: new LogEvent<([Id: string, finzlizeTime: bigint, status: number] & {Id: string, finzlizeTime: bigint, status: number})>(
        abi, '0x6a314f706983136e56fb80718294d65722af282cc5804f4eb28ae503cb529dc6'
    ),
    Initialized: new LogEvent<([version: number] & {version: number})>(
        abi, '0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    PublicSaleEnabled: new LogEvent<([id: string, time: bigint] & {id: string, time: bigint})>(
        abi, '0x1e8e6101440b5b2a6f0c6d8acd4de1b2aeed1ffdc69cf975600307b4b7d8b5c8'
    ),
    Purchased: new LogEvent<([id: string, sender: string, _amount: bigint] & {id: string, sender: string, _amount: bigint})>(
        abi, '0x3938ed494a2ac43205578f4190dcbdd61333ef5924e2db9ff8e6c3a204f840a6'
    ),
    RewardsCalimed: new LogEvent<([id: string, receiver: string, share: bigint] & {id: string, receiver: string, share: bigint})>(
        abi, '0x6f34c456d23677a6849f4cbaa263fd0beafa71d5fc974548d652936f1f4e4cf5'
    ),
    UpdateEndTime: new LogEvent<([id: string, timeNow: bigint, end: bigint] & {id: string, timeNow: bigint, end: bigint})>(
        abi, '0xc16974328ffcf9463697990f5485eb6b94d7c7b4f6128b76e646eb3560de8187'
    ),
    UpdateReward: new LogEvent<([id: string, reward: bigint, sender: string] & {id: string, reward: bigint, sender: string})>(
        abi, '0x927b04056419909f8447e9638542a08678274ee5324ec4d137520829298e93f2'
    ),
    UpdateTime: new LogEvent<([id: string, start: bigint, end: bigint] & {id: string, start: bigint, end: bigint})>(
        abi, '0xf80ef49d950f117083f540297f930bf980c275b4c11f784e0ab708289b3c5225'
    ),
    WhitelistUpdated: new LogEvent<([account: Array<string>, sender: string] & {account: Array<string>, sender: string})>(
        abi, '0x0c5a12c037597c1d2258bba4cf82c514e4e02fa76d7af223e59064e1d87e26aa'
    ),
    liquidityAdded: new LogEvent<([id: string, pair: string, liquidity: bigint] & {id: string, pair: string, liquidity: bigint})>(
        abi, '0x6b664bc3d1cb0e2df0092587ea712f1fe4aae5fe1acae3714deea67aa9aa0374'
    ),
}

export const functions = {
    Id: new Func<[], {}, bigint>(
        abi, '0x39a090c9'
    ),
    __GempadFairLaunch_init: new Func<[_id: bigint, info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _buyBack: ([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint}), _fundToken: string, _isPrivateMode: boolean, _feeReceiver: string, _owner: string], {_id: bigint, info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _buyBack: ([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint}), _fundToken: string, _isPrivateMode: boolean, _feeReceiver: string, _owner: string}, []>(
        abi, '0x3998c248'
    ),
    __ServicePayer_init: new Func<[receiver: string, serviceName: string], {receiver: string, serviceName: string}, []>(
        abi, '0xa35e3aec'
    ),
    addWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0xedac985b'
    ),
    buyBack: new Func<[], {}, ([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint})>(
        abi, '0xacdf4f18'
    ),
    buyBackTokens: new Func<[], {}, []>(
        abi, '0xd506d3fe'
    ),
    buyToken: new Func<[_amount: bigint, _referrer: string], {_amount: bigint, _referrer: string}, []>(
        abi, '0x9134709e'
    ),
    cancel: new Func<[], {}, []>(
        abi, '0xea8a1af0'
    ),
    claimReward: new Func<[], {}, []>(
        abi, '0xb88a802f'
    ),
    claimTokens: new Func<[], {}, []>(
        abi, '0x48c54b9d'
    ),
    claimUserRefund: new Func<[], {}, []>(
        abi, '0xa7e993eb'
    ),
    currentPrice: new Func<[], {}, bigint>(
        abi, '0x9d1b464a'
    ),
    currentStatus: new Func<[], {}, number>(
        abi, '0xef8a9235'
    ),
    enablePublicSale: new Func<[_startTime: bigint], {_startTime: bigint}, []>(
        abi, '0xcfed032a'
    ),
    finalize: new Func<[], {}, []>(
        abi, '0x4bb278f3'
    ),
    fundByTokens: new Func<[], {}, boolean>(
        abi, '0x00fed700'
    ),
    fundToken: new Func<[], {}, string>(
        abi, '0x50adcdb7'
    ),
    getAllInvestors: new Func<[], {}, Array<string>>(
        abi, '0xd0a2f2c4'
    ),
    getAllReferrers: new Func<[], {}, Array<string>>(
        abi, '0xb9a9f739'
    ),
    getCurrentMode: new Func<[], {}, number>(
        abi, '0x15370598'
    ),
    getCurrentStatus: new Func<[], {}, number>(
        abi, '0xa3dd2619'
    ),
    getUserTokens: new Func<[_user: string], {_user: string}, bigint>(
        abi, '0x519dc8d2'
    ),
    isInitialized: new Func<[], {}, boolean>(
        abi, '0x392e53cd'
    ),
    isWhitelisted: new Func<[_address: string], {_address: string}, boolean>(
        abi, '0x3af32abf'
    ),
    liquidity: new Func<[], {}, ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint})>(
        abi, '0x1a686502'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    pool: new Func<[], {}, ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint})>(
        abi, '0x16f0115b'
    ),
    remainingBuybackAmount: new Func<[], {}, bigint>(
        abi, '0x5a5a89e7'
    ),
    removeWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0x23245216'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    rewardInfo: new Func<[_: string], {}, ([referralInvest: bigint, rewardShare: bigint] & {referralInvest: bigint, rewardShare: bigint})>(
        abi, '0xcbecf6b5'
    ),
    setAffiliation: new Func<[_reward: bigint], {_reward: bigint}, []>(
        abi, '0x824f3473'
    ),
    setEndTime: new Func<[_endTime: bigint], {_endTime: bigint}, []>(
        abi, '0xccb98ffc'
    ),
    setTime: new Func<[_startTime: bigint, _endTime: bigint], {_startTime: bigint, _endTime: bigint}, []>(
        abi, '0xa0355eca'
    ),
    tokenFee: new Func<[], {}, bigint>(
        abi, '0x45599136'
    ),
    tokenToReceive: new Func<[], {}, bigint>(
        abi, '0x5c7440cc'
    ),
    totalClaimed: new Func<[], {}, bigint>(
        abi, '0xd54ad2a1'
    ),
    totalRaised: new Func<[], {}, bigint>(
        abi, '0xc5c4744c'
    ),
    totalReferralInvest: new Func<[], {}, bigint>(
        abi, '0xd18f0a69'
    ),
    totalReward: new Func<[], {}, bigint>(
        abi, '0x750142e6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    userInfo: new Func<[_: string], {}, ([userInvest: bigint, userCalimed: bigint] & {userInvest: bigint, userCalimed: bigint})>(
        abi, '0x1959a002'
    ),
}

export class Contract extends ContractBase {

    Id(): Promise<bigint> {
        return this.eth_call(functions.Id, [])
    }

    buyBack(): Promise<([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint})> {
        return this.eth_call(functions.buyBack, [])
    }

    currentPrice(): Promise<bigint> {
        return this.eth_call(functions.currentPrice, [])
    }

    currentStatus(): Promise<number> {
        return this.eth_call(functions.currentStatus, [])
    }

    fundByTokens(): Promise<boolean> {
        return this.eth_call(functions.fundByTokens, [])
    }

    fundToken(): Promise<string> {
        return this.eth_call(functions.fundToken, [])
    }

    getAllInvestors(): Promise<Array<string>> {
        return this.eth_call(functions.getAllInvestors, [])
    }

    getAllReferrers(): Promise<Array<string>> {
        return this.eth_call(functions.getAllReferrers, [])
    }

    getCurrentMode(): Promise<number> {
        return this.eth_call(functions.getCurrentMode, [])
    }

    getCurrentStatus(): Promise<number> {
        return this.eth_call(functions.getCurrentStatus, [])
    }

    isInitialized(): Promise<boolean> {
        return this.eth_call(functions.isInitialized, [])
    }

    isWhitelisted(_address: string): Promise<boolean> {
        return this.eth_call(functions.isWhitelisted, [_address])
    }

    liquidity(): Promise<([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint})> {
        return this.eth_call(functions.liquidity, [])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    pool(): Promise<([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint})> {
        return this.eth_call(functions.pool, [])
    }

    remainingBuybackAmount(): Promise<bigint> {
        return this.eth_call(functions.remainingBuybackAmount, [])
    }

    rewardInfo(arg0: string): Promise<([referralInvest: bigint, rewardShare: bigint] & {referralInvest: bigint, rewardShare: bigint})> {
        return this.eth_call(functions.rewardInfo, [arg0])
    }

    tokenFee(): Promise<bigint> {
        return this.eth_call(functions.tokenFee, [])
    }

    tokenToReceive(): Promise<bigint> {
        return this.eth_call(functions.tokenToReceive, [])
    }

    totalClaimed(): Promise<bigint> {
        return this.eth_call(functions.totalClaimed, [])
    }

    totalRaised(): Promise<bigint> {
        return this.eth_call(functions.totalRaised, [])
    }

    totalReferralInvest(): Promise<bigint> {
        return this.eth_call(functions.totalReferralInvest, [])
    }

    totalReward(): Promise<bigint> {
        return this.eth_call(functions.totalReward, [])
    }

    userInfo(arg0: string): Promise<([userInvest: bigint, userCalimed: bigint] & {userInvest: bigint, userCalimed: bigint})> {
        return this.eth_call(functions.userInfo, [arg0])
    }
}
