export const ABI_JSON = [
    {
        "type": "event",
        "anonymous": false,
        "name": "Cancelled",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Finalized",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "finzlizeTime",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Initialized",
        "inputs": [
            {
                "type": "uint8",
                "name": "version",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "PublicSaleEnabled",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "time",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Purchased",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "_amount",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "UpdateTime",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "start",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "end",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "WhitelistUpdated",
        "inputs": [
            {
                "type": "address[]",
                "name": "account"
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "liquidityAdded",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "pair",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "liquidity",
                "indexed": false
            }
        ]
    },
    {
        "type": "function",
        "name": "Id",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "__GempadSubscriptionPool_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_id"
            },
            {
                "type": "tuple",
                "name": "info",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "userHardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "sellRate"
                    },
                    {
                        "type": "uint256",
                        "name": "listingRate"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_liquidity",
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    }
                ]
            },
            {
                "type": "address",
                "name": "_fundToken"
            },
            {
                "type": "bool",
                "name": "_isPrivateMode"
            },
            {
                "type": "bool",
                "name": "_isRefund"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            },
            {
                "type": "address",
                "name": "_owner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "__ServicePayer_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "address",
                "name": "receiver"
            },
            {
                "type": "string",
                "name": "serviceName"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "addWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "buyToken",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_amount"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "calculateShare",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_totalTokens"
            },
            {
                "type": "uint256",
                "name": "_totalFunds"
            },
            {
                "type": "address[]",
                "name": "_contributors"
            },
            {
                "type": "uint256[]",
                "name": "_amounts"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "canCalculate",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "canFinalize",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "cancel",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimTokens",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimUserRefund",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "currentStatus",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "enablePublicSale",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_startTime"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "finalize",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "fundByTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "fundToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllInvestors",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentMode",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "mode"
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentStatus",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "status"
            }
        ]
    },
    {
        "type": "function",
        "name": "getDistribution",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            },
            {
                "type": "uint256",
                "name": ""
            },
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getSurplusData",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "tuple",
                "name": "",
                "components": [
                    {
                        "type": "uint256",
                        "name": "totalAllocated"
                    },
                    {
                        "type": "uint256",
                        "name": "surplusTokens"
                    },
                    {
                        "type": "uint256",
                        "name": "totalSurplusFunds"
                    },
                    {
                        "type": "address[]",
                        "name": "leftInvestors"
                    },
                    {
                        "type": "uint256[]",
                        "name": "amounts"
                    }
                ]
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserRemainingFunds",
        "constant": true,
        "stateMutability": "pure",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "isInitialized",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "isWhitelisted",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_address"
            }
        ],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "liquidity",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": "router"
            },
            {
                "type": "uint256",
                "name": "liquidityPercent"
            },
            {
                "type": "uint256",
                "name": "lockTime"
            },
            {
                "type": "address",
                "name": "locker"
            },
            {
                "type": "uint256",
                "name": "liquidityAdded"
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "pool",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "uint256",
                "name": "hardCap"
            },
            {
                "type": "uint256",
                "name": "softCap"
            },
            {
                "type": "uint256",
                "name": "userHardCap"
            },
            {
                "type": "uint256",
                "name": "sellRate"
            },
            {
                "type": "uint256",
                "name": "listingRate"
            },
            {
                "type": "uint256",
                "name": "startTime"
            },
            {
                "type": "uint256",
                "name": "endTime"
            },
            {
                "type": "uint256",
                "name": "finalizeTime"
            },
            {
                "type": "uint256",
                "name": "publicSaleTime"
            }
        ]
    },
    {
        "type": "function",
        "name": "removeWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "setTime",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_startTime"
            },
            {
                "type": "uint256",
                "name": "_endTime"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "totalClaimed",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalContribution",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalRaised",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "updateCalculation",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_contributors"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            },
            {
                "type": "uint256",
                "name": ""
            },
            {
                "type": "address[]",
                "name": ""
            },
            {
                "type": "uint256[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "userInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": "userInvest"
            },
            {
                "type": "uint256",
                "name": "userDeposit"
            },
            {
                "type": "uint256",
                "name": "userAllocation"
            },
            {
                "type": "uint256",
                "name": "userClaimed"
            }
        ]
    }
]
