export const ABI_JSON = [
    {
        "type": "constructor",
        "stateMutability": "undefined",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_initBlueprint"
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "FairLaunchCreated",
        "inputs": [
            {
                "type": "address",
                "name": "id",
                "indexed": false
            },
            {
                "type": "tuple",
                "name": "_info",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "totalsellTokens"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "bool",
                        "name": "isMaxLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    },
                    {
                        "type": "bool",
                        "name": "isAffiliate"
                    },
                    {
                        "type": "uint256",
                        "name": "affiliateReward"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "liq",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    }
                ]
            },
            {
                "type": "address",
                "name": "fairLaunch",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "function",
        "name": "IdCounter",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "createFairLaunch",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "tuple",
                "name": "_info",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "totalsellTokens"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "bool",
                        "name": "isMaxLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    },
                    {
                        "type": "bool",
                        "name": "isAffiliate"
                    },
                    {
                        "type": "uint256",
                        "name": "affiliateReward"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_liquidity",
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_buyBack",
                "components": [
                    {
                        "type": "bool",
                        "name": "isBuyback"
                    },
                    {
                        "type": "uint256",
                        "name": "buyBackPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "totalBuyBackAmount"
                    },
                    {
                        "type": "uint256",
                        "name": "boughtBackAmount"
                    },
                    {
                        "type": "uint256",
                        "name": "amountPerBuyback"
                    },
                    {
                        "type": "uint256",
                        "name": "minDelay"
                    },
                    {
                        "type": "uint256",
                        "name": "maxDelay"
                    },
                    {
                        "type": "uint256",
                        "name": "lastBuyTime"
                    }
                ]
            },
            {
                "type": "address",
                "name": "_fundToken"
            },
            {
                "type": "bool",
                "name": "_isprivateSale"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "fairLaunches",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllFairLaunches",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getFairLaunchBeacon",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getImplementation",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserFairLaunche",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    }
]
