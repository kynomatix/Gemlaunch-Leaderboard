import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './fairlaunch-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    FairLaunchCreated: new LogEvent<([id: string, _info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), fairLaunch: string] & {id: string, _info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), fairLaunch: string})>(
        abi, '0xe1936dedc5dbb4494524e388dd3750bf3e071574556789b5e96ffcdbcecde433'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
}

export const functions = {
    IdCounter: new Func<[], {}, bigint>(
        abi, '0xae227ad4'
    ),
    createFairLaunch: new Func<[_info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _buyBack: ([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint}), _fundToken: string, _isprivateSale: boolean, _feeReceiver: string], {_info: ([token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint] & {token: string, totalsellTokens: bigint, softCap: bigint, isMaxLimit: boolean, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint, isAffiliate: boolean, affiliateReward: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _buyBack: ([isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint] & {isBuyback: boolean, buyBackPercent: bigint, totalBuyBackAmount: bigint, boughtBackAmount: bigint, amountPerBuyback: bigint, minDelay: bigint, maxDelay: bigint, lastBuyTime: bigint}), _fundToken: string, _isprivateSale: boolean, _feeReceiver: string}, []>(
        abi, '0x01b86d5c'
    ),
    fairLaunches: new Func<[_: bigint], {}, string>(
        abi, '0xf3c2d011'
    ),
    getAllFairLaunches: new Func<[], {}, Array<string>>(
        abi, '0x303eddb6'
    ),
    getFairLaunchBeacon: new Func<[], {}, string>(
        abi, '0xd3edc882'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getUserFairLaunche: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0x4268069e'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    IdCounter(): Promise<bigint> {
        return this.eth_call(functions.IdCounter, [])
    }

    fairLaunches(arg0: bigint): Promise<string> {
        return this.eth_call(functions.fairLaunches, [arg0])
    }

    getAllFairLaunches(): Promise<Array<string>> {
        return this.eth_call(functions.getAllFairLaunches, [])
    }

    getFairLaunchBeacon(): Promise<string> {
        return this.eth_call(functions.getFairLaunchBeacon, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getUserFairLaunche(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserFairLaunche, [_user])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
