export const ABI_JSON = [
    {
        "type": "event",
        "anonymous": false,
        "name": "Cancelled",
        "inputs": [
            {
                "type": "address",
                "name": "id",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "time",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "ClaimTimeUpdate",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "time",
                "indexed": false
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Finalized",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "finzlizeTime",
                "indexed": false
            },
            {
                "type": "uint8",
                "name": "status",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Initialized",
        "inputs": [
            {
                "type": "uint8",
                "name": "version",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "PublicSaleEnabled",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "time",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Purchased",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "_amount",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "amount",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "RewardsCalimed",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "receiver",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "share",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "Transfer",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "receiver",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "token",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "UpdateReward",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "reward",
                "indexed": false
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "UpdateTime",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "start",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "end",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "WhitelistUpdated",
        "inputs": [
            {
                "type": "address[]",
                "name": "account"
            },
            {
                "type": "address",
                "name": "sender",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "liquidityAdded",
        "inputs": [
            {
                "type": "address",
                "name": "Id",
                "indexed": false
            },
            {
                "type": "address",
                "name": "pair",
                "indexed": false
            },
            {
                "type": "uint256",
                "name": "liquidity",
                "indexed": false
            }
        ]
    },
    {
        "type": "function",
        "name": "Id",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "__GempadLaunchpad_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_id"
            },
            {
                "type": "tuple",
                "name": "info",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "sellPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "listingPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_liquidity",
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    },
                    {
                        "type": "bool",
                        "name": "isAutolisting"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_vesting",
                "components": [
                    {
                        "type": "bool",
                        "name": "isVestingEnable"
                    },
                    {
                        "type": "uint256",
                        "name": "TGEPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "address",
                "name": "_fundToken"
            },
            {
                "type": "bool",
                "name": "_isPrivateMode"
            },
            {
                "type": "bool",
                "name": "_isAffiliate"
            },
            {
                "type": "uint256",
                "name": "_affiliateReward"
            },
            {
                "type": "bool",
                "name": "_refundType"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            },
            {
                "type": "address",
                "name": "_owner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "__ServicePayer_init",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "address",
                "name": "receiver"
            },
            {
                "type": "string",
                "name": "serviceName"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "addWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "affiliateReward",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "buyToken",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "uint256",
                "name": "_amount"
            },
            {
                "type": "address",
                "name": "_referrer"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "cancel",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimReward",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimTime",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "claimTokens",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimUserRefund",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "claimableTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "currentStatus",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "enablePublicSale",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_startTime"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "finalize",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "fundByTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "fundToken",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllInvestors",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllReferrers",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentMode",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "mode"
            }
        ]
    },
    {
        "type": "function",
        "name": "getCurrentStatus",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint8",
                "name": "status"
            }
        ]
    },
    {
        "type": "function",
        "name": "getTotalSaleTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getTotalTokensSold",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserRemainingClaimable",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserTokens",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "isAffiliate",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "isWhitelisted",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_address"
            }
        ],
        "outputs": [
            {
                "type": "bool",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "liquidity",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": "router"
            },
            {
                "type": "uint256",
                "name": "liquidityPercent"
            },
            {
                "type": "uint256",
                "name": "lockTime"
            },
            {
                "type": "address",
                "name": "locker"
            },
            {
                "type": "uint256",
                "name": "liquidityAdded"
            },
            {
                "type": "bool",
                "name": "isAutolisting"
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "pool",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": "token"
            },
            {
                "type": "uint256",
                "name": "sellPrice"
            },
            {
                "type": "uint256",
                "name": "listingPrice"
            },
            {
                "type": "uint256",
                "name": "softCap"
            },
            {
                "type": "uint256",
                "name": "hardCap"
            },
            {
                "type": "uint256",
                "name": "minBuyLimit"
            },
            {
                "type": "uint256",
                "name": "maxBuyLimit"
            },
            {
                "type": "uint256",
                "name": "startTime"
            },
            {
                "type": "uint256",
                "name": "endTime"
            },
            {
                "type": "uint256",
                "name": "finalizeTime"
            },
            {
                "type": "uint256",
                "name": "publicSaleTime"
            }
        ]
    },
    {
        "type": "function",
        "name": "removeWhitelist",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address[]",
                "name": "_participants"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "rewardInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": "referralInvest"
            },
            {
                "type": "uint256",
                "name": "rewardShare"
            }
        ]
    },
    {
        "type": "function",
        "name": "setAffiliation",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_reward"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "setClaimTime",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_time"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "setTime",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": "_startTime"
            },
            {
                "type": "uint256",
                "name": "_endTime"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "tokenFee",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalClaimed",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalRaised",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "totalReferralInvest",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "userInfo",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "uint256",
                "name": "userInvest"
            },
            {
                "type": "uint256",
                "name": "userCalimed"
            },
            {
                "type": "uint256",
                "name": "lastClaimTime"
            },
            {
                "type": "uint256",
                "name": "intervalClaimed"
            }
        ]
    },
    {
        "type": "function",
        "name": "vesting",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "bool",
                "name": "isVestingEnable"
            },
            {
                "type": "uint256",
                "name": "TGEPercent"
            },
            {
                "type": "uint256",
                "name": "cyclePercent"
            },
            {
                "type": "uint256",
                "name": "cycleInterval"
            }
        ]
    },
    {
        "type": "function",
        "name": "withdrawTokens",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    }
]
