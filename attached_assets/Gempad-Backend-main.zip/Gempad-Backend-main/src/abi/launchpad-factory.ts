import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './launchpad-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    LaunchpadCreated: new LogEvent<([id: string, info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), isprivateSale: boolean, launchpad: string, refundType: boolean] & {id: string, info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), isprivateSale: boolean, launchpad: string, refundType: boolean})>(
        abi, '0xdc5b9b7889cc24cf28a2bc496a5347272f7c83a32692e21c271470e355210baf'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
}

export const functions = {
    IdCounter: new Func<[], {}, bigint>(
        abi, '0xae227ad4'
    ),
    createLaunchpad: new Func<[_info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isprivateSale: boolean, _isAffiliate: boolean, _affiliateReward: bigint, _refundType: boolean, _feeReceiver: string], {_info: ([token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, sellPrice: bigint, listingPrice: bigint, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint, isAutolisting: boolean}), _vesting: ([isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint] & {isVestingEnable: boolean, TGEPercent: bigint, cyclePercent: bigint, cycleInterval: bigint}), _fundToken: string, _isprivateSale: boolean, _isAffiliate: boolean, _affiliateReward: bigint, _refundType: boolean, _feeReceiver: string}, []>(
        abi, '0x82f340f3'
    ),
    getAllLaunchpads: new Func<[], {}, Array<string>>(
        abi, '0x7c0bb6b7'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getLaunchpadBeacon: new Func<[], {}, string>(
        abi, '0xd9203fb5'
    ),
    getUserLaunchpads: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0xd551d85a'
    ),
    launchpads: new Func<[_: bigint], {}, string>(
        abi, '0x5be5f0bc'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    IdCounter(): Promise<bigint> {
        return this.eth_call(functions.IdCounter, [])
    }

    getAllLaunchpads(): Promise<Array<string>> {
        return this.eth_call(functions.getAllLaunchpads, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getLaunchpadBeacon(): Promise<string> {
        return this.eth_call(functions.getLaunchpadBeacon, [])
    }

    getUserLaunchpads(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserLaunchpads, [_user])
    }

    launchpads(arg0: bigint): Promise<string> {
        return this.eth_call(functions.launchpads, [arg0])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
