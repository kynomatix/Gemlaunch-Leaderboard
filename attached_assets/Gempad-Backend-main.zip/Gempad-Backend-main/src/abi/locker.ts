import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './locker.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    LockAdded: new LogEvent<([id: bigint, token: string, owner: string, amount: bigint, isLpToken: boolean, unlockDate: bigint] & {id: bigint, token: string, owner: string, amount: bigint, isLpToken: boolean, unlockDate: bigint})>(
        abi, '0x53be666cbfb8bd2ec48b986c2c92b6fcd7499123fb01befafa2b1cf955b6a410'
    ),
    LockDescriptionChanged: new LogEvent<([lockId: bigint] & {lockId: bigint})>(
        abi, '0xe4a1120fd509c50aec65802fd3c3c9a4b72bf746fe9a552396185c6de928e8aa'
    ),
    LockOwnerChanged: new LogEvent<([lockId: bigint, owner: string, newOwner: string] & {lockId: bigint, owner: string, newOwner: string})>(
        abi, '0x9075ad040756c0d8743a1fed927066a92c4755071615bf61e04b17583d961caf'
    ),
    LockRemoved: new LogEvent<([id: bigint, token: string, owner: string, amount: bigint, unlockedAt: bigint] & {id: bigint, token: string, owner: string, amount: bigint, unlockedAt: bigint})>(
        abi, '0xc6532367992b32e42a62dd89fc3574876d97d081a263aa6e030f34b79b7e6e8b'
    ),
    LockUpdated: new LogEvent<([id: bigint, token: string, owner: string, newAmount: bigint, newUnlockDate: bigint] & {id: bigint, token: string, owner: string, newAmount: bigint, newUnlockDate: bigint})>(
        abi, '0xa8b26360df8d5e154ffa5a8a7e894e85f781acfbbef0b744fb9551d8fd0fd36c'
    ),
    LockVested: new LogEvent<([id: bigint, token: string, owner: string, amount: bigint, total: bigint, timestamp: bigint] & {id: bigint, token: string, owner: string, amount: bigint, total: bigint, timestamp: bigint})>(
        abi, '0xf93385ffdf40b698b13993c059834b8e91d0ca8e7abf827a34001ca03c03f6ff'
    ),
    Paused: new LogEvent<([account: string] & {account: string})>(
        abi, '0x62e78cea01bee320cd4e420270b5ea74000d11b0c9f74754ebdbfc544b05a258'
    ),
    Unpaused: new LogEvent<([account: string] & {account: string})>(
        abi, '0x5db9ee0a495bf2e6ff9c91a7834c1ba4fdd244a5e8aa4e537bd38aeae4b073aa'
    ),
    VestingLockAdded: new LogEvent<([id: bigint, token: string, owner: string, amount: bigint, isLpToken: boolean, TGE: bigint, cycleShare: bigint, interval: bigint, unlockDate: bigint] & {id: bigint, token: string, owner: string, amount: bigint, isLpToken: boolean, TGE: bigint, cycleShare: bigint, interval: bigint, unlockDate: bigint})>(
        abi, '0xa77f49d096fc35f7cae72a05466791d7a2997798145fa68fb631c5f4de79854a'
    ),
}

export const functions = {
    allLpTokenLockedCount: new Func<[], {}, bigint>(
        abi, '0xb982922e'
    ),
    allNormalTokenLockedCount: new Func<[], {}, bigint>(
        abi, '0x475831c8'
    ),
    cumulativeLockInfo: new Func<[_: string], {}, ([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>(
        abi, '0xe1444fd6'
    ),
    editLock: new Func<[lockId: bigint, newAmount: bigint, newUnlockDate: bigint], {lockId: bigint, newAmount: bigint, newUnlockDate: bigint}, []>(
        abi, '0xb3b9aa48'
    ),
    editLockDescription: new Func<[lockId: bigint, description: string], {lockId: bigint, description: string}, []>(
        abi, '0xd3cac885'
    ),
    getCumulativeLpTokenLockInfo: new Func<[start: bigint, end: bigint], {start: bigint, end: bigint}, Array<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>>(
        abi, '0xaec640c6'
    ),
    getCumulativeLpTokenLockInfoAt: new Func<[index: bigint], {index: bigint}, ([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>(
        abi, '0xa20b8c18'
    ),
    getCumulativeNormalTokenLockInfo: new Func<[start: bigint, end: bigint], {start: bigint, end: bigint}, Array<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>>(
        abi, '0x76c12822'
    ),
    getCumulativeNormalTokenLockInfoAt: new Func<[index: bigint], {index: bigint}, ([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>(
        abi, '0x7e6706d3'
    ),
    getLockAt: new Func<[index: bigint], {index: bigint}, ([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>(
        abi, '0x0d4f581a'
    ),
    getLockById: new Func<[lockId: bigint], {lockId: bigint}, ([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>(
        abi, '0x08f12470'
    ),
    getLocksForToken: new Func<[token: string, start: bigint, end: bigint], {token: string, start: bigint, end: bigint}, Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>>(
        abi, '0x332f26d7'
    ),
    getTotalLockCount: new Func<[], {}, bigint>(
        abi, '0xfd981c66'
    ),
    lock: new Func<[owner: string, token: string, isLpToken: boolean, amount: bigint, unlockDate: bigint, description: string], {owner: string, token: string, isLpToken: boolean, amount: bigint, unlockDate: bigint, description: string}, bigint>(
        abi, '0x07279357'
    ),
    lpLockCountForUser: new Func<[user: string], {user: string}, bigint>(
        abi, '0x07873ef1'
    ),
    lpLockForUserAtIndex: new Func<[user: string, index: bigint], {user: string, index: bigint}, ([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>(
        abi, '0xeeacf786'
    ),
    lpLocksForUser: new Func<[user: string], {user: string}, Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>>(
        abi, '0xaef0e540'
    ),
    multipleVestingLock: new Func<[owners: Array<string>, amounts: Array<bigint>, token: string, isLpToken: boolean, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, description: string], {owners: Array<string>, amounts: Array<bigint>, token: string, isLpToken: boolean, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, description: string}, Array<bigint>>(
        abi, '0xe0da83ce'
    ),
    normalLockCountForUser: new Func<[user: string], {user: string}, bigint>(
        abi, '0xeb80bdae'
    ),
    normalLockForUserAtIndex: new Func<[user: string, index: bigint], {user: string, index: bigint}, ([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>(
        abi, '0x618df7a3'
    ),
    normalLocksForUser: new Func<[user: string], {user: string}, Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>>(
        abi, '0xda1d8cff'
    ),
    paused: new Func<[], {}, boolean>(
        abi, '0x5c975abb'
    ),
    renounceLockOwnership: new Func<[lockId: bigint], {lockId: bigint}, []>(
        abi, '0xa57e3141'
    ),
    totalLockCountForToken: new Func<[token: string], {token: string}, bigint>(
        abi, '0xe3676f88'
    ),
    totalLockCountForUser: new Func<[user: string], {user: string}, bigint>(
        abi, '0xcd83eadc'
    ),
    totalTokenLockedCount: new Func<[], {}, bigint>(
        abi, '0x1982242c'
    ),
    transferLockOwnership: new Func<[lockId: bigint, newOwner: string], {lockId: bigint, newOwner: string}, []>(
        abi, '0x5a04fb69'
    ),
    unlock: new Func<[lockId: bigint], {lockId: bigint}, []>(
        abi, '0x6198e339'
    ),
    vestingLock: new Func<[owner: string, token: string, isLpToken: boolean, amount: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, description: string], {owner: string, token: string, isLpToken: boolean, amount: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, description: string}, bigint>(
        abi, '0xcb645e32'
    ),
    withdrawableTokens: new Func<[lockId: bigint], {lockId: bigint}, bigint>(
        abi, '0x6dbdeab3'
    ),
}

export class Contract extends ContractBase {

    allLpTokenLockedCount(): Promise<bigint> {
        return this.eth_call(functions.allLpTokenLockedCount, [])
    }

    allNormalTokenLockedCount(): Promise<bigint> {
        return this.eth_call(functions.allNormalTokenLockedCount, [])
    }

    cumulativeLockInfo(arg0: string): Promise<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})> {
        return this.eth_call(functions.cumulativeLockInfo, [arg0])
    }

    getCumulativeLpTokenLockInfo(start: bigint, end: bigint): Promise<Array<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>> {
        return this.eth_call(functions.getCumulativeLpTokenLockInfo, [start, end])
    }

    getCumulativeLpTokenLockInfoAt(index: bigint): Promise<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})> {
        return this.eth_call(functions.getCumulativeLpTokenLockInfoAt, [index])
    }

    getCumulativeNormalTokenLockInfo(start: bigint, end: bigint): Promise<Array<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})>> {
        return this.eth_call(functions.getCumulativeNormalTokenLockInfo, [start, end])
    }

    getCumulativeNormalTokenLockInfoAt(index: bigint): Promise<([token: string, factory: string, amount: bigint] & {token: string, factory: string, amount: bigint})> {
        return this.eth_call(functions.getCumulativeNormalTokenLockInfoAt, [index])
    }

    getLockAt(index: bigint): Promise<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})> {
        return this.eth_call(functions.getLockAt, [index])
    }

    getLockById(lockId: bigint): Promise<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})> {
        return this.eth_call(functions.getLockById, [lockId])
    }

    getLocksForToken(token: string, start: bigint, end: bigint): Promise<Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>> {
        return this.eth_call(functions.getLocksForToken, [token, start, end])
    }

    getTotalLockCount(): Promise<bigint> {
        return this.eth_call(functions.getTotalLockCount, [])
    }

    lpLockCountForUser(user: string): Promise<bigint> {
        return this.eth_call(functions.lpLockCountForUser, [user])
    }

    lpLockForUserAtIndex(user: string, index: bigint): Promise<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})> {
        return this.eth_call(functions.lpLockForUserAtIndex, [user, index])
    }

    lpLocksForUser(user: string): Promise<Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>> {
        return this.eth_call(functions.lpLocksForUser, [user])
    }

    normalLockCountForUser(user: string): Promise<bigint> {
        return this.eth_call(functions.normalLockCountForUser, [user])
    }

    normalLockForUserAtIndex(user: string, index: bigint): Promise<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})> {
        return this.eth_call(functions.normalLockForUserAtIndex, [user, index])
    }

    normalLocksForUser(user: string): Promise<Array<([id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string] & {id: bigint, token: string, owner: string, amount: bigint, lockDate: bigint, tgeDate: bigint, tgeBps: bigint, cycle: bigint, cycleBps: bigint, unlockedAmount: bigint, description: string})>> {
        return this.eth_call(functions.normalLocksForUser, [user])
    }

    paused(): Promise<boolean> {
        return this.eth_call(functions.paused, [])
    }

    totalLockCountForToken(token: string): Promise<bigint> {
        return this.eth_call(functions.totalLockCountForToken, [token])
    }

    totalLockCountForUser(user: string): Promise<bigint> {
        return this.eth_call(functions.totalLockCountForUser, [user])
    }

    totalTokenLockedCount(): Promise<bigint> {
        return this.eth_call(functions.totalTokenLockedCount, [])
    }

    withdrawableTokens(lockId: bigint): Promise<bigint> {
        return this.eth_call(functions.withdrawableTokens, [lockId])
    }
}
