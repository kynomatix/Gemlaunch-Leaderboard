export const ABI_JSON = [
    {
        "type": "constructor",
        "stateMutability": "undefined",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_initBlueprint"
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "PrivateSaleCreated",
        "inputs": [
            {
                "type": "uint256",
                "name": "id",
                "indexed": false
            },
            {
                "type": "tuple",
                "name": "info",
                "indexed": false,
                "components": [
                    {
                        "type": "string",
                        "name": "name"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "vesting",
                "indexed": false,
                "components": [
                    {
                        "type": "uint256",
                        "name": "initialRelease"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "uint8",
                "name": "mode",
                "indexed": false
            },
            {
                "type": "address",
                "name": "fundToken",
                "indexed": false
            },
            {
                "type": "address",
                "name": "privateSale",
                "indexed": false
            }
        ]
    },
    {
        "type": "function",
        "name": "IdCounter",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "createPrivateSale",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "tuple",
                "name": "info",
                "components": [
                    {
                        "type": "string",
                        "name": "name"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_vesting",
                "components": [
                    {
                        "type": "uint256",
                        "name": "initialRelease"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "uint8",
                "name": "mode"
            },
            {
                "type": "address",
                "name": "feeReceiver"
            },
            {
                "type": "address",
                "name": "fundToken"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "getAllPrivateSales",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getImplementation",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getPrivateSaleBeacon",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserPrivateSales",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    }
]
