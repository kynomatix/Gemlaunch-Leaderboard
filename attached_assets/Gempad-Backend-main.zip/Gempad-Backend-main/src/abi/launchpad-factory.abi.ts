export const ABI_JSON = [
    {
        "type": "constructor",
        "stateMutability": "undefined",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_initBlueprint"
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "LaunchpadCreated",
        "inputs": [
            {
                "type": "address",
                "name": "id",
                "indexed": false
            },
            {
                "type": "tuple",
                "name": "info",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "sellPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "listingPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "liq",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    },
                    {
                        "type": "bool",
                        "name": "isAutolisting"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "vesting",
                "indexed": false,
                "components": [
                    {
                        "type": "bool",
                        "name": "isVestingEnable"
                    },
                    {
                        "type": "uint256",
                        "name": "TGEPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "bool",
                "name": "isprivateSale",
                "indexed": false
            },
            {
                "type": "address",
                "name": "launchpad",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "refundType",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "function",
        "name": "IdCounter",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "createLaunchpad",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "tuple",
                "name": "_info",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "sellPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "listingPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_liquidity",
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    },
                    {
                        "type": "bool",
                        "name": "isAutolisting"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_vesting",
                "components": [
                    {
                        "type": "bool",
                        "name": "isVestingEnable"
                    },
                    {
                        "type": "uint256",
                        "name": "TGEPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "address",
                "name": "_fundToken"
            },
            {
                "type": "bool",
                "name": "_isprivateSale"
            },
            {
                "type": "bool",
                "name": "_isAffiliate"
            },
            {
                "type": "uint256",
                "name": "_affiliateReward"
            },
            {
                "type": "bool",
                "name": "_refundType"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "getAllLaunchpads",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getImplementation",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getLaunchpadBeacon",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserLaunchpads",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "launchpads",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    }
]
