export const ABI_JSON = [
    {
        "type": "constructor",
        "stateMutability": "undefined",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_initBlueprint"
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "DutchAuctionCreated",
        "inputs": [
            {
                "type": "address",
                "name": "id",
                "indexed": false
            },
            {
                "type": "tuple",
                "name": "info",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "totalSaleAmount"
                    },
                    {
                        "type": "uint256",
                        "name": "startPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "endPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    },
                    {
                        "type": "uint256",
                        "name": "decreaseInterval"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "",
                "indexed": false,
                "components": [
                    {
                        "type": "bool",
                        "name": "isVestingEnable"
                    },
                    {
                        "type": "uint256",
                        "name": "TGEPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "liq",
                "indexed": false,
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    }
                ]
            },
            {
                "type": "address",
                "name": "dutchAuction",
                "indexed": false
            },
            {
                "type": "bool",
                "name": "refundType",
                "indexed": false
            }
        ]
    },
    {
        "type": "event",
        "anonymous": false,
        "name": "OwnershipTransferred",
        "inputs": [
            {
                "type": "address",
                "name": "previousOwner",
                "indexed": true
            },
            {
                "type": "address",
                "name": "newOwner",
                "indexed": true
            }
        ]
    },
    {
        "type": "function",
        "name": "IdCounter",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "createDutchAuction",
        "constant": false,
        "stateMutability": "payable",
        "payable": true,
        "inputs": [
            {
                "type": "tuple",
                "name": "info",
                "components": [
                    {
                        "type": "address",
                        "name": "token"
                    },
                    {
                        "type": "uint256",
                        "name": "totalSaleAmount"
                    },
                    {
                        "type": "uint256",
                        "name": "startPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "endPrice"
                    },
                    {
                        "type": "uint256",
                        "name": "softCap"
                    },
                    {
                        "type": "uint256",
                        "name": "hardCap"
                    },
                    {
                        "type": "uint256",
                        "name": "minBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "maxBuyLimit"
                    },
                    {
                        "type": "uint256",
                        "name": "startTime"
                    },
                    {
                        "type": "uint256",
                        "name": "endTime"
                    },
                    {
                        "type": "uint256",
                        "name": "finalizeTime"
                    },
                    {
                        "type": "uint256",
                        "name": "publicSaleTime"
                    },
                    {
                        "type": "uint256",
                        "name": "decreaseInterval"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_liquidity",
                "components": [
                    {
                        "type": "address",
                        "name": "router"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "lockTime"
                    },
                    {
                        "type": "address",
                        "name": "locker"
                    },
                    {
                        "type": "uint256",
                        "name": "liquidityAdded"
                    }
                ]
            },
            {
                "type": "tuple",
                "name": "_vesting",
                "components": [
                    {
                        "type": "bool",
                        "name": "isVestingEnable"
                    },
                    {
                        "type": "uint256",
                        "name": "TGEPercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cyclePercent"
                    },
                    {
                        "type": "uint256",
                        "name": "cycleInterval"
                    }
                ]
            },
            {
                "type": "address",
                "name": "_fundToken"
            },
            {
                "type": "bool",
                "name": "_isPrivateMode"
            },
            {
                "type": "bool",
                "name": "_refundType"
            },
            {
                "type": "address",
                "name": "_feeReceiver"
            }
        ],
        "outputs": []
    },
    {
        "type": "function",
        "name": "dutchAuctions",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "uint256",
                "name": ""
            }
        ],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getAllDutchAuctions",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getDutchAuction",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getImplementation",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "getUserDutchAuctions",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "_user"
            }
        ],
        "outputs": [
            {
                "type": "address[]",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "owner",
        "constant": true,
        "stateMutability": "view",
        "payable": false,
        "inputs": [],
        "outputs": [
            {
                "type": "address",
                "name": ""
            }
        ]
    },
    {
        "type": "function",
        "name": "renounceOwnership",
        "constant": false,
        "payable": false,
        "inputs": [],
        "outputs": []
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "constant": false,
        "payable": false,
        "inputs": [
            {
                "type": "address",
                "name": "newOwner"
            }
        ],
        "outputs": []
    }
]
