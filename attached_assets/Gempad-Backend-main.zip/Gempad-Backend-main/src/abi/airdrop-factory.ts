import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './airdrop-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    GempadAirdropCreated: new LogEvent<([id: bigint, token: string, name: string, airdrop: string] & {id: bigint, token: string, name: string, airdrop: string})>(
        abi, '0xd3fcf5a9308f038c166d4013ff49f5b46619fe6de1b2f7766e994fab2b443887'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
}

export const functions = {
    createGempadAirdrop: new Func<[_tokenAddress: string, _airdropName: string, _feeReceiver: string], {_tokenAddress: string, _airdropName: string, _feeReceiver: string}, []>(
        abi, '0xf20b30bd'
    ),
    getAllGempadAirdrop: new Func<[], {}, Array<string>>(
        abi, '0x6ad9f822'
    ),
    getGempadAirdropBeacon: new Func<[], {}, string>(
        abi, '0x7d52009a'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getUserAirdrop: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0xa5cbb928'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    getAllGempadAirdrop(): Promise<Array<string>> {
        return this.eth_call(functions.getAllGempadAirdrop, [])
    }

    getGempadAirdropBeacon(): Promise<string> {
        return this.eth_call(functions.getGempadAirdropBeacon, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getUserAirdrop(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserAirdrop, [_user])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }
}
