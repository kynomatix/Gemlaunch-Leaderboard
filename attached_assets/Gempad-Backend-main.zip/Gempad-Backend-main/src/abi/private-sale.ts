import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './private-sale.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    AntibotInfoAdded: new LogEvent<([Id: bigint, mode: number, token: string, amount: bigint] & {Id: bigint, mode: number, token: string, amount: bigint})>(
        abi, '0x9f79b558c48e3206ce26a87c94cb9647069ede691bf7210539ad0277725f4d49'
    ),
    Cancelled: new LogEvent<([Id: bigint, status: number] & {Id: bigint, status: number})>(
        abi, '0xf8f7fcba8ab018b753ab5098154d39a8ef2b120fbc02282664dfa97c900d7367'
    ),
    Finalized: new LogEvent<([Id: bigint, status: number, finalizeTime: bigint] & {Id: bigint, status: number, finalizeTime: bigint})>(
        abi, '0xa757a7780d9d2b6eb77cea8d062295b54ad43f504fc5e0aaf4d7547a3fcc9d43'
    ),
    FundsDeposited: new LogEvent<([Id: bigint, sender: string, amount: bigint] & {Id: bigint, sender: string, amount: bigint})>(
        abi, '0xe030e47e27825a2ad1b19e4cf2e70bfbfb3124af275c7727a82b114ba7b29a85'
    ),
    Initialized: new LogEvent<([version: number] & {version: number})>(
        abi, '0x7f26b83ff96e1f2b6a682f133852f6798a09c465da95921460cefb3847402498'
    ),
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    PublicSaleEnabled: new LogEvent<([Id: bigint, saleTime: bigint] & {Id: bigint, saleTime: bigint})>(
        abi, '0x1b00aa34af117b63885012db1060a3aad14e052462daab8ac939c370978206c1'
    ),
    WhitelistAdded: new LogEvent<([account: Array<string>, sender: string, status: boolean] & {account: Array<string>, sender: string, status: boolean})>(
        abi, '0x92b68c43a67d2449c108d21b7c3e8174f313ac035c4a25d4f7e73014a997e112'
    ),
    WhitelistRemoved: new LogEvent<([account: Array<string>, sender: string, status: boolean] & {account: Array<string>, sender: string, status: boolean})>(
        abi, '0x5f73122530c9d932562efb7c9f756fe263892584da8517a3f959e1852affe85f'
    ),
}

export const functions = {
    Id: new Func<[], {}, bigint>(
        abi, '0x39a090c9'
    ),
    __GempadPrivateSale_init: new Func<[_id: bigint, _owner: string, info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), _mode: number, _feeReceiver: string, _fundToken: string], {_id: bigint, _owner: string, info: ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _vesting: ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint}), _mode: number, _feeReceiver: string, _fundToken: string}, []>(
        abi, '0x9d8efc01'
    ),
    __ServicePayer_init: new Func<[receiver: string, serviceName: string], {receiver: string, serviceName: string}, []>(
        abi, '0xa35e3aec'
    ),
    addWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0xedac985b'
    ),
    antibotToken: new Func<[], {}, string>(
        abi, '0xc3ee6de8'
    ),
    cancel: new Func<[], {}, []>(
        abi, '0xea8a1af0'
    ),
    claimRefund: new Func<[], {}, []>(
        abi, '0xb5545a3c'
    ),
    claimTokens: new Func<[], {}, []>(
        abi, '0x48c54b9d'
    ),
    claimableTokens: new Func<[], {}, bigint>(
        abi, '0xbab8fe40'
    ),
    claimedAmount: new Func<[], {}, bigint>(
        abi, '0x9668ceb8'
    ),
    depositOf: new Func<[_: string], {}, bigint>(
        abi, '0x23e3fbd5'
    ),
    enableAntibotMode: new Func<[_token: string, _amount: bigint], {_token: string, _amount: bigint}, []>(
        abi, '0x496a1bbd'
    ),
    enablePublicSale: new Func<[_startTime: bigint], {_startTime: bigint}, []>(
        abi, '0xcfed032a'
    ),
    finalize: new Func<[], {}, []>(
        abi, '0x4bb278f3'
    ),
    fundByTokens: new Func<[], {}, boolean>(
        abi, '0x00fed700'
    ),
    fundToken: new Func<[], {}, string>(
        abi, '0x50adcdb7'
    ),
    getAllInvestors: new Func<[], {}, Array<string>>(
        abi, '0xd0a2f2c4'
    ),
    getCurrentMode: new Func<[], {}, number>(
        abi, '0x15370598'
    ),
    getCurrentStatus: new Func<[], {}, number>(
        abi, '0xa3dd2619'
    ),
    investFunds: new Func<[_amount: bigint], {_amount: bigint}, []>(
        abi, '0xdd4cbcef'
    ),
    isInitialized: new Func<[], {}, boolean>(
        abi, '0x392e53cd'
    ),
    isWhitelisted: new Func<[_address: string], {_address: string}, boolean>(
        abi, '0x3af32abf'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    removeWhitelist: new Func<[_participants: Array<string>], {_participants: Array<string>}, []>(
        abi, '0x23245216'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    saleInfo: new Func<[], {}, ([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})>(
        abi, '0x8e3695b8'
    ),
    totalSale: new Func<[], {}, bigint>(
        abi, '0xea4ce239'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
    vesting: new Func<[], {}, ([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint})>(
        abi, '0x44c63eec'
    ),
}

export class Contract extends ContractBase {

    Id(): Promise<bigint> {
        return this.eth_call(functions.Id, [])
    }

    antibotToken(): Promise<string> {
        return this.eth_call(functions.antibotToken, [])
    }

    claimableTokens(): Promise<bigint> {
        return this.eth_call(functions.claimableTokens, [])
    }

    claimedAmount(): Promise<bigint> {
        return this.eth_call(functions.claimedAmount, [])
    }

    depositOf(arg0: string): Promise<bigint> {
        return this.eth_call(functions.depositOf, [arg0])
    }

    fundByTokens(): Promise<boolean> {
        return this.eth_call(functions.fundByTokens, [])
    }

    fundToken(): Promise<string> {
        return this.eth_call(functions.fundToken, [])
    }

    getAllInvestors(): Promise<Array<string>> {
        return this.eth_call(functions.getAllInvestors, [])
    }

    getCurrentMode(): Promise<number> {
        return this.eth_call(functions.getCurrentMode, [])
    }

    getCurrentStatus(): Promise<number> {
        return this.eth_call(functions.getCurrentStatus, [])
    }

    isInitialized(): Promise<boolean> {
        return this.eth_call(functions.isInitialized, [])
    }

    isWhitelisted(_address: string): Promise<boolean> {
        return this.eth_call(functions.isWhitelisted, [_address])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    saleInfo(): Promise<([name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {name: string, softCap: bigint, hardCap: bigint, minBuyLimit: bigint, maxBuyLimit: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint})> {
        return this.eth_call(functions.saleInfo, [])
    }

    totalSale(): Promise<bigint> {
        return this.eth_call(functions.totalSale, [])
    }

    vesting(): Promise<([initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint] & {initialRelease: bigint, cyclePercent: bigint, cycleInterval: bigint})> {
        return this.eth_call(functions.vesting, [])
    }
}
