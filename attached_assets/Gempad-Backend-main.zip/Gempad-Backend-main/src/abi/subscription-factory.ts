import * as ethers from 'ethers'
import {LogEvent, Func, ContractBase} from './abi.support'
import {ABI_JSON} from './subscription-factory.abi'

export const abi = new ethers.Interface(ABI_JSON);

export const events = {
    OwnershipTransferred: new LogEvent<([previousOwner: string, newOwner: string] & {previousOwner: string, newOwner: string})>(
        abi, '0x8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e0'
    ),
    SubscriptionPoolCreated: new LogEvent<([id: string, _info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), subscriptionPool: string, refundType: boolean] & {id: string, _info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), liq: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), subscriptionPool: string, refundType: boolean})>(
        abi, '0x5ebfa3768557bf760ff88cdc7cfba8fb9933a0f88cd2966c4f42b3bb61af3776'
    ),
}

export const functions = {
    IdCounter: new Func<[], {}, bigint>(
        abi, '0xae227ad4'
    ),
    createSubscriptionPool: new Func<[_info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _fundToken: string, _isprivateSale: boolean, _isRefund: boolean, _feeReceiver: string], {_info: ([token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint] & {token: string, hardCap: bigint, softCap: bigint, userHardCap: bigint, sellRate: bigint, listingRate: bigint, startTime: bigint, endTime: bigint, finalizeTime: bigint, publicSaleTime: bigint}), _liquidity: ([router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint] & {router: string, liquidityPercent: bigint, lockTime: bigint, locker: string, liquidityAdded: bigint}), _fundToken: string, _isprivateSale: boolean, _isRefund: boolean, _feeReceiver: string}, []>(
        abi, '0x0c904608'
    ),
    getAllSubscriptionPools: new Func<[], {}, Array<string>>(
        abi, '0x0b4357a7'
    ),
    getImplementation: new Func<[], {}, string>(
        abi, '0xaaf10f42'
    ),
    getSubscriptionPoolBeacon: new Func<[], {}, string>(
        abi, '0x5567cfb7'
    ),
    getUserSubscriptionPools: new Func<[_user: string], {_user: string}, Array<string>>(
        abi, '0xc0ef3d6c'
    ),
    owner: new Func<[], {}, string>(
        abi, '0x8da5cb5b'
    ),
    renounceOwnership: new Func<[], {}, []>(
        abi, '0x715018a6'
    ),
    subscriptionPools: new Func<[_: bigint], {}, string>(
        abi, '0xee77073d'
    ),
    transferOwnership: new Func<[newOwner: string], {newOwner: string}, []>(
        abi, '0xf2fde38b'
    ),
}

export class Contract extends ContractBase {

    IdCounter(): Promise<bigint> {
        return this.eth_call(functions.IdCounter, [])
    }

    getAllSubscriptionPools(): Promise<Array<string>> {
        return this.eth_call(functions.getAllSubscriptionPools, [])
    }

    getImplementation(): Promise<string> {
        return this.eth_call(functions.getImplementation, [])
    }

    getSubscriptionPoolBeacon(): Promise<string> {
        return this.eth_call(functions.getSubscriptionPoolBeacon, [])
    }

    getUserSubscriptionPools(_user: string): Promise<Array<string>> {
        return this.eth_call(functions.getUserSubscriptionPools, [_user])
    }

    owner(): Promise<string> {
        return this.eth_call(functions.owner, [])
    }

    subscriptionPools(arg0: bigint): Promise<string> {
        return this.eth_call(functions.subscriptionPools, [arg0])
    }
}
