import { Log } from "@subsquid/evm-processor";
import {
  AntibotAddRemoveToBlacklistData,
  AntibotAddRemoveToWhitelistData,
  BaseEventData,
} from "../types";
import * as antibot from "../abi/antibot";

export const processAntibotData = (
  log: Log,
  baseEventData: BaseEventData
): AntibotAddRemoveToBlacklistData | AntibotAddRemoveToWhitelistData => {
  console.log("inside prefetch antibot");
  const _topic = log.topics[0];
  const { Blacklist, Whitelist } = antibot.events;

  if (_topic === Blacklist.topic) {
    return addOrRemoveToBlacklist(log, baseEventData);
  }

  if (_topic === Whitelist.topic) {
    return addOrRemoveToWhitelist(log, baseEventData);
  }

  return null as never;
};

const addOrRemoveToBlacklist = (
  log: Log,
  baseEventData: BaseEventData
): AntibotAddRemoveToBlacklistData => {
  const { status, token, users } = antibot.events.Blacklist.decode(log);

  const data: AntibotAddRemoveToBlacklistData = {
    ...baseEventData,
    type: "AddRemoveToBlacklist",
    item: {
      id: token.toLowerCase(),
      users,
      status,
    },
  };

  return data;
};
const addOrRemoveToWhitelist = (
  log: Log,
  baseEventData: BaseEventData
): AntibotAddRemoveToWhitelistData => {
  const { status, token, users } = antibot.events.Whitelist.decode(log);

  const data: AntibotAddRemoveToWhitelistData = {
    ...baseEventData,
    type: "AddRemoveToWhitelist",
    item: {
      id: token.toLowerCase(),
      users,
      status,
    },
  };

  return data;
};
