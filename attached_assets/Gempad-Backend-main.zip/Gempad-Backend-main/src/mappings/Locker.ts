import { Log } from "@subsquid/evm-processor";
import {
  BaseEventData,
  LockAddedData,
  LockOwnerChanged,
  LockRemovedData,
  LockUpdatedData,
  VestingLockAdded,
} from "../types";
import * as locker from "../abi/locker";
import { BigNumberToDate } from "../utils";
import { Context } from "vm";
import { ProcessorContext } from "../processor";
import { Store } from "@subsquid/typeorm-store";
import { Lock } from "../model";

export const processLockerData = async (
  log: Log,
  baseEventData: BaseEventData,
  ctx: ProcessorContext<Store>
): Promise<
  | LockAddedData
  | VestingLockAdded
  | LockOwnerChanged
  | LockUpdatedData
  | LockRemovedData
> => {
  const _topic = log.topics[0].toLowerCase();
  const {
    LockAdded,
    VestingLockAdded,
    LockRemoved,
    LockUpdated,
    LockOwnerChanged,
  } = locker.events;

  if (_topic === LockAdded.topic.toLowerCase()) {
    return processNewLockAddedData(log, baseEventData);
  }

  // Lock vested
  if (_topic === VestingLockAdded.topic.toLowerCase()) {
    return processNewVestingLockAddedData(log, baseEventData);
  }

  // LockUpdated
  if (_topic === LockUpdated.topic.toLowerCase()) {
    return processLockUpdatedData(log, baseEventData);
  }
  // LockRemoved
  if (_topic === LockRemoved.topic.toLowerCase()) {
    return processLockRemovedData(log, baseEventData);
  }

  // LockedOwnerChanged
  if (_topic === LockOwnerChanged.topic.toLowerCase()) {
    return await processLockOwnerChangedData(log, baseEventData, ctx);
  }

  return null as never;
};

const processNewLockAddedData = (
  log: Log,
  baseEventData: BaseEventData
): LockAddedData => {
  const { id, owner, token, amount, unlockDate, isLpToken } =
    locker.events.LockAdded.decode(log);

  const data: LockAddedData = {
    ...baseEventData,
    type: "LockAdded",
    item: {
      id: id.toString(),
      owner: owner.toLowerCase(),
      token: token.toLowerCase(),
      isLpToken,
      unlockedAmount: 0n,
      amount: amount,
      unlockDate: BigNumberToDate(unlockDate),
    },
  };

  return data;
};

const processNewVestingLockAddedData = (
  log: Log,
  baseEventData: BaseEventData
): VestingLockAdded => {
  const {
    id,
    token,
    owner,
    amount,
    isLpToken,
    TGE,
    cycleShare,
    interval,
    unlockDate,
  } = locker.events.VestingLockAdded.decode(log);

  const data: VestingLockAdded = {
    ...baseEventData,
    type: "VestingLockAdded",
    item: {
      id: id.toString(),
      owner: owner.toLowerCase(),
      token: token.toLowerCase(),
      amount,
      isLpToken,
      TGE,
      unlockedAmount: 0n,
      cycleShare,
      interval,
      unlockDate: BigNumberToDate(unlockDate),
    },
  };

  return data;
};

const processLockUpdatedData = (
  log: Log,
  baseEventData: BaseEventData
): LockUpdatedData => {
  const { id, owner, token, newAmount, newUnlockDate } =
    locker.events.LockUpdated.decode(log);

  const data: LockUpdatedData = {
    ...baseEventData,
    type: "LockUpdated",
    item: {
      id: id.toString(),
      owner: owner.toLowerCase(),
      token: token.toLowerCase(),
      newAmount: newAmount,
      newUnlockDate: BigNumberToDate(newUnlockDate),
    },
  };

  return data;
};

const processLockRemovedData = (
  log: Log,
  baseEventData: BaseEventData
): LockRemovedData => {
  const { id, owner, token, amount, unlockedAt } =
    locker.events.LockRemoved.decode(log);

  const data: LockRemovedData = {
    ...baseEventData,
    type: "LockRemoved",
    item: {
      id: id.toString(),
      owner: owner.toLowerCase(),
      token: token.toLowerCase(),
      amount: amount,
      unlockedAt: BigNumberToDate(unlockedAt),
    },
  };

  return data;
};

const processLockOwnerChangedData = async (
  log: Log,
  baseEventData: BaseEventData,
  ctx: ProcessorContext<Store>
): Promise<LockOwnerChanged> => {
  const { lockId, owner, newOwner } =
    locker.events.LockOwnerChanged.decode(log);

  const query: Lock | undefined = await ctx.store.findOne(Lock, {
    where: { id: lockId.toString() },
    relations: { token: true },
  });

  const data: LockOwnerChanged = {
    ...baseEventData,
    type: "LockOwnerChanged",
    item: {
      id: lockId.toString(),
      oldOwner: owner.toLowerCase(),
      newOwner: newOwner.toLowerCase(),
      token: query?.token?.id!, // lock owner can only be changed if the lock exist so we can safly do this.
    },
  };
  return data;
};
