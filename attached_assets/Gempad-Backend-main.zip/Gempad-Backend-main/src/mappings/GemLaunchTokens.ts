import { Log } from "@subsquid/evm-processor";

import { BaseEventData, GemlaunchTokenCreatedData } from "../types";

export const processTokenCreation = (
  log: Log,
  baseEventData: BaseEventData,
  abi: any
): GemlaunchTokenCreatedData => {
  if (
    log.topics[0].toLowerCase() === abi.events.TokenCreated.topic.toLowerCase()
  ) {
    const { owner, token, tokenType } = abi.events.TokenCreated.decode(log);

    const data: GemlaunchTokenCreatedData = {
      ...baseEventData,
      type: "GemlaunchTokenCreated",
      item: {
        owner,
        token,
        tokenType,
      },
    };

    return data;
  }

  return null as never;
};
