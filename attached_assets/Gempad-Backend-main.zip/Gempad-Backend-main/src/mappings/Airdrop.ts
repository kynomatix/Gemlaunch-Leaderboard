import * as airdropFactory from "../abi/airdrop-factory";
import { Airdrop, Status } from "../model";
import { ProcessorContext } from "../processor";
import {
  AirdropCreationData,
  AirdropOwnerChangedData,
  BaseEventData,
} from "../types";
import { Log } from "@subsquid/evm-processor";

export const processAirdropFactory = (
  log: Log,
  baseEventData: BaseEventData
): AirdropCreationData => {
  const _topic = log.topics[0];
  const { GempadAirdropCreated } = airdropFactory.events;

  if (_topic === GempadAirdropCreated.topic) {
    return handleAirdropCreation(log, baseEventData);
  }

  return null as never;
};

const handleAirdropCreation = (
  log: Log,
  baseEventData: BaseEventData
): AirdropCreationData => {
  const { token, name, airdrop, id } =
    airdropFactory.events.GempadAirdropCreated.decode(log);

  const data: AirdropCreationData = {
    ...baseEventData,
    type: "AirdropCreated",
    item: {
      id: id.toString(),
      owner: log.transaction!.from.toLowerCase(),
      token,
      name,
      tge: 0n,
      cycle: 0n,
      interval: 0n,
      isVesting: false,
      contractAddress: airdrop.toLowerCase(),
      status: Status.PENDING,
      isCancelled: false,
      isEnded: false,
    },
  };

  return data;
};
