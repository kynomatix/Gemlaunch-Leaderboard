import { Log } from "@subsquid/evm-processor";
import { BaseEventData, PrivateSaleCreationData } from "../types";
import * as privateSaleFactory from "../abi/private-sale-factory";
import { Status } from "../model";
import { CHAIN_ID } from "../constants";

enum Currency {
  NATIVE,
  USDT,
  USDC,
}

const NATIVE_CURRENCY_SYMBOLS: Record<number, string> = {
  [5]: "ETH",
  [97]: "BNB",
  [4005]: "FTM",
};

const CURRENCY_ADDRESS: Record<number, string> = {
  [Currency.NATIVE]: "0x0000000000000000000000000000000000000000",
  [Currency.USDT]: "0xAf4DB11839dD39fB4715d8942aA2EC72a842e648",
  [Currency.USDC]: "0xB12a6f31F80405cAe7fC11499F53EDBeC237b65C",
};

const CURRENCY_SYMBOLS: Record<string, string> = {
  [CURRENCY_ADDRESS[Currency.NATIVE]]: NATIVE_CURRENCY_SYMBOLS[CHAIN_ID],
  [CURRENCY_ADDRESS[Currency.USDC]]: "USDC",
  [CURRENCY_ADDRESS[Currency.USDT]]: "USDT",
};

export const processPrivateSale = (
  log: Log,
  baseEventData: BaseEventData
): PrivateSaleCreationData => {
  const _topic = log.topics[0];
  const { PrivateSaleCreated } = privateSaleFactory.events;

  if (_topic === PrivateSaleCreated.topic) {
    return processNewPrivateSaleData(log, baseEventData);
  }

  return null as never;
};

export const processNewPrivateSaleData = (
  log: Log,
  baseEventData: BaseEventData
): PrivateSaleCreationData => {
  const {
    info: {
      name,
      softCap: softcap,
      hardCap: hardcap,
      minBuyLimit,
      maxBuyLimit,
      startTime,
      endTime,
      finalizeTime,
      publicSaleTime,
    },
    vesting: { initialRelease, cycleInterval, cyclePercent },
    mode,
    privateSale,
    id,
    fundToken, // currency
  } = privateSaleFactory.events.PrivateSaleCreated.decode(log);

  const data: PrivateSaleCreationData = {
    ...baseEventData,
    type: "PrivateSaleAdded",
    item: {
      id: privateSale.toLowerCase(),
      owner: log.transaction?.from?.toLowerCase()!,
      name,
      contractAddress: privateSale,
      softcap,
      hardcap,
      minBuyLimit,
      maxBuyLimit,
      startTime,
      endTime,
      isCancelled: false,
      finalizeTime,
      publicSaleTime,
      initialRelease,
      cycleInterval,
      cyclePercent,
      currency: fundToken,
      tokenSymbol: CURRENCY_SYMBOLS[fundToken],
      isWhitelist: mode,
      status: Status.PENDING,
      depositedAmount: 0n,
    },
  };

  return data;
};
