import { BlockData, assertNotNull } from "@subsquid/evm-processor";
import { Store } from "@subsquid/typeorm-store";
import last from "lodash/last.js";
import uniq from "lodash/uniq.js";
import { BlockContext } from "../abi/abi.support";
import {
  BABY_TOKEN_FACTORY,
  BUYBACK_TOKEN_FACTORY,
  DUTCH_FACTORY,
  FAIRLAUNCH_FACTORY,
  LAUNCHPAD_FACTORY,
  LIQUIDITY_TOKEN_FACTORY,
  STANDARD_TOKEN_FACTORY,
  SUBSCRIPTION_FACTORY,
  AIRDROP_FACTORY,
  ANTIBOT,
  CHAIN_ID,
  LOCKER,
  PRIVATE_SALE_FACTORY,
  ANTIBOT_STANDARD_TOKEN_FACTORY,
  ANTIBOT_LIQUIDITY_TOKEN_FACTORY,
  ANTIBOT_BABY_TOKEN_FACTORY,
  ANTIBOT_BUYBACK_TOKEN_FACTORY,
} from "../constants";
import {
  Aggregation,
  Airdrop,
  Antibot,
  GemlaunchToken,
  Lock,
  PrivateSale,
  Token,
  User,
  LaunchPad,
} from "../model";
import { processPrivateSaleContract } from "../process/PrivateSale";
import { ProcessorContext, Transaction } from "../processor";
import {
  AirdropEventData,
  AntibotEventData,
  BaseEventData,
  EVM,
  EventData,
  GemTokenAbi,
  GemlaunchTokenEventData,
  LaunchPadsEventData,
  LockerEventData,
  PrivateSaleEventData,
} from "../types";
import { EntityManager } from "../utils/entityManager";
import {
  extractAirdropEventData,
  extractAntibotEventData,
  extractGemlaunchTokenEventData,
  extractLaunchpadsEventData,
  extractLockerEventData,
  extractPrivateSaleEventData,
} from "../utils/extractEventData";
import {
  fetchTokensCoinInfo,
  fetchTokensDecimals,
  fetchTokensName,
  fetchTokensPair,
  fetchTokensSymbol,
  fetchTokensTotalSupply,
} from "../utils/token";
import { processPrivateSale } from "./PrivateSale";
import { processAirdropFactory } from "./Airdrop";
import { processAirdropContract } from "../process/Airdrop";
import { processTokenCreation } from "./GemLaunchTokens";

import * as standardTokenFactoryAbi from "../abi/standard-token-factory";
import * as liquidityTokenFactoryAbi from "../abi/liquidity-token-factory";
import * as babyTokenFactoryAbi from "../abi/baby-token-factory";
import * as buybackBabyTokenFactoryAbi from "../abi/buyback-baby-token";

import * as antibotStandardTokenFactoryAbi from "../abi/antibot-standard-token-factory";
import * as antibotLiquidityTokenFactoryAbi from "../abi/antibot-liquidity-token-factory";
import * as antibotBabyTokenFactoryAbi from "../abi/antibot-baby-token-factory";
import * as antibotBuybackBabyTokenFactoryAbi from "../abi/antibot-buyback-baby-token-factory";

import { processFairlaunchFactory } from "../process/Fairlaunch";
import { processDutchAuctionFactory } from "../process/Dutch";
import { processSubscriptionFactory } from "../process/Subscription";
import { processLockerData } from "./Locker";
import { processAntibotData } from "./Antibot";
import {
  processLaunchpadFactory,
  processLaunchpadsContract,
} from "../process/Launchpad";

export class PretechFactory {
  readonly blockCtx: BlockContext = {
    _chain: this.ctx._chain,
    block: last(this.ctx.blocks)!.header,
  };

  eventsData: ReadonlyArray<EventData> = [];
  privateSaleEventData: ReadonlyArray<PrivateSaleEventData> = [];
  lockerEventData: ReadonlyArray<LockerEventData> = [];
  airdropEventData: ReadonlyArray<AirdropEventData> = [];
  antibotEventData: ReadonlyArray<AntibotEventData> = [];
  gemlaunchTokenEventData: ReadonlyArray<GemlaunchTokenEventData> = [];
  launchpadsEventData: ReadonlyArray<LaunchPadsEventData> = [];

  constructor(
    private ctx: ProcessorContext<Store>,
    private em: EntityManager
  ) {}

  async prefetch(): Promise<void> {
    this.eventsData = await this.processEventLogs();
    if (this.eventsData.length === 0) return;

    this.privateSaleEventData = extractPrivateSaleEventData(this.eventsData);
    this.lockerEventData = extractLockerEventData(this.eventsData);
    this.airdropEventData = extractAirdropEventData(this.eventsData);
    this.antibotEventData = extractAntibotEventData(this.eventsData);
    this.gemlaunchTokenEventData = extractGemlaunchTokenEventData(
      this.eventsData
    );
    this.launchpadsEventData = extractLaunchpadsEventData(this.eventsData);

    await Promise.all([
      this.prefetchAggregation(),
      this.prefetchUsers(),
      this.prefetchTokens(),
      this.prefetchLocks(),
      this.prefetchAntibots(),
      this.prefetchAirdrops(),
      this.prefetchPrivateSale(),
      this.prefetchLaunchpads(),
    ]);
  }

  private async processEventLogs(): Promise<EventData[]> {
    const processedData: EventData[] = [];

    await Promise.all(
      this.ctx.blocks.flatMap(async (block: BlockData) => {
        for (const log of block.logs) {
          const baseEventData: BaseEventData = {
            topic: log.topics[0]?.toLowerCase(),
            transaction: log.transaction as Transaction,
          };

          // Locker
          if (LOCKER === log.address.toLowerCase()) {
            processedData.push(
              await processLockerData(log, baseEventData, this.ctx)
            );
          }

          // Airdrops;
          if (AIRDROP_FACTORY === log.address.toLowerCase()) {
            processedData.push(processAirdropFactory(log, baseEventData));
          }
          const airdropData = processAirdropContract(
            log,
            this.em,
            baseEventData
          );
          if (airdropData) {
            processedData.push(airdropData);
          }

          // Launchpads:
          if (LAUNCHPAD_FACTORY.toLowerCase() === log.address.toLowerCase()) {
            processedData.push(
              processLaunchpadFactory(log, baseEventData, this.ctx.blocks)
            );
          }

          // Fairlaunchpads:
          if (FAIRLAUNCH_FACTORY.toLowerCase() === log.address.toLowerCase()) {
            processedData.push(
              processFairlaunchFactory(log, baseEventData, this.ctx.blocks)
            );
          }

          // Dutch Auction:
          if (DUTCH_FACTORY.toLowerCase() === log.address.toLowerCase()) {
            processedData.push(
              processDutchAuctionFactory(log, baseEventData, this.ctx.blocks)
            );
          }

          // Subscription Pool:
          if (
            SUBSCRIPTION_FACTORY.toLowerCase() === log.address.toLowerCase()
          ) {
            processedData.push(
              processSubscriptionFactory(log, baseEventData, this.ctx.blocks)
            );
          }

          // Launchpads Contract:
          const launchpadsData = processLaunchpadsContract(
            log,
            this.em,
            baseEventData
          );
          if (launchpadsData) {
            processedData.push(launchpadsData);
          }

          // Private Sale
          if (PRIVATE_SALE_FACTORY === log.address.toLowerCase()) {
            processedData.push(processPrivateSale(log, baseEventData));
          }
          const privateSaleData = await processPrivateSaleContract(
            log,
            this.em,
            baseEventData
          );
          if (privateSaleData) {
            processedData.push(privateSaleData);
          }

          // Antibot:
          if (ANTIBOT === log.address.toLowerCase()) {
            processedData.push(processAntibotData(log, baseEventData));
          }

          // Gemlaunch Tokens:
          if (STANDARD_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(log, baseEventData, standardTokenFactoryAbi)
            );
          }
          if (LIQUIDITY_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(log, baseEventData, liquidityTokenFactoryAbi)
            );
          }
          if (BABY_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(log, baseEventData, babyTokenFactoryAbi)
            );
          }
          if (BUYBACK_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(
                log,
                baseEventData,
                buybackBabyTokenFactoryAbi
              )
            );
          }
          if (ANTIBOT_STANDARD_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(
                log,
                baseEventData,
                antibotStandardTokenFactoryAbi
              )
            );
          }
          if (ANTIBOT_LIQUIDITY_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(
                log,
                baseEventData,
                antibotLiquidityTokenFactoryAbi
              )
            );
          }
          if (ANTIBOT_BABY_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(
                log,
                baseEventData,
                antibotBabyTokenFactoryAbi
              )
            );
          }
          if (ANTIBOT_BUYBACK_TOKEN_FACTORY === log.address.toLowerCase()) {
            processedData.push(
              processTokenCreation(
                log,
                baseEventData,
                antibotBuybackBabyTokenFactoryAbi
              )
            );
          }
        }
      })
    );
    return processedData.filter((x) => x);
  }

  // Methods

  private getEventData<T extends EventData["type"]>(type: T) {
    return this.eventsData.filter((x) => x.type === type) as Extract<
      EventData,
      { type: T }
    >[];
  }

  // Aggrigration
  private async prefetchAggregation(): Promise<void> {
    let aggregation = await this.em.get(Aggregation, "1");

    if (!aggregation) {
      aggregation = new Aggregation({
        id: "1",
        chainId: CHAIN_ID,
        createdAt: new Date(),
        tokenLockedCount: 0,
        tokenLocked: 0,
        tokenLockedInUsd: 0,
        liquidityLockedCount: 0,
        liquidityLocked: 0,
        liquidityLockedInUsd: 0,
        raisedContributionNative: 0n,
        raisedContributionUSDC: 0n,
        raisedContributionUSDT: 0n,
        totalAirdropsLaunched: 0,
        totalParticipantsAirdrops: 0,
        fundedProjects: 0,
        uniqueParticipants: [],
      });
    }

    this.em.add(aggregation);
  }

  // users
  private async prefetchUsers(): Promise<void> {
    const userIds: string[] = uniq(
      this.eventsData.flatMap((x) => {
        switch (x.type) {
          case "LockAdded":
          case "LockUpdated":
          case "LockRemoved":
          case "VestingLockAdded":
          case "AirdropCreated":
          case "PrivateSaleAdded":
          case "GemlaunchTokenCreated":
          case "FairlaunchCreated":
          case "DutchAuctionCreated":
          case "LaunchpadCreated":
          case "SubscriptionPoolCreated":
          case "TokenPurchasedLaunchpad":
            return [x.item.owner];
          case "LockTransfer":
          case "LockOwnerChanged":
            return [x.item.oldOwner, x.item.newOwner];
          default:
            return [];
        }
      })
    );

    this.em.defer(User, ...userIds);
    await this.em.load(User);

    const uncachedIds = userIds.filter((id) => !this.em.has(User, id));

    // create
    for (const id of uncachedIds) {
      const user = new User({ id, chainId: CHAIN_ID, createdAt: new Date() });
      this.em.add(user);
    }
  }

  // locks
  private async prefetchLocks(): Promise<void> {
    const lockIds = uniq(
      this.eventsData.flatMap((x) => {
        switch (x.type) {
          case "LockAdded":
          case "LockUpdated":
          case "LockRemoved":
          case "LockTransfer":
          case "VestingLockAdded":
          case "LockOwnerChanged":
            return [x.item.id];
          default:
            return [];
        }
      })
    );

    this.em.defer(Lock, ...lockIds);
    await this.em.load(Lock);
  }

  // Antibots
  private async prefetchAntibots(): Promise<void> {
    const antibotIds = uniq(
      this.antibotEventData.flatMap((x) => {
        switch (x.type) {
          case "AddRemoveToBlacklist":
          case "AddRemoveToWhitelist":
            return [x.item.id];
          default:
            return [];
        }
      })
    );

    this.em.defer(Antibot, ...antibotIds);
    await this.em.load(Antibot);
  }

  // Airdrops
  private async prefetchAirdrops(): Promise<void> {
    const airdropIds = uniq(
      this.airdropEventData.flatMap((x) => {
        switch (x.type) {
          case "AirdropCreated":
          case "AirdropVestingInfoSet":
          case "AirdropAddParticipants":
          case "AirdropCancelled":
          case "AirdropStarted":
          case "AirdropAllocationsRemoved":
            return x.item.id;
          default:
            return [];
        }
      })
    );

    this.em.defer(Airdrop, ...airdropIds);
    await this.em.load(Airdrop);
  }

  // PrivateSale:
  private async prefetchPrivateSale(): Promise<void> {
    const privateSaleIds = uniq(
      this.privateSaleEventData.flatMap((x) => {
        switch (x.type) {
          case "PrivateSaleAdded":
          case "PrivateSaleWhitelistAdded":
          case "PrivateSaleWhitelistRemoved":
          case "PrivateSaleFundsDeposited":
            return x.item.id;

          default:
            return [];
        }
      })
    );

    this.em.defer(PrivateSale, ...privateSaleIds);
    await this.em.load(PrivateSale);
  }

  // tokens
  private async prefetchTokens(): Promise<void> {
    const lockerTokenIds = uniq(this.lockerEventData.map((x) => x.item.token));

    const airdropTokenIds = uniq(
      this.airdropEventData.filter((x) => x.item.token).map((x) => x.item.token)
    );

    const launchpadsTokenIds = uniq(
      this.launchpadsEventData
        .filter((x) => x.item.token)
        .map((x) => x.item.token)
    );

    const tokenIds = [
      ...lockerTokenIds,
      ...airdropTokenIds,
      ...launchpadsTokenIds,
    ];
    await this.loadTokens(tokenIds);

    // get token0 & token1
    const lpTokens = this.em.values(Token).filter((x) => x.isLiquidityToken);
    const pairIds = await this.syncTokenPairs(lpTokens);

    // load token0 & token1
    const uncachedPairs = pairIds.filter((id) => !this.em.has(Token, id));
    await this.loadTokens(uncachedPairs);

    // sync all tokens
    const tokens = this.em.values(Token);

    await this.syncTokens(tokens);
  }

  // LaunchpadFactory

  private async prefetchLaunchpads(): Promise<void> {
    const launchpadId = uniq(
      this.launchpadsEventData.flatMap((x) => {
        switch (x.type) {
          case "LaunchpadCreated":
          case "FairlaunchCreated":
          case "DutchAuctionCreated":
          case "SubscriptionPoolCreated":
            return [x.item.id];
          default:
            return [];
        }
      })
    );

    this.em.defer(LaunchPad, ...launchpadId);
    await this.em.load(LaunchPad);
  }

  // Methods
  private async loadTokens(ids: string[]): Promise<void> {
    this.em.defer(Token, ...ids);
    await this.em.load(Token);

    const lockAddedData = this.getEventData("LockAdded");
    const uncachedIds = ids.filter((id) => !this.em.has(Token, id));

    // create
    for (const id of uncachedIds) {
      const data = lockAddedData.find((x) => x.item.token === id)?.item;
      const token = new Token({
        id,
        chainId: CHAIN_ID,
        isLiquidityToken: Boolean(data?.isLpToken),
        usdPrice: 0,
        tokenLockedCount: 0,
        tokenLocked: 0,
        tokenLockedInUsd: 0,
        createdAt: new Date(),
      });

      this.em.add(token);
    }
  }

  private async syncTokenPairs(tokens: Token[]): Promise<string[]> {
    const lpIds = tokens.map((t) => t.id);
    const tokenPairs = await fetchTokensPair(this.blockCtx, lpIds);

    for (const token of tokens) {
      const {
        token0: token0Address,
        token1: token1Address,
        reserve0,
        reserve1,
      } = tokenPairs.get(token.id)!;

      if (token) {
        token.token0 = assertNotNull(new Token({ id: token0Address }));
        token.token1 = assertNotNull(new Token({ id: token1Address }));

        token.reserve0 = assertNotNull(reserve0);
        token.reserve1 = assertNotNull(reserve1);
      }
    }

    return uniq([...tokenPairs.values()].flatMap((x) => [x.token0, x.token1])); // return token0 and token1
  }

  private async syncTokens(tokens: Token[]): Promise<void> {
    const ids = tokens.map((t) => t.id);

    const [symbols, names, totalSupplies, decimals, coinInfos] =
      await Promise.all([
        fetchTokensSymbol(this.blockCtx, ids),
        fetchTokensName(this.blockCtx, ids),
        fetchTokensTotalSupply(this.blockCtx, ids),
        fetchTokensDecimals(this.blockCtx, ids),
        fetchTokensCoinInfo(this.blockCtx, ids),
      ]);

    for (const token of tokens) {
      token.symbol = assertNotNull(symbols.get(token.id));
      token.name = assertNotNull(names.get(token.id));
      token.totalSupply = assertNotNull(totalSupplies.get(token.id));
      token.decimals = assertNotNull(decimals.get(token.id));
      token.image = coinInfos.get(token.id)?.image;
      token.usdPrice = coinInfos.get(token.id)?.usdPrice || 0;
    }
  }
}
