// import { BlockData, DataHandlerContext } from "@subsquid/evm-processor";
// import { Store } from "@subsquid/typeorm-store";
// import { EntityManager } from "../utils/entityManager";
// import { BaseEventData, EventData, PrivateSaleEvent } from "../types";
// import { BlockMap } from "../utils/blockMap";
// import * as privateSale from "../abi/private-sale";
// import { PrivateSale } from "../model";
// import { EvmLog } from "@subsquid/evm-processor/lib/interfaces/evm";

// type ContextWithEntityManager = DataHandlerContext<Store> & {
//   entities: EntityManager;
// };
// export async function processPairs(
//   ctx: ContextWithEntityManager,
//   blocks: BlockData[],
//   baseEventData: BaseEventData
// ): Promise<void> {
//   let eventsData = await processItems(ctx, blocks, baseEventData);
//   //console.log("processPairs", eventsData);
//   if (!eventsData || eventsData.size == 0) return;
// }

// async function processItems(
//   ctx: ContextWithEntityManager,
//   blocks: BlockData[],
//   baseEventData: BaseEventData
// ) {
//   let priveateSaleEventsData = new BlockMap<PrivateSaleEvent>();

//   for (let block of blocks) {
//     for (let log of block.logs) {
//       let evmLog = {
//         logIndex: log.logIndex,
//         transactionIndex: log.transactionIndex,
//         transactionHash: log.transaction?.hash || "",
//         address: log.address,
//         data: log.data,
//         topics: log.topics,
//       };
//       let ps = await ctx.entities.get(PrivateSale, log.address);

//       if (ps) {
//         switch (log.topics[0]) {
//           case privateSale.events.WhitelistUpdated.topic: {
//             let data = processWhitelistUpdated(evmLog, baseEventData);
//             priveateSaleEventsData.push(block.header, {
//               ...data,
//             });
//             break;
//           }
//         }
//       }
//     }
//   }
//   //.log("eventsData", eventsData);
//   return priveateSaleEventsData;
// }

// function processWhitelistUpdated(
//   log: EvmLog,
//   baseEventData: BaseEventData
// ): PrivateSaleEvent {
//   let event = privateSale.events.WhitelistUpdated.decode(log);
//   return {
//     ...baseEventData,
//     type: "PrivateSaleWhitelistUpdated",
//     item: {
//       id: "0x80833ea87ebc4c81651a92D0F3CeD946862A23F1",
//       accounts: event.account,
//       sender: event.sender,
//     },
//   };
// }
