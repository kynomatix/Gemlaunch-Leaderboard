import { Field, ObjectType, Query, Resolver } from "type-graphql";
import type { EntityManager } from "typeorm";
import { Lock, Token } from "../../model/generated";
// import { LockEntity } from "../model/lock.model";

@Resolver()
export class CountResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Query(() => Number)
  async totalBurns(): Promise<number> {
    console.log(this.tx);
    return 10;
  }
}

@Resolver()
export class MyResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Query(() => []) // Use [Token] for an array of Token
  async myQuery(): Promise<Lock[]> {
    const manager = await this.tx();

    // execute custom SQL query
    const result: Lock[] = await manager.getRepository(Lock).find();

    return result;
  }
}
