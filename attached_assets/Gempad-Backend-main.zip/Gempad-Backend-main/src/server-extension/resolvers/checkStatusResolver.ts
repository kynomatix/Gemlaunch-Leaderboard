import { Arg, Mutation, Resolver } from "type-graphql";
import { EntityManager } from "typeorm";


@Resolver()
export class CheckStatusResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Mutation(() => Boolean)
  async checkStatus(): Promise<boolean> {
    return true;
  }
}
