import { Arg, Mutation, Resolver } from "type-graphql";
import { EntityManager } from "typeorm";
import { LaunchpadTemp, Socials } from "../../model/generated";

@Resolver()
export class kycAuditResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Mutation(() => Boolean)
  async addKycAuditToLaunchpad(
    @Arg("contractAddress", { nullable: false }) contractAddress: string,
    @Arg("kyc", { nullable: true }) kyc: string,
    @Arg("audit", { nullable: true }) audit: string
  ): Promise<boolean> {
    const manager = await this.tx();

    let launchpadTemp = await manager.getRepository(LaunchpadTemp).findOne({
      where: { contractAddress },
    })!;

    if (!launchpadTemp) throw Error("LaunchpadTemp not found");

    launchpadTemp = new LaunchpadTemp({
      ...launchpadTemp,
      kyc,
      audit,
    });

    await manager.save(launchpadTemp);

    return true;
  }
}
