import { Arg, Mutation, Resolver } from "type-graphql";
import { EntityManager } from "typeorm";
import { AirdropTemp, Socials } from "../../model/generated";

@Resolver()
export class AirdropResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Mutation(() => Boolean)
  async addMetadataToAirdrop(
    @Arg("txHash", { nullable: false }) txHash: string,
    @Arg("logoUrl", { nullable: false }) logoUrl: string,
    @Arg("webUrl", { nullable: false }) webUrl: string,
    @Arg("facebookUrl", { nullable: true }) facebookUrl: string,
    @Arg("twitterUrl", { nullable: true }) twitterUrl: string,
    @Arg("githubUrl", { nullable: true }) githubUrl: string,
    @Arg("telegramUrl", { nullable: true }) telegramUrl: string,
    @Arg("redditUrl", { nullable: true }) redditUrl: string,
    @Arg("youtubeUrl", { nullable: true }) youtubeUrl: string,
    @Arg("description", { nullable: true }) description: string
  ): Promise<boolean> {
    const manager = await this.tx();
    const socials = new Socials({
      logoUrl,
      webUrl,
      facebookUrl,
      twitterUrl,
      githubUrl,
      telegramUrl,
      redditUrl,
      youtubeUrl,
      description,
    });

    const airdropTemp = manager.getRepository(AirdropTemp).create({
      id: txHash,
      socials,
      contractAddress: undefined,
    });

    await manager.save(airdropTemp);

    return true;
  }
}
