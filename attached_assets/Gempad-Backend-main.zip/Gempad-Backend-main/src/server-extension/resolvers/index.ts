import "reflect-metadata";
import { LockResolver } from "./lockResolver";
import { AirdropResolver } from "./airdropResolver";
import { PrivateSaleResolver } from "./privateSaleResolver";
import { EditAirdropResolver } from "./editAirdropResolver";
import { EditLaunchpadResolver } from "./editLaunchpadResolver";
import { CheckStatusResolver } from "./checkStatusResolver";
import { kycAuditResolver } from "./kycAuditResolver";
import { LaunchpadResolver } from "./launchpadResolver";
import { Query, Resolver } from "type-graphql";
import { EntityManager } from "typeorm";

// this needs to be here in order to work properly
@Resolver()
export class HelloResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Query(() => String)
  async hello(): Promise<string> {
    return "Hey, this is you custom API extension";
  }
}

export {
  LockResolver,
  AirdropResolver,
  PrivateSaleResolver,
  CheckStatusResolver,
  LaunchpadResolver,
  kycAuditResolver,
  EditAirdropResolver,
  EditLaunchpadResolver,
};
