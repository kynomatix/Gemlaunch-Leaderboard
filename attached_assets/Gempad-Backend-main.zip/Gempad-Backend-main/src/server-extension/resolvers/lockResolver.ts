import { Arg, Mutation, Resolver } from "type-graphql";
import { EntityManager } from "typeorm";
import { Lock, LockTemp } from "../../model/generated";

@Resolver()
export class LockResolver {
  constructor(private tx: () => Promise<EntityManager>) {}

  @Mutation(() => Boolean)
  async addTitleToLock(
    @Arg("txHash", { nullable: false }) txHash: string,
    @Arg("title", { nullable: false }) title: string
  ): Promise<boolean> {
    const manager = await this.tx();

    const lockTemp = manager
      .getRepository(LockTemp)
      .create({ id: txHash, title });

    await manager.save(lockTemp);

    return true;
  }
}
