import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import * as marshal from "./marshal"
import {Token} from "./token.model"
import {User} from "./user.model"
import {FundToken} from "./fundToken.model"
import {VestingDetails} from "./vestingDetails.model"
import {LiquidityDetails} from "./liquidityDetails.model"
import {LaunchpadTemp} from "./launchpadTemp.model"

@Entity_()
export class LaunchPad {
    constructor(props?: Partial<LaunchPad>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("text", {nullable: false})
    name!: string

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token!: Token

    @Index_()
    @ManyToOne_(() => User, {nullable: true})
    owner!: User

    @Column_("int4", {nullable: false})
    chainId!: number

    @Column_("text", {nullable: false})
    contractAddress!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    sellPrice!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    listingPrice!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    softCap!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    hardCap!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    minBuyLimit!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    maxBuyLimit!: bigint | undefined | null

    @Index_()
    @ManyToOne_(() => FundToken, {nullable: true})
    fundToken!: FundToken

    @Column_("bool", {nullable: true})
    refundType!: boolean | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    listingTime!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    startTime!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    endTime!: bigint

    @Column_("bool", {nullable: false})
    isCancelled!: boolean

    @Column_("bool", {nullable: true})
    isAffiliate!: boolean | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    finalizeTime!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    publicSaleTime!: bigint | undefined | null

    @Column_("text", {nullable: true})
    router!: string | undefined | null

    @Column_("text", {array: true, nullable: false})
    investors!: (string | undefined | null)[]

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    investedAmount!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    liquidityPercent!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    lockTime!: bigint | undefined | null

    @Column_("text", {nullable: true})
    locker!: string | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    listingRate!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    sellRate!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    userHardCap!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    liquidityAdded!: bigint | undefined | null

    @Column_("bool", {nullable: true})
    isAutoListing!: boolean | undefined | null

    @Index_()
    @ManyToOne_(() => VestingDetails, {nullable: true})
    vestingDetails!: VestingDetails | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    totalSellTokens!: bigint | undefined | null

    @Column_("bool", {nullable: true})
    isMaxLimit!: boolean | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    affiliateReward!: bigint | undefined | null

    @Index_()
    @ManyToOne_(() => LiquidityDetails, {nullable: true})
    liquidityDetails!: LiquidityDetails | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    totalSaleAmount!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    startPrice!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    endPrice!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    decreaseInterval!: bigint | undefined | null

    @Index_()
    @ManyToOne_(() => LaunchpadTemp, {nullable: true})
    metadata!: LaunchpadTemp | undefined | null

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
