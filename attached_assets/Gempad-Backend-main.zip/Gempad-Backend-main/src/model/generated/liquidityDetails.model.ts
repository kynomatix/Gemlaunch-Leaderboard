import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_} from "typeorm"
import * as marshal from "./marshal"

@Entity_()
export class LiquidityDetails {
    constructor(props?: Partial<LiquidityDetails>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("text", {nullable: false})
    router!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    liquidityPercent!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    lockTime!: bigint

    @Column_("text", {nullable: false})
    locker!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    liquidityAdded!: bigint
}
