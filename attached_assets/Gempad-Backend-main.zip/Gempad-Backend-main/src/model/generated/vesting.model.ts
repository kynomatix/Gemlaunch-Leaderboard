import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_, OneToMany as OneToMany_} from "typeorm"
import * as marshal from "./marshal"
import {Token} from "./token.model"
import {User} from "./user.model"
import {Claimer} from "./claimer.model"
import {Transaction} from "./transaction.model"

@Entity_()
export class Vesting {
    constructor(props?: Partial<Vesting>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token!: Token

    @Index_()
    @ManyToOne_(() => User, {nullable: true})
    creator!: User

    @Column_("text", {nullable: false})
    merkleRoot!: string

    @Column_("text", {nullable: false})
    dataUri!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    totalAmount!: bigint

    @OneToMany_(() => Claimer, e => e.vesting)
    claimers!: Claimer[]

    @OneToMany_(() => Transaction, e => e.vesting)
    transactions!: Transaction[]

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
