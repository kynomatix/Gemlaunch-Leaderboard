import assert from "assert"
import * as marshal from "./marshal"

export class Allocation {
    private _user!: string
    private _amount!: bigint

    constructor(props?: Partial<Omit<Allocation, 'toJSON'>>, json?: any) {
        Object.assign(this, props)
        if (json != null) {
            this._user = marshal.string.fromJSON(json.user)
            this._amount = marshal.bigint.fromJSON(json.amount)
        }
    }

    get user(): string {
        assert(this._user != null, 'uninitialized access')
        return this._user
    }

    set user(value: string) {
        this._user = value
    }

    get amount(): bigint {
        assert(this._amount != null, 'uninitialized access')
        return this._amount
    }

    set amount(value: bigint) {
        this._amount = value
    }

    toJSON(): object {
        return {
            user: this.user,
            amount: marshal.bigint.toJSON(this.amount),
        }
    }
}
