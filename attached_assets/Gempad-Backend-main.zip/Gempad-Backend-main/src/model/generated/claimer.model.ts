import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import {Token} from "./token.model"
import {User} from "./user.model"
import {Vesting} from "./vesting.model"

@Entity_()
export class Claimer {
    constructor(props?: Partial<Claimer>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token!: Token

    @Index_()
    @ManyToOne_(() => User, {nullable: true})
    user!: User

    @Column_("text", {nullable: false})
    amount!: string

    @Column_("int4", {nullable: false})
    start!: number

    @Column_("int4", {nullable: false})
    end!: number

    @Column_("int4", {nullable: false})
    cliff!: number

    @Column_("int4", {nullable: false})
    cadance!: number

    @Column_("int4", {nullable: false})
    percentageOnStart!: number

    @Column_("bool", {nullable: false})
    revocable!: boolean

    @Column_("int4", {nullable: false})
    index!: number

    @Index_()
    @ManyToOne_(() => Vesting, {nullable: true})
    vesting!: Vesting

    @Column_("text", {array: true, nullable: false})
    merkleProof!: (string | undefined | null)[]

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
