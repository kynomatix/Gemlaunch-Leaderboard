import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_} from "typeorm"
import * as marshal from "./marshal"

@Entity_()
export class Aggregation {
    constructor(props?: Partial<Aggregation>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Column_("int4", {nullable: false})
    tokenLockedCount!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    tokenLocked!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    tokenLockedInUsd!: number

    @Column_("int4", {nullable: false})
    liquidityLockedCount!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    liquidityLocked!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    liquidityLockedInUsd!: number

    @Column_("int4", {nullable: false})
    totalAirdropsLaunched!: number

    @Column_("int4", {nullable: false})
    totalParticipantsAirdrops!: number

    @Column_("int4", {nullable: false})
    fundedProjects!: number

    @Column_("text", {array: true, nullable: false})
    uniqueParticipants!: (string | undefined | null)[]

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    raisedContributionNative!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    raisedContributionUSDC!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    raisedContributionUSDT!: bigint

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
