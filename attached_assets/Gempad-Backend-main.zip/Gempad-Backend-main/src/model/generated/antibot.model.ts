import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_} from "typeorm"

@Entity_()
export class Antibot {
    constructor(props?: Partial<Antibot>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("text", {array: true, nullable: true})
    blacklist!: (string | undefined | null)[] | undefined | null

    @Column_("text", {array: true, nullable: true})
    whitelist!: (string | undefined | null)[] | undefined | null
}
