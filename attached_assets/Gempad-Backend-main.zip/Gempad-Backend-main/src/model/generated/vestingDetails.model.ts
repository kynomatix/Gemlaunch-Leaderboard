import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_} from "typeorm"
import * as marshal from "./marshal"

@Entity_()
export class VestingDetails {
    constructor(props?: Partial<VestingDetails>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("bool", {nullable: false})
    isVestingEnable!: boolean

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    tgePercent!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    cyclePercent!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    cycleInterval!: bigint
}
