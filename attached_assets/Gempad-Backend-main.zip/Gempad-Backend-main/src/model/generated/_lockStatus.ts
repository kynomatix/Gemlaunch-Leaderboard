export enum LockStatus {
    Locked = "Locked",
    Withdrawn = "Withdrawn",
}
