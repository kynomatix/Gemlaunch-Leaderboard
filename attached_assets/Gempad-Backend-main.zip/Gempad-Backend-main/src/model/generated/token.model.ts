import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_, OneToMany as OneToMany_} from "typeorm"
import * as marshal from "./marshal"
import {Lock} from "./lock.model"

@Entity_()
export class Token {
    constructor(props?: Partial<Token>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Column_("text", {nullable: false})
    name!: string

    @Column_("text", {nullable: true})
    symbol!: string | undefined | null

    @Column_("int4", {nullable: false})
    decimals!: number

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    totalSupply!: bigint

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    usdPrice!: number

    @Column_("text", {nullable: true})
    image!: string | undefined | null

    @Column_("bool", {nullable: false})
    isLiquidityToken!: boolean

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token0!: Token | undefined | null

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token1!: Token | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    reserve0!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    reserve1!: bigint | undefined | null

    @Column_("timestamp with time zone", {nullable: true})
    nextUnlock!: Date | undefined | null

    @Column_("int4", {nullable: false})
    tokenLockedCount!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    tokenLocked!: number

    @Column_("numeric", {transformer: marshal.floatTransformer, nullable: false})
    tokenLockedInUsd!: number

    @OneToMany_(() => Lock, e => e.token)
    locks!: Lock[]

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
