import assert from "assert"
import * as marshal from "./marshal"

export class Socials {
    private _logoUrl!: string
    private _webUrl!: string
    private _facebookUrl!: string | undefined | null
    private _twitterUrl!: string | undefined | null
    private _githubUrl!: string | undefined | null
    private _telegramUrl!: string | undefined | null
    private _redditUrl!: string | undefined | null
    private _youtubeUrl!: string | undefined | null
    private _description!: string | undefined | null

    constructor(props?: Partial<Omit<Socials, 'toJSON'>>, json?: any) {
        Object.assign(this, props)
        if (json != null) {
            this._logoUrl = marshal.string.fromJSON(json.logoUrl)
            this._webUrl = marshal.string.fromJSON(json.webUrl)
            this._facebookUrl = json.facebookUrl == null ? undefined : marshal.string.fromJSON(json.facebookUrl)
            this._twitterUrl = json.twitterUrl == null ? undefined : marshal.string.fromJSON(json.twitterUrl)
            this._githubUrl = json.githubUrl == null ? undefined : marshal.string.fromJSON(json.githubUrl)
            this._telegramUrl = json.telegramUrl == null ? undefined : marshal.string.fromJSON(json.telegramUrl)
            this._redditUrl = json.redditUrl == null ? undefined : marshal.string.fromJSON(json.redditUrl)
            this._youtubeUrl = json.youtubeUrl == null ? undefined : marshal.string.fromJSON(json.youtubeUrl)
            this._description = json.description == null ? undefined : marshal.string.fromJSON(json.description)
        }
    }

    get logoUrl(): string {
        assert(this._logoUrl != null, 'uninitialized access')
        return this._logoUrl
    }

    set logoUrl(value: string) {
        this._logoUrl = value
    }

    get webUrl(): string {
        assert(this._webUrl != null, 'uninitialized access')
        return this._webUrl
    }

    set webUrl(value: string) {
        this._webUrl = value
    }

    get facebookUrl(): string | undefined | null {
        return this._facebookUrl
    }

    set facebookUrl(value: string | undefined | null) {
        this._facebookUrl = value
    }

    get twitterUrl(): string | undefined | null {
        return this._twitterUrl
    }

    set twitterUrl(value: string | undefined | null) {
        this._twitterUrl = value
    }

    get githubUrl(): string | undefined | null {
        return this._githubUrl
    }

    set githubUrl(value: string | undefined | null) {
        this._githubUrl = value
    }

    get telegramUrl(): string | undefined | null {
        return this._telegramUrl
    }

    set telegramUrl(value: string | undefined | null) {
        this._telegramUrl = value
    }

    get redditUrl(): string | undefined | null {
        return this._redditUrl
    }

    set redditUrl(value: string | undefined | null) {
        this._redditUrl = value
    }

    get youtubeUrl(): string | undefined | null {
        return this._youtubeUrl
    }

    set youtubeUrl(value: string | undefined | null) {
        this._youtubeUrl = value
    }

    get description(): string | undefined | null {
        return this._description
    }

    set description(value: string | undefined | null) {
        this._description = value
    }

    toJSON(): object {
        return {
            logoUrl: this.logoUrl,
            webUrl: this.webUrl,
            facebookUrl: this.facebookUrl,
            twitterUrl: this.twitterUrl,
            githubUrl: this.githubUrl,
            telegramUrl: this.telegramUrl,
            redditUrl: this.redditUrl,
            youtubeUrl: this.youtubeUrl,
            description: this.description,
        }
    }
}
