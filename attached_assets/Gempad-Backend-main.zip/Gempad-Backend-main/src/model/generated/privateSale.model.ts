import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import * as marshal from "./marshal"
import {PrivateSaleTemp} from "./privateSaleTemp.model"

@Entity_()
export class PrivateSale {
    constructor(props?: Partial<PrivateSale>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Column_("text", {nullable: false})
    name!: string

    @Column_("text", {nullable: false})
    owner!: string

    @Column_("text", {nullable: false})
    contractAddress!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    softcap!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    hardcap!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    minBuyLimit!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    maxBuyLimit!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    startTime!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    endTime!: bigint

    @Column_("bool", {nullable: false})
    isCancelled!: boolean

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    finalizeTime!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    publicSaleTime!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    initialRelease!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    cycleInterval!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    cyclePercent!: bigint

    @Column_("int4", {nullable: false})
    isWhitelist!: number

    @Column_("text", {nullable: false})
    currency!: string

    @Column_("text", {nullable: false})
    tokenSymbol!: string

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    depositedAmount!: bigint

    @Column_("text", {array: true, nullable: false})
    investors!: (string | undefined | null)[]

    @Column_("text", {array: true, nullable: false})
    whitelistUsers!: (string | undefined | null)[]

    @Index_()
    @ManyToOne_(() => PrivateSaleTemp, {nullable: true})
    metadata!: PrivateSaleTemp | undefined | null

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null
}
