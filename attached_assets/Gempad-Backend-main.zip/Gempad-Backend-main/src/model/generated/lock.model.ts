import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_, OneToMany as OneToMany_} from "typeorm"
import * as marshal from "./marshal"
import {User} from "./user.model"
import {Token} from "./token.model"
import {LockStatus} from "./_lockStatus"
import {Transaction} from "./transaction.model"

@Entity_()
export class Lock {
    constructor(props?: Partial<Lock>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Index_()
    @ManyToOne_(() => User, {nullable: true})
    owner!: User

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token!: Token

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    amount!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    unlockedAmount!: bigint

    @Column_("timestamp with time zone", {nullable: false})
    unlockDate!: Date

    @Column_("timestamp with time zone", {nullable: false})
    depositDate!: Date

    @Column_("varchar", {length: 9, nullable: false})
    status!: LockStatus

    @OneToMany_(() => Transaction, e => e.lock)
    transactions!: Transaction[]

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    tge!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    cycleShare!: bigint | undefined | null

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    interval!: bigint | undefined | null

    @Column_("text", {nullable: true})
    title!: string | undefined | null
}
