export enum Status {
    PENDING = "PENDING",
    ACTIVE = "ACTIVE",
    CANCELLED = "CANCELLED",
    CLOSED = "CLOSED",
}
