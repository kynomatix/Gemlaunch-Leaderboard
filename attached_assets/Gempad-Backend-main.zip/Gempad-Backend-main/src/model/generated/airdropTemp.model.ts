import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_} from "typeorm"
import * as marshal from "./marshal"
import {Socials} from "./_socials"

@Entity_()
export class AirdropTemp {
    constructor(props?: Partial<AirdropTemp>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("jsonb", {transformer: {to: obj => obj.toJSON(), from: obj => obj == null ? undefined : new Socials(undefined, obj)}, nullable: false})
    socials!: Socials

    @Column_("text", {nullable: true})
    contractAddress!: string | undefined | null
}
