import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import * as marshal from "./marshal"
import {User} from "./user.model"
import {Token} from "./token.model"
import {Status} from "./_status"
import {Allocation} from "./_allocation"
import {AirdropTemp} from "./airdropTemp.model"

@Entity_()
export class Airdrop {
    constructor(props?: Partial<Airdrop>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("int4", {nullable: false})
    chainId!: number

    @Index_()
    @ManyToOne_(() => User, {nullable: true})
    owner!: User

    @Index_()
    @ManyToOne_(() => Token, {nullable: true})
    token!: Token

    @Column_("text", {nullable: false})
    name!: string

    @Column_("varchar", {length: 9, nullable: false})
    status!: Status

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    tge!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    cycle!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    interval!: bigint

    @Column_("bool", {nullable: false})
    isVesting!: boolean

    @Column_("bool", {nullable: false})
    isCancelled!: boolean

    @Column_("bool", {nullable: false})
    isEnded!: boolean

    @Column_("text", {nullable: false})
    contractAddress!: string

    @Column_("jsonb", {transformer: {to: obj => obj.map((val: any) => val == null ? undefined : val.toJSON()), from: obj => obj == null ? undefined : marshal.fromList(obj, val => val == null ? undefined : new Allocation(undefined, val))}, nullable: false})
    allocations!: (Allocation | undefined | null)[]

    @Column_("text", {array: true, nullable: false})
    allocatedUsers!: (string | undefined | null)[]

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: false})
    totalTokens!: bigint

    @Column_("numeric", {transformer: marshal.bigintTransformer, nullable: true})
    startTime!: bigint | undefined | null

    @Column_("timestamp with time zone", {nullable: false})
    createdAt!: Date

    @Column_("timestamp with time zone", {nullable: true})
    updatedAt!: Date | undefined | null

    @Index_()
    @ManyToOne_(() => AirdropTemp, {nullable: true})
    metadata!: AirdropTemp | undefined | null
}
