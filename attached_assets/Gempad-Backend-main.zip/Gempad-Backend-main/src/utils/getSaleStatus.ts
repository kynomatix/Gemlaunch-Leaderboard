// import moment from "moment";
// // import { SaleStatus } from "./constant";

// import { SaleStatus } from "../constants";

// export const getSaleStatus = (
//   startTime: number,
//   endTime: number
// ): SaleStatus => {
//   const currentTimestamp = moment().unix();

//   if (currentTimestamp < startTime) {
//     return {
//       status: LaunchPadStatus.Upcomming,
//       isSaleActive: false,
//       isSaleEnd: false,
//       isUpcoming: true,
//     };
//   }
//   if (currentTimestamp >= startTime && currentTimestamp <= endTime) {
//     return {
//       status: LaunchPadStatus.Live,
//       isSaleActive: true,
//       isSaleEnd: false,
//       isUpcoming: false,
//     };
//   }
//   return {
//     status: LaunchPadStatus.End,
//     isSaleActive: false,
//     isSaleEnd: true,
//     isUpcoming: false,
//   };
// };
