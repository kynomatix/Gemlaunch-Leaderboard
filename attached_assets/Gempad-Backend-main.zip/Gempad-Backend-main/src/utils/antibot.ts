import { Antibot } from "../model";
import { EntityManager } from "./entityManager";

interface Item {
  id: string;
  users: string[];
  status: boolean;
}

export const addToBlacklist = async (item: Item, em: EntityManager) => {
  const { id, users: newUsers } = item;
  let antibot = await em.get(Antibot, id);
  console.log({ newUsers });
  if (!antibot) {
    const ab = new Antibot({
      id,
      blacklist: Array.from(new Set([...newUsers])),
      whitelist: [],
    });

    em.add(ab);
  }

  if (antibot) {
    antibot = new Antibot({
      ...antibot,
      blacklist: Array.from(
        new Set([...(antibot.blacklist as string[]), ...newUsers])
      ),
    });

    em.add(antibot);
  }
};

export const addToWhitelist = async (item: Item, em: EntityManager) => {
  const { id, users: newUsers } = item;
  let antibot = await em.get(Antibot, id);

  if (!antibot) {
    // ab = antibot
    const ab = new Antibot({
      id,
      whitelist: Array.from(new Set([...newUsers])),
      blacklist: [],
    });

    em.add(ab);
  }

  if (antibot) {
    antibot = new Antibot({
      ...antibot,
      whitelist: Array.from(
        new Set([...(antibot.whitelist as string[]), ...newUsers])
      ),
    });

    em.add(antibot);
  }
};

export const removeFromBlacklist = async (item: Item, em: EntityManager) => {
  const { users: usersToRemove, id } = item;
  let antibot = await em.get(Antibot, id);

  if (!antibot) {
    return;
  }

  const { blacklist: oldUsers } = antibot;
  const newUsers = oldUsers?.filter(
    (user) => user && !usersToRemove.includes(user)
  );
  if (newUsers?.length === oldUsers?.length) {
    return; // None of the specified users were found in the blacklist
  }

  antibot = new Antibot({
    ...antibot,
    blacklist: newUsers,
  });

  em.add(antibot);
  return;
};

export const removeFromWhitelist = async (item: Item, em: EntityManager) => {
  const { users: usersToRemove, id } = item;
  let antibot = await em.get(Antibot, id);

  if (!antibot) {
    return;
  }

  const { whitelist: oldUsers } = antibot;
  const newUsers = oldUsers?.filter(
    (user) => user && !usersToRemove.includes(user)
  );
  if (newUsers?.length === oldUsers?.length) {
    return; // None of the specified users were found in the whitelist
  }

  antibot = new Antibot({
    ...antibot,
    whitelist: newUsers,
  });

  em.add(antibot);
  return;
};
