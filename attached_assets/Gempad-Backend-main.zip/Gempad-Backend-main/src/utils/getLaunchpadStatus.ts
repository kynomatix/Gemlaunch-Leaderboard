// interface LaunchpadStatus {
//   isSaleActive: boolean;
//   isSaleEnd: boolean;
//   isUpcoming: boolean;
//   status: LaunchPadStatus;
// }
// export default function launchpadStatusCheck(startTime: bigint, endTime: bigint): LaunchpadStatus {
//   const sTime = Number(startTime)
//   const eTime = Number(endTime)
//   const { isSaleActive, isSaleEnd, isUpcoming, status } = getSaleStatus(sTime, eTime)

//   return {
//     isSaleActive, isSaleEnd, isUpcoming, status
//   }
// }
