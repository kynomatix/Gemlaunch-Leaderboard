import { Aggregation, Claimer, Token } from "../model";
import { CoinFullInfo } from "coingecko-api-v3";
import { nanoid } from "nanoid";
import { coinGeckoClient } from "../common/CoinGeckoClient";
import { CHAIN_ID, MULTICALL_ADDRESS } from "../constants";
import * as ERC20 from "../abi/erc20";
import * as ERC20NameBytes from "../abi/erc20-name-bytes";
import * as ERC20SymbolBytes from "../abi/erc20-symbol-bytes";
import * as UniswapV2Pair from "../abi/uniswap-v2-pair";
import { cal, removeNullBytes, toBigInt } from ".";
import { BlockContext } from "../abi/abi.support";
import { Multicall } from "../abi/multicall";
import { StaticTokenDefinition } from "./staticTokenDefination";
import { EntityManager } from "./entityManager";
import { formatUnits } from "ethers";

export async function fetchTokensSymbol(
  ctx: BlockContext,
  tokenAddresses: string[]
): Promise<Map<string, string>> {
  const multicall = new Multicall(ctx, MULTICALL_ADDRESS);

  const symbols = new Map<string, string>();

  const results = await multicall.tryAggregate(
    ERC20.functions.symbol,
    tokenAddresses.map((a) => [a, []])
  );

  results.forEach((res, i) => {
    const address = tokenAddresses[i];
    let sym: string | undefined;
    if (res.success) {
      sym = res.value;
    } else if (res.returnData) {
      ERC20.functions.symbol.decode(res.returnData);
      sym = ERC20SymbolBytes.functions.symbol.tryDecodeResult(res.returnData);
    }
    if (sym) {
      symbols.set(address, removeNullBytes(sym));
    } else {
      const value = StaticTokenDefinition.fromAddress(address)?.symbol;
      if (value == null) console.warn(`Missing symbol for token ${address}`);
      symbols.set(address, value || "unknown");
    }
  });

  return symbols;
}

export async function fetchTokensName(
  ctx: BlockContext,
  tokenAddresses: string[]
): Promise<Map<string, string>> {
  const multicall = new Multicall(ctx, MULTICALL_ADDRESS);

  const names = new Map<string, string>();

  const results = await multicall.tryAggregate(
    ERC20.functions.name,
    tokenAddresses.map((a) => [a, []])
  );

  results.forEach((res, i) => {
    const address = tokenAddresses[i];
    let name: string | undefined;
    if (res.success) {
      name = res.value;
    } else if (res.returnData) {
      name = ERC20NameBytes.functions.name.tryDecodeResult(res.returnData);
    }
    if (name) {
      names.set(address, removeNullBytes(name));
    } else {
      const value = StaticTokenDefinition.fromAddress(address)?.name;
      if (value == null) console.warn(`Missing name for token ${address}`);
      names.set(address, value || "unknown");
    }
  });

  return names;
}

export async function fetchTokensDecimals(
  ctx: BlockContext,
  tokenAddresses: string[]
): Promise<Map<string, number>> {
  let multicall = new Multicall(ctx, MULTICALL_ADDRESS);

  let results = await multicall.tryAggregate(
    ERC20.functions.decimals,
    tokenAddresses.map((a) => [a, []])
  );

  return new Map(
    results.map((res, i) => {
      let address = tokenAddresses[i];
      let decimals = res.success ? res.value : 0;
      return [address, decimals];
    })
  );
}

export async function fetchTokensTotalSupply(
  ctx: BlockContext,
  tokenAddresses: string[]
): Promise<Map<string, bigint>> {
  let multicall = new Multicall(ctx, MULTICALL_ADDRESS);

  let results = await multicall.tryAggregate(
    ERC20.functions.totalSupply,
    tokenAddresses.map((a) => [a, []])
  );

  return new Map(
    results.map((res, i) => {
      let address = tokenAddresses[i];
      let supply = res.success ? res.value : 0n;
      return [address, supply];
    })
  );
}

export async function fetchTokensPair(
  ctx: BlockContext,
  tokenAddresses: string[]
) {
  const results = await Promise.all(
    tokenAddresses.map((tokenAddress) => getTokenPairs(ctx, tokenAddress))
  );

  return new Map(
    results.map((res, i) => {
      let address = tokenAddresses[i];
      return [address, res];
    })
  );
}

export async function fetchTokensCoinInfo(
  ctx: BlockContext,
  tokenAddresses: string[]
) {
  const results: CoinFullInfo[] = await Promise.all(
    tokenAddresses.map((tokenAddress) => {
      return coinGeckoClient
        .contract({
          id: "fantom-testnet" as any,
          contract_address: tokenAddress,
        })
        .then((x: any) => ({ ...x, id: tokenAddress }))
        .catch(() => ({}));
    })
  );

  return new Map(
    results.map((res, i) => {
      let address = res.id;

      return [
        address,
        {
          rank: res.coingecko_rank,
          image: res.image?.large,
          usdPrice: res.market_data?.current_price?.["usd"],
        },
      ];
    })
  );
}

async function getTokenPairs(
  ctx: BlockContext,
  tokenAddress: string
): Promise<{
  token0: string;
  token1: string;
  reserve0: bigint;
  reserve1: bigint;
}> {
  const contract = new UniswapV2Pair.Contract(ctx, tokenAddress.toLowerCase());

  const [token0Address, token1Address, reserves] = await Promise.all([
    contract.token0(),
    contract.token1(),
    contract.getReserves(),
  ]);

  return {
    token0: token0Address.toLowerCase(),
    token1: token1Address.toLowerCase(),
    reserve0: reserves._reserve0,
    reserve1: reserves._reserve1,
  };
}

export const updateTokenPairCounts = (
  tokenLocked: number,
  token: Token,
  opr: "+" | "-",
  em: EntityManager
): void => {
  if (token.isLiquidityToken) {
    const totalSupply = Number(formatUnits(token.totalSupply, token.decimals));
    const tokenLockedRatio = tokenLocked / totalSupply;
    const liquidityLockedInPercent = Number(
      (tokenLockedRatio * 100).toFixed(2)
    );
    let token0 = em.get(Token, token.token0!.id, false)!;
    let token1 = em.get(Token, token.token1!.id, false)!;

    /* token 0 */
    const reserve0 = Number(formatUnits(token.reserve0!, token0.decimals));
    const token0TokenLocked = cal(
      token0.tokenLocked,
      tokenLockedRatio * reserve0,
      opr
    );

    token0 = new Token({
      ...token0,
      tokenLocked: token0TokenLocked,
      tokenLockedInUsd: token0TokenLocked * token0.usdPrice,
      // liquidityLockedInPercent,
    });

    em.add(token0);

    /* token 1 */
    const reserve1 = Number(formatUnits(token.reserve1!, token1.decimals));
    const token1TokenLocked = cal(
      token1.tokenLocked,
      tokenLockedRatio * reserve1,
      opr
    );

    token1 = new Token({
      ...token1,
      tokenLocked: token1TokenLocked,
      tokenLockedInUsd: token1TokenLocked * token1.usdPrice,
      // liquidityLockedInPercent,
    });

    em.add(token1);

    let aggregation = em.get(Aggregation, "1", false)!;
    const liquidityLocked = token0TokenLocked + token1TokenLocked;
    const aggrLiquidityLocked = cal(
      aggregation.liquidityLocked,
      liquidityLocked,
      opr
    );

    const liquidityLockedInUsd =
      token0TokenLocked * token0.usdPrice + token1TokenLocked * token1.usdPrice;
    const aggrLiquidityLockedInUsd = cal(
      aggregation.liquidityLockedInUsd,
      liquidityLockedInUsd,
      opr
    );

    aggregation = new Aggregation({
      ...aggregation,
      liquidityLocked: aggrLiquidityLocked,
      liquidityLockedInUsd: aggrLiquidityLockedInUsd,
    });

    em.add(aggregation);
  }
};

export const getLpToken = async (
  id: string,
  em: EntityManager,
  ctx: any
): Promise<Token | undefined> => {
  let token = [...em.values(Token)].find((x) =>
    [x.token0?.id, x.token1?.id].includes(id)
  );

  if (!token) {
    token = await ctx.store.findOne(Token, {
      where: [{ token0: { id } }, { token1: { id } }],
    });
  }

  return token;
};

// export function createToken() {
//  return  new Token({
//   id: nanoid(),
//   name,
//   tokenAddress: tokenAddress.toLowerCase(),
//   symbol,
//   chainId: CHAIN_ID,
//   decimals,
//   totalSupply,
//   circulatingSupply: coinFullInfo.market_data?.circulating_supply || 0,
//   rank: coinFullInfo.coingecko_rank,
//   image: coinFullInfo.image?.large,
//   usdPrice: coinFullInfo.market_data?.current_price?.["usd"] || 0,
//   token0,
//   token1,
//   reserve0,
//   reserve1,
//   isLiquidityToken: Boolean(token0),
//   tokenLockedCount: 0,
//   tokenLocked: 0,
//   tokenLockedInUsd: 0,
//   liquidityLockedInPercent: 0,
//   createdAt: new Date(),
// });
// }
