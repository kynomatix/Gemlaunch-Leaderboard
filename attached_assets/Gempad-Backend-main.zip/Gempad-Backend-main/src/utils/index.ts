import { BigNumberish } from "ethers";
// import { Range } from "@subsquid/util-internal-processor-tools";
import assert from "assert";
import { Range } from "./interfaces/interfaces";

// implement this function to convert a BigNumber to a bigint with the specified number of decimals
// export function toBigIntWithDecimals(amount: BigNumberish, decimals: number): bigint {
//   return BigInt(formatUnits(amount, decimals));
// }

export function BigNumberToDate(value: BigNumberish) {
  return new Date(Number(toBigInt(value).toString().slice(0, 10)) * 1000);
}

export function smallestRange(ranges: { [key: string]: Range }) {
  return Math.min(...Object.values(ranges).flatMap(Object.values));
}

export const toBigInt = (value: BigNumberish) => BigInt(value);

export function removeNullBytes(str: string): string {
  return str.replace(/\0/g, "");
}

export function cal(
  num1: number,
  num2: number,
  opr: "+" | "-" | "*" | "/"
): number {
  if (opr === "+") return num1 + num2;
  if (opr === "-") return num1 - num2;
  if (opr === "*") return num1 * num2;
  if (opr === "/") return num1 / num2;

  throw new Error('Invalid operator. Please use "+" or "-".');
}

// export function last<T>(array: T[]): T {
//   assert(array.length > 0);
//   return array[array.length - 1];
// }

// export function* chunk<T>(list: T[], maxBatchSize: number): Generator<T[]> {
//   if (list.length <= maxBatchSize) {
//     yield list;
//   } else {
//     let offset = 0;
//     while (list.length - offset > maxBatchSize) {
//       yield list.slice(offset, offset + maxBatchSize);
//       offset += maxBatchSize;
//     }
//     yield list.slice(offset);
//   }
// }
