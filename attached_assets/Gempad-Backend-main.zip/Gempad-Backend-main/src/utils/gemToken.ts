import { Transaction, assertNotNull } from "@subsquid/evm-processor";
import { CHAIN_ID } from "../constants";
import { GemlaunchToken, User } from "../model";
import { GemlaunchTokenCreatedData } from "../types";
import { EntityManager } from "./entityManager";
import {
  fetchTokensCoinInfo,
  fetchTokensDecimals,
  fetchTokensName,
  fetchTokensSymbol,
  fetchTokensTotalSupply,
} from "./token";
import { BlockContext } from "../abi/abi.support";

export const handleGemTokenCreation = async (
  item: GemlaunchTokenCreatedData["item"],
  tx: Transaction,
  em: EntityManager,
  blockCtx: BlockContext
) => {
  const { owner, token, tokenType } = item;

  const user = em.get(User, owner, false);

  const gemToken = new GemlaunchToken({
    chainId: CHAIN_ID,
    createdAt: new Date(tx.block.timestamp),
    id: token,
    owner: user,
    tokenType,
    image: "",
    name: "",
    symbol: "",
    decimals: 0,
    totalSupply: 0n,
  });

  em.add(gemToken);

  const tokens = em.values(GemlaunchToken);
  await syncGemTokens(tokens, blockCtx);
};

const syncGemTokens = async (
  tokens: GemlaunchToken[],
  blockCtx: BlockContext
): Promise<void> => {
  const ids = tokens.map((t) => t.id);

  const [symbols, names, totalSupplies, decimals, coinInfos] =
    await Promise.all([
      fetchTokensSymbol(blockCtx, ids),
      fetchTokensName(blockCtx, ids),
      fetchTokensTotalSupply(blockCtx, ids),
      fetchTokensDecimals(blockCtx, ids),
      fetchTokensCoinInfo(blockCtx, ids),
    ]);

  for (const token of tokens) {
    token.symbol = assertNotNull(symbols.get(token.id));
    token.name = assertNotNull(names.get(token.id));
    token.totalSupply = assertNotNull(totalSupplies.get(token.id));
    token.decimals = assertNotNull(decimals.get(token.id));
    token.image = coinInfos.get(token.id)?.image;
  }
};
