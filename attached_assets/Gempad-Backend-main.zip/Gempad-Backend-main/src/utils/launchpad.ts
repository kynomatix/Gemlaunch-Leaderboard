import { assertNotNull, DataHandlerContext } from "@subsquid/evm-processor";
import {
  BaseEventData,
  DutchCreationData,
  FairlaunchCreationData,
  LaunchpadCreationData,
  PoolCancelledLaunchpads,
  PoolFinalizedLaunchpads,
  SubscriptionCreationData,
  TokenPurchasedDutch,
  TokenPurchasedFairlaunch,
  TokenPurchasedLaunchpad,
  TokenPurchasedSubscription,
} from "../types";
import { EntityManager } from "./entityManager";
import { Store } from "@subsquid/typeorm-store";
import {
  Aggregation,
  FundToken,
  LaunchPad,
  LaunchpadTemp,
  LiquidityDetails,
  Socials,
  Token,
  User,
  VestingDetails,
} from "../model";
import { CustomRepositoryCannotInheritRepositoryError } from "typeorm";
import { CHAIN_ID, FUND_TOKEN, FundTokenCurrency } from "../constants";
import { fetchEthPrice } from "./fetchCurrencyPrice";
import { ZeroAddress } from "ethers";
import { BlockContext } from "../abi/abi.support";
import {
  fetchTokensDecimals,
  fetchTokensName,
  fetchTokensSymbol,
} from "./token";
import * as ERC20 from "../abi/erc20";

const NATIVE_FUND_TOKENS: Record<number, { name: string; symbol: string }> = {
  [97]: { name: "BNB Coin", symbol: "BNB" },
}; // TODO: add multiple chains

export async function handleCreateLaunchpad(
  item:
    | LaunchpadCreationData["item"]
    | FairlaunchCreationData["item"]
    | DutchCreationData["item"]
    | SubscriptionCreationData["item"],
  tx: BaseEventData["transaction"],
  em: EntityManager,
  ctx: DataHandlerContext<Store>,
  blockCtx: BlockContext
) {
  switch (item.name) {
    case "LaunchPad":
      await handleLaunchpad(
        item as LaunchpadCreationData["item"],
        em,
        tx,
        ctx,
        blockCtx
      );
      break;

    case "Fairlaunch":
      await handleFairlaunch(
        item as FairlaunchCreationData["item"],
        em,
        tx,
        ctx,
        blockCtx
      );
      break;

    case "SubscriptionPool":
      await handleSubscriptionPool(
        item as SubscriptionCreationData["item"],
        em,
        tx,
        ctx,
        blockCtx
      );
      break;

    case "DutchAuction":
      await handleDutchAuction(
        item as DutchCreationData["item"],
        em,
        tx,
        ctx,
        blockCtx
      );
      break;

    default:
      break;
  }
}

export const handleLaunchpad = async (
  data: LaunchpadCreationData["item"],
  em: EntityManager,
  tx: BaseEventData["transaction"],
  ctx: DataHandlerContext<Store>,
  blockCtx: BlockContext
) => {
  const {
    id,
    name,
    endTime,
    finalizeTime,
    hardCap,
    isAffiliate,
    isAutoListing,
    contractAddress,
    liquidityAdded,
    liquidityPercent,
    listingPrice,
    lockTime,
    locker,
    maxBuyLimit,
    minBuyLimit,
    publicSaleTime,
    router,
    sellPrice,
    softCap,
    startTime,
    owner,
    investors,
    token,
    cycleInterval,
    investedAmount,
    cyclePercent,
    isVestingEnable,
    tgePercent,
    fundTokenAddress,
    isCancelled,
  } = data;

  const user = em.get(User, owner, false);
  const _token = em.get(Token, token, false);
  let launchpadTemp = await em.get(LaunchpadTemp, tx.hash.toString());

  if (!launchpadTemp) {
    const socials = new Socials({
      description: undefined,
      facebookUrl: undefined,
      githubUrl: undefined,
      logoUrl: "",
      redditUrl: undefined,
      telegramUrl: undefined,
      twitterUrl: undefined,
      webUrl: "",
      youtubeUrl: undefined,
    });

    launchpadTemp = new LaunchpadTemp({
      audit: "",
      contractAddress,
      id: tx.hash.toString(),
      kyc: "",
      socials: socials,
    });
  } else {
    launchpadTemp = new LaunchpadTemp({
      ...launchpadTemp,
      contractAddress,
    });
  }

  const liquidityDetails = new LiquidityDetails({
    id: contractAddress,
    liquidityAdded,
    liquidityPercent,
    lockTime,
    locker,
    router,
  });

  const vestingDetails = new VestingDetails({
    id,
    cycleInterval,
    cyclePercent,
    isVestingEnable,
    tgePercent,
  });

  const fundToken = new FundToken({
    id: fundTokenAddress,
    isNative: fundTokenAddress.toLowerCase() === ZeroAddress.toLowerCase(),
    name: NATIVE_FUND_TOKENS[CHAIN_ID].name,
    symbol: NATIVE_FUND_TOKENS[CHAIN_ID].symbol,
    decimals: 18,
  });

  em.add(fundToken);

  const tokens = em.values(FundToken).filter((x) => x.id !== ZeroAddress);
  await syncFundTokens(tokens, blockCtx);

  Promise.all([
    ctx.store.save(launchpadTemp),
    ctx.store.save(liquidityDetails),
    ctx.store.save(vestingDetails),
    ctx.store.save(fundToken),
  ]);

  const launchpadData = new LaunchPad({
    id,
    name,
    chainId: CHAIN_ID,
    token: _token,
    createdAt: new Date(tx.block.timestamp),
    startTime,
    endTime,
    isCancelled,
    finalizeTime,
    hardCap,
    isAffiliate,
    isAutoListing,
    contractAddress,
    investedAmount,
    liquidityDetails,
    listingPrice,
    investors,
    fundToken,
    maxBuyLimit,
    minBuyLimit,
    publicSaleTime,
    sellPrice,
    softCap,
    listingTime: 0n,
    vestingDetails,
    metadata: launchpadTemp,
    owner: user,
  });

  console.log("Launchpad created: ", tx.block.height);
  em.add(launchpadData);
};

export const handleFairlaunch = async (
  data: FairlaunchCreationData["item"],
  em: EntityManager,
  tx: BaseEventData["transaction"],
  ctx: DataHandlerContext<Store>,
  blockCtx: BlockContext
) => {
  const {
    affiliateReward,
    endTime,
    finalizeTime,
    id,
    isAffiliate,
    isMaxLimit,
    liquidityAdded,
    liquidityPercent,
    lockTime,
    locker,
    router,
    maxBuyLimit,
    publicSaleTime,
    softCap,
    startTime,
    token,
    investors,
    investedAmount,
    totalSellTokens,
    name,
    contractAddress,
    owner,
    fundTokenAddress,
    isCancelled,
  } = data;

  const user = em.get(User, owner, false);
  const _token = em.get(Token, token, false);
  let fairlaunchTemp = await em.get(LaunchpadTemp, tx.hash.toString());

  if (!fairlaunchTemp) {
    const socials = new Socials({
      description: undefined,
      facebookUrl: undefined,
      githubUrl: undefined,
      logoUrl: "",
      redditUrl: undefined,
      telegramUrl: undefined,
      twitterUrl: undefined,
      webUrl: "",
      youtubeUrl: undefined,
    });

    fairlaunchTemp = new LaunchpadTemp({
      audit: "",
      contractAddress,
      id: tx.hash.toString(),
      kyc: "",
      socials: socials,
    });
  } else {
    fairlaunchTemp = new LaunchpadTemp({
      ...fairlaunchTemp,
      contractAddress,
    });
  }

  const liquidityDetails = new LiquidityDetails({
    id: contractAddress,
    liquidityAdded,
    liquidityPercent,
    lockTime,
    locker,
    router,
  });

  const fundToken = new FundToken({
    id: fundTokenAddress,
    isNative: fundTokenAddress.toLowerCase() === ZeroAddress.toLowerCase(),
    name: NATIVE_FUND_TOKENS[CHAIN_ID].name,
    symbol: NATIVE_FUND_TOKENS[CHAIN_ID].symbol,
    decimals: 18,
  });

  em.add(fundToken);

  const tokens = em.values(FundToken).filter((x) => x.id !== ZeroAddress);
  await syncFundTokens(tokens, blockCtx);

  Promise.all([
    ctx.store.save(fairlaunchTemp),
    ctx.store.save(liquidityDetails),
    ctx.store.save(fundToken),
  ]);

  const launchpadData = new LaunchPad({
    id,
    token: _token,
    owner: user,
    name,
    contractAddress,
    affiliateReward,
    startTime,
    endTime,
    isCancelled,
    finalizeTime,
    liquidityDetails,
    fundToken,
    publicSaleTime,
    maxBuyLimit,
    investors,
    investedAmount,
    softCap,
    listingTime: 0n,
    totalSellTokens,
    chainId: CHAIN_ID,
    metadata: fairlaunchTemp,
    isAffiliate: isAffiliate as boolean,
    isMaxLimit: isMaxLimit as boolean,
    createdAt: new Date(tx.block.timestamp),
  });

  console.log("Fairlaunch: ", tx.block.height);
  em.add(launchpadData);
};

export const handleSubscriptionPool = async (
  data: SubscriptionCreationData["item"],
  em: EntityManager,
  tx: BaseEventData["transaction"],
  ctx: DataHandlerContext<Store>,
  blockCtx: BlockContext
) => {
  const {
    contractAddress,
    endTime,
    finalizeTime,
    hardCap,
    id,
    liquidityAdded,
    liquidityPercent,
    investors,
    listingRate,
    lockTime,
    locker,
    name,
    owner,
    publicSaleTime,
    router,
    sellRate,
    investedAmount,
    softCap,
    startTime,
    token,
    userHardCap,
    fundTokenAddress,
    isCancelled,
  } = data;

  const _token = em.get(Token, token, false);
  const user = em.get(User, owner, false);
  let subscriptionTemp = await em.get(LaunchpadTemp, tx.hash.toString());

  if (!subscriptionTemp) {
    const socials = new Socials({
      description: undefined,
      facebookUrl: undefined,
      githubUrl: undefined,
      logoUrl: "",
      redditUrl: undefined,
      telegramUrl: undefined,
      twitterUrl: undefined,
      webUrl: "",
      youtubeUrl: undefined,
    });

    subscriptionTemp = new LaunchpadTemp({
      audit: "",
      contractAddress,
      id: tx.hash.toString(),
      kyc: "",
      socials: socials,
    });
  } else {
    subscriptionTemp = new LaunchpadTemp({
      ...subscriptionTemp,
      contractAddress,
    });
  }

  const liquidityDetails = new LiquidityDetails({
    id: contractAddress,
    liquidityAdded,
    router,
    liquidityPercent,
    lockTime,
    locker,
  });

  const fundToken = new FundToken({
    id: fundTokenAddress,
    isNative: fundTokenAddress.toLowerCase() === ZeroAddress.toLowerCase(),
    name: NATIVE_FUND_TOKENS[CHAIN_ID].name,
    symbol: NATIVE_FUND_TOKENS[CHAIN_ID].symbol,
    decimals: 18,
  });

  em.add(fundToken);
  const tokens = em.values(FundToken).filter((x) => x.id !== ZeroAddress);
  await syncFundTokens(tokens, blockCtx);

  Promise.all([
    ctx.store.save(subscriptionTemp),
    ctx.store.save(liquidityDetails),
    ctx.store.save(fundToken),
  ]);

  const launchpadData = new LaunchPad({
    chainId: CHAIN_ID,
    token: _token,
    owner: user,
    contractAddress,
    startTime,
    endTime,
    isCancelled,
    finalizeTime,
    hardCap,
    id,
    listingRate,
    investors,
    liquidityDetails,
    listingTime: 0n,
    name,
    investedAmount,
    publicSaleTime,
    sellRate,
    softCap,
    fundToken,
    userHardCap,
    metadata: subscriptionTemp,
    createdAt: new Date(tx.block.timestamp),
  });

  console.log("SubscriptionPool: ", tx.block.height);
  em.add(launchpadData);
};

export const handleDutchAuction = async (
  data: DutchCreationData["item"],
  em: EntityManager,
  tx: BaseEventData["transaction"],
  ctx: DataHandlerContext<Store>,
  blockCtx: BlockContext
) => {
  const {
    contractAddress,
    decreaseInterval,
    endPrice,
    endTime,
    finalizeTime,
    hardCap,
    id,
    liquidityAdded,
    liquidityPercent,
    investedAmount,
    lockTime,
    locker,
    router,
    maxBuyLimit,
    minBuyLimit,
    name,
    owner,
    investors,
    publicSaleTime,
    fundTokenAddress,
    softCap,
    startPrice,
    startTime,
    token,
    totalSaleAmount,
    TGEPercent,
    cycleInterval,
    cyclePercent,
    isVestingEnable,
    isCancelled,
  } = data;

  const user = em.get(User, owner, false);
  const _token = em.get(Token, token, false);
  let dutchTemp = await em.get(LaunchpadTemp, tx.hash.toString());

  if (!dutchTemp) {
    const socials = new Socials({
      description: undefined,
      facebookUrl: undefined,
      githubUrl: undefined,
      logoUrl: "",
      redditUrl: undefined,
      telegramUrl: undefined,
      twitterUrl: undefined,
      webUrl: "",
      youtubeUrl: undefined,
    });

    dutchTemp = new LaunchpadTemp({
      audit: "",
      contractAddress,
      id: tx.hash.toString(),
      kyc: "",
      socials: socials,
    });
  } else {
    dutchTemp = new LaunchpadTemp({
      ...dutchTemp,
      contractAddress,
    });
  }

  const liquidityDetails = new LiquidityDetails({
    id: contractAddress,
    liquidityAdded,
    liquidityPercent,
    lockTime,
    locker,
    router,
  });

  const vestingDetails = new VestingDetails({
    id: contractAddress,
    isVestingEnable,
    tgePercent: TGEPercent,
    cyclePercent,
    cycleInterval,
  });

  const fundToken = new FundToken({
    id: fundTokenAddress,
    isNative: fundTokenAddress.toLowerCase() === ZeroAddress.toLowerCase(),
    name: NATIVE_FUND_TOKENS[CHAIN_ID].name,
    symbol: NATIVE_FUND_TOKENS[CHAIN_ID].symbol,
    decimals: 18,
  });

  em.add(fundToken);

  const tokens = em.values(FundToken).filter((x) => x.id !== ZeroAddress);
  await syncFundTokens(tokens, blockCtx);

  Promise.all([
    ctx.store.save(dutchTemp),
    ctx.store.save(liquidityDetails),
    ctx.store.save(vestingDetails),
    ctx.store.save(fundToken),
  ]);

  const launchpadData = new LaunchPad({
    id,
    name,
    token: _token,
    owner: user,
    contractAddress,
    decreaseInterval,
    startTime,
    endPrice,
    isCancelled,
    endTime,
    listingTime: 0n,
    finalizeTime,
    hardCap,
    liquidityDetails,
    maxBuyLimit,
    investors,
    minBuyLimit,
    fundToken,
    investedAmount,
    publicSaleTime,
    softCap,
    startPrice,
    totalSaleAmount,
    chainId: CHAIN_ID,
    metadata: dutchTemp,
    vestingDetails,
    createdAt: new Date(tx.block.timestamp),
  });
  console.log("Dutch Auction: ", tx.block.height);
  em.add(launchpadData);
};

export const handleTokenPurchased = async (
  item:
    | TokenPurchasedLaunchpad["item"]
    | TokenPurchasedFairlaunch["item"]
    | TokenPurchasedDutch["item"]
    | TokenPurchasedSubscription["item"],
  tx: BaseEventData["transaction"],
  em: EntityManager,
  ctx: DataHandlerContext<Store>
) => {
  const { id, owner, currencyAmount } = item;

  // let launchpad = await em.get(LaunchPad, id);
  let launchpad = await ctx.store.findOne(LaunchPad, {
    where: { id },
    relations: { fundToken: true },
  });
  if (!launchpad) return;

  let aggregation = em.get(Aggregation, "1", false)!;

  if (launchpad.investors.length <= 0) {
    aggregation = new Aggregation({
      ...aggregation,
      fundedProjects: aggregation.fundedProjects + 1,
    });
    em.add(aggregation);
  }

  launchpad = new LaunchPad({
    ...launchpad,
    investedAmount: launchpad.investedAmount + currencyAmount,
    investors: Array.from(new Set([...launchpad.investors, owner])),
  });

  em.add(launchpad);

  const address = FUND_TOKEN[CHAIN_ID][launchpad.fundToken.id as `0x${string}`];

  let raisedAmounts = {
    native: 0n,
    usdc: 0n,
    usdt: 0n,
  };
  if (address === FundTokenCurrency.NATIVE) {
    raisedAmounts.native = currencyAmount;
  }
  if (address === FundTokenCurrency.USDC) {
    raisedAmounts.usdc = currencyAmount;
  }
  if (address === FundTokenCurrency.USDT) {
    raisedAmounts.usdt = currencyAmount;
  }

  aggregation = new Aggregation({
    ...aggregation,
    raisedContributionNative:
      aggregation.raisedContributionNative + raisedAmounts.native,
    raisedContributionUSDC:
      aggregation.raisedContributionUSDC + raisedAmounts.usdc,
    raisedContributionUSDT:
      aggregation.raisedContributionUSDT + raisedAmounts.usdt,
    uniqueParticipants: Array.from(
      new Set([...aggregation.uniqueParticipants, owner])
    ),
  });
  em.add(aggregation);
};

export const handlePoolFinalizedLaunchpad = async (
  item: PoolFinalizedLaunchpads["item"],
  tx: BaseEventData["transaction"],
  em: EntityManager,
  ctx: DataHandlerContext<Store>
) => {
  const { id, finalizeTime } = item;

  let launchpad = await em.get(LaunchPad, id);
  if (!launchpad) return;

  launchpad = new LaunchPad({
    ...launchpad,
    finalizeTime,
  });

  em.add(launchpad);
  console.log("Pool Finalzed", launchpad.name, launchpad.finalizeTime);
};

export const handlePoolCancelledLaunchpad = async (
  item: PoolCancelledLaunchpads["item"],
  tx: BaseEventData["transaction"],
  em: EntityManager,
  ctx: DataHandlerContext<Store>
) => {
  const { id } = item;

  let launchpad = await em.get(LaunchPad, id);
  if (!launchpad) return;

  launchpad = new LaunchPad({
    ...launchpad,
    isCancelled: true,
  });

  em.add(launchpad);
  console.log("Pool Cancelled", launchpad.name, launchpad.finalizeTime);
};

const syncFundTokens = async (
  tokens: FundToken[],
  blockCtx: BlockContext
): Promise<void> => {
  const ids = tokens.map((t) => t.id);

  const [symbols, names, decimals] = await Promise.all([
    fetchTokensSymbol(blockCtx, ids),
    fetchTokensName(blockCtx, ids),
    fetchTokensDecimals(blockCtx, ids),
  ]);

  for (const token of tokens) {
    token.symbol = assertNotNull(symbols.get(token.id));
    token.name = assertNotNull(names.get(token.id));
    token.decimals = assertNotNull(decimals.get(token.id));
  }
};
