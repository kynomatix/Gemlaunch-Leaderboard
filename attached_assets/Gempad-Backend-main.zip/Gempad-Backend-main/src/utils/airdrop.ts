import { DataHandlerContext } from "@subsquid/evm-processor";
import { CHAIN_ID } from "../constants";
import {
  Aggregation,
  Airdrop,
  AirdropTemp,
  Allocation,
  Socials,
  Status,
  Token,
  User,
} from "../model";
import {
  AirdropAddParticipantsData,
  AirdropAllocationsRemovedData,
  AirdropCancelledData,
  AirdropCreationData,
  AirdropStartedData,
  AirdropVestingInfoSetData,
} from "../types";
import { EntityManager } from "./entityManager";
import { Store } from "@subsquid/typeorm-store";

export const startAirdrop = async (
  item: AirdropStartedData["item"],
  em: EntityManager
): Promise<void> => {
  const { id, status, startTime } = item;

  let airdrop = em.get(Airdrop, id, false);
  if (!airdrop) return;

  airdrop = new Airdrop({
    ...airdrop,
    startTime,
  });

  em.add(airdrop);
};

export const addParticipants = async (
  item: AirdropAddParticipantsData["item"],
  em: EntityManager
): Promise<void> => {
  const { id, receivers, tokenAmounts } = item;

  const airdrop = em.get(Airdrop, id, false);
  if (!airdrop) return;

  const oldAllocations = airdrop.allocations as Allocation[];

  const newAllocations: Allocation[] = [];
  const existingAllocationsToUpdate: Allocation[] = [];

  // Separate new allocations into two categories: new and existing
  for (let i = 0; i < receivers.length; i++) {
    const index = oldAllocations.findIndex(
      (allocation) => allocation.user === receivers[i]
    );
    if (index !== -1) {
      // If allocation exists, update its amount
      const updatedAllocation = new Allocation();
      updatedAllocation.user = receivers[i];
      updatedAllocation.amount = tokenAmounts[i];
      existingAllocationsToUpdate.push(updatedAllocation);
    } else {
      // If allocation doesn't exist, add it as new
      const newAllocation = new Allocation();
      newAllocation.user = receivers[i];
      newAllocation.amount = tokenAmounts[i];
      newAllocations.push(newAllocation);
    }
  }

  // Append new allocations and update existing allocations
  const updatedAllocations = [
    ...oldAllocations.filter(
      (allocation) =>
        !existingAllocationsToUpdate.some(
          (updated) => updated.user === allocation.user
        )
    ),
    ...existingAllocationsToUpdate,
    ...newAllocations,
  ];

  const totalAmount = updatedAllocations.reduce(
    (acc, val) => acc + val.amount,
    0n
  );

  const updatedAirdrop = new Airdrop({
    ...airdrop,
    allocations: updatedAllocations,
    allocatedUsers: updatedAllocations.map((x) => x.user),
    totalTokens: totalAmount,
  });

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    totalParticipantsAirdrops:
      aggregation.totalParticipantsAirdrops + newAllocations.length,
  });

  em.add(updatedAirdrop);
  em.add(aggregation);
};

export const removeAllParticipants = async (
  item: AirdropAllocationsRemovedData["item"],
  em: EntityManager
): Promise<void> => {
  const { id, participants } = item;
  let airdrop = em.get(Airdrop, id, false);
  if (!airdrop) return;

  airdrop = new Airdrop({
    ...airdrop,
    allocations: [],
    allocatedUsers: [],
  });

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    totalParticipantsAirdrops:
      aggregation.totalParticipantsAirdrops - participants.length,
  });

  em.add(airdrop);
  em.add(aggregation);
};

export const cancelAirdrop = async (
  item: AirdropCancelledData["item"],
  em: EntityManager
): Promise<void> => {
  const { id, status, timeStamp, tokenBalance } = item;

  let airdrop = await em.get(Airdrop, id);
  if (!airdrop) return;

  airdrop = new Airdrop({
    ...airdrop,
    status: Status.CLOSED,
    totalTokens: tokenBalance,
    isCancelled: true,
    updatedAt: new Date(Number(timeStamp)),
  });

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    totalParticipantsAirdrops:
      aggregation.totalParticipantsAirdrops - airdrop.allocations.length,
  });

  em.add(airdrop);
  em.add(aggregation);
};

export const createAirdrop = async (
  item: AirdropCreationData["item"],
  tx: AirdropCreationData["transaction"],
  em: EntityManager,
  ctx: DataHandlerContext<Store>
): Promise<void> => {
  const {
    id,
    name,
    owner,
    token,
    cycle,
    tge,
    interval,
    isVesting,
    contractAddress,
    status,
  } = item;

  const user = em.get(User, owner, false);
  const _token = em.get(Token, token, false);

  let airdropTemp = await em.get(AirdropTemp, tx.hash.toString());

  if (!airdropTemp) {
    const socials = new Socials({
      description: undefined,
      facebookUrl: undefined,
      githubUrl: undefined,
      logoUrl: "",
      redditUrl: undefined,
      telegramUrl: undefined,
      twitterUrl: undefined,
      webUrl: "",
      youtubeUrl: undefined,
    });

    airdropTemp = new AirdropTemp({
      id: tx.hash.toString(),
      contractAddress,
      socials: socials,
    });
  } else {
    airdropTemp = new AirdropTemp({
      ...airdropTemp,
      contractAddress,
    });
  }

  ctx.store.save(airdropTemp);

  const airdrop = new Airdrop({
    id,
    name,
    cycle,
    tge,
    interval,
    isVesting,
    allocations: [],
    allocatedUsers: [],
    status,
    owner: user,
    token: _token,
    chainId: CHAIN_ID,
    contractAddress: contractAddress.toLowerCase(),
    totalTokens: 0n,
    isCancelled: false,
    isEnded: false,
    startTime: undefined,
    metadata: airdropTemp,
    createdAt: new Date(tx.block.timestamp),
    updatedAt: new Date(),
  });

  em.add(airdrop);
  console.log("New Airdrop Created", airdrop);

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    totalAirdropsLaunched: aggregation.totalAirdropsLaunched + 1,
  });
  em.add(aggregation);
};

export const updateAirdropVestingInfo = async (
  item: AirdropVestingInfoSetData["item"],
  em: EntityManager
): Promise<void> => {
  const { id, cycle, interval, isVesting, tge } = item;

  let airdrop = await em.get(Airdrop, id);
  if (!airdrop) return;

  airdrop = new Airdrop({
    ...airdrop,
    tge,
    cycle,
    interval,
    isVesting,
    updatedAt: new Date(),
  });

  em.add(airdrop);
};
