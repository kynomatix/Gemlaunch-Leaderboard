import { EvmTransaction } from "@subsquid/evm-processor/lib/interfaces/evm";
import { CHAIN_ID, FUND_TOKEN, FundTokenCurrency } from "../constants";
import { Aggregation, PrivateSale, PrivateSaleTemp } from "../model";
import {
  PrivateSaleCancelled,
  PrivateSaleCreationData,
  PrivateSaleFundsDeposited,
  PrivateSaleWhitelistAdded,
  PrivateSaleWhitelistRemoved,
} from "../types";
import { EntityManager } from "./entityManager";

export const handlePrivateSaleCreated = async (
  item: PrivateSaleCreationData["item"],
  tx: PrivateSaleCreationData["transaction"],
  em: EntityManager
): Promise<void> => {
  const {
    cycleInterval,
    cyclePercent,
    endTime,
    finalizeTime,
    hardcap,
    id,
    initialRelease,
    isWhitelist,
    maxBuyLimit,
    minBuyLimit,
    name,
    publicSaleTime,
    softcap,
    startTime,
    status,
    contractAddress,
    currency,
    depositedAmount,
    owner,
    tokenSymbol,
    isCancelled,
  } = item;

  const privateSaleTemp = await em.get(PrivateSaleTemp, tx.hash.toString());

  const privateSale = new PrivateSale({
    id,
    chainId: CHAIN_ID,
    cycleInterval,
    cyclePercent,
    startTime,
    endTime,
    isCancelled,
    owner,
    finalizeTime,
    hardcap,
    contractAddress,
    createdAt: new Date(),
    initialRelease,
    isWhitelist,
    whitelistUsers: [],
    investors: [],
    maxBuyLimit,
    minBuyLimit,
    name,
    publicSaleTime,
    softcap,
    currency,
    tokenSymbol,
    depositedAmount,
    metadata: privateSaleTemp,
  });

  console.log({ privateSale });
  em.add(privateSale);
};

export const handleAddedToWhitelist = (
  item: PrivateSaleWhitelistAdded["item"],
  em: EntityManager
): void => {
  const { users, id } = item;

  let privateSale = em.get(PrivateSale, id, false);
  if (!privateSale) return;

  const { whitelistUsers } = privateSale;
  if (whitelistUsers.length) {
    privateSale = new PrivateSale({
      ...privateSale,
      whitelistUsers: [...whitelistUsers, ...users],
    });
  } else {
    privateSale = new PrivateSale({
      ...privateSale,
      whitelistUsers: users,
    });
  }

  em.add(privateSale);
};

export const handlePrivateSaleCancelled = (
  item: PrivateSaleCancelled["item"],
  em: EntityManager
): void => {
  const { id, status } = item;

  let privateSale = em.get(PrivateSale, id, false);
  if (!privateSale) return;

  privateSale = new PrivateSale({
    ...privateSale,
    isCancelled: true,
  });

  em.add(privateSale);
};

export const handleRemovedFromWhitelist = (
  item: PrivateSaleWhitelistRemoved["item"],
  em: EntityManager
): void => {
  const { users, id } = item;

  let privateSale = em.get(PrivateSale, id, false);
  if (!privateSale) return;

  const { whitelistUsers } = privateSale;
  const updatedWhitelistUsers = whitelistUsers.filter(
    (x) => x && !users.includes(x)
  );

  privateSale = new PrivateSale({
    ...privateSale,
    whitelistUsers: updatedWhitelistUsers,
  });

  em.add(privateSale);
};

export const handleFundsDeposited = (
  item: PrivateSaleFundsDeposited["item"],
  em: EntityManager
): void => {
  const { amount, id, sender } = item;

  let privateSale = em.get(PrivateSale, id, false);
  if (!privateSale) return;

  if (privateSale.investors.length <= 0) {
    let aggregation = em.get(Aggregation, "1", false)!;
    aggregation = new Aggregation({
      ...aggregation,
      fundedProjects: aggregation.fundedProjects + 1,
    });
    em.add(aggregation);
  }

  const address = FUND_TOKEN[CHAIN_ID][privateSale.currency as `0x${string}`];
  let raisedAmounts = {
    native: 0n,
    usdc: 0n,
    usdt: 0n,
  };

  if (address === FundTokenCurrency.NATIVE) {
    raisedAmounts.native = amount;
  }
  if (address === FundTokenCurrency.USDC) {
    raisedAmounts.usdc = amount;
  }
  if (address === FundTokenCurrency.USDT) {
    raisedAmounts.usdt = amount;
  }

  // const { investors } = privateSale;
  // if (investors.includes(sender)) return;

  privateSale = new PrivateSale({
    ...privateSale,
    investors: Array.from(new Set([...privateSale.investors, sender])),
  });

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    raisedContributionNative:
      aggregation.raisedContributionNative + raisedAmounts.native,
    raisedContributionUSDC:
      aggregation.raisedContributionUSDC + raisedAmounts.usdc,
    raisedContributionUSDT:
      aggregation.raisedContributionUSDT + raisedAmounts.usdt,
    uniqueParticipants: Array.from(
      new Set([...aggregation.uniqueParticipants, sender])
    ),
  });
  em.add(aggregation);

  console.log("contribution added by: ", sender);
  em.add(privateSale);
};
