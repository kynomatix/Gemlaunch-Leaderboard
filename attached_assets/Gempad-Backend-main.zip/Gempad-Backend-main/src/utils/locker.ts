import { formatUnits } from "ethers";
import { CHAIN_ID } from "../constants";
import { Aggregation, Lock, LockStatus, LockTemp, Token, User } from "../model";
import {
  LockAddedData,
  LockOwnerChanged,
  LockRemovedData,
  LockUpdatedData,
  VestingLockAdded,
} from "../types";
import { EntityManager } from "./entityManager";
import { updateTokenPairCounts } from "./token";

export const handleLockAdded = async (
  item: LockAddedData["item"],
  tx: LockAddedData["transaction"],
  em: EntityManager
) => {
  const user = em.get(User, item.owner, false)!;
  let token = em.get(Token, item.token, false)!;
  const lockTemp = await em.get(LockTemp, tx.hash.toString());

  const lock = new Lock({
    id: item.id,
    chainId: CHAIN_ID,
    status: LockStatus.Locked,
    owner: user,
    token,
    unlockedAmount: item.unlockedAmount,
    amount: item.amount,
    unlockDate: item.unlockDate,
    depositDate: new Date(tx.block.timestamp),
    createdAt: new Date(tx.block.timestamp),
    title: lockTemp?.title,
  });

  em.add(lock);

  const amountLocked = +formatUnits(lock.amount, token.decimals);
  const tokenLocked = token.tokenLocked + amountLocked;

  token = new Token({
    ...token,
    tokenLockedCount: token.tokenLockedCount + 1,
    tokenLocked: tokenLocked,
    tokenLockedInUsd: tokenLocked * token.usdPrice,
  });

  em.add(token);

  updateTokenPairCounts(tokenLocked, token, "+", em);

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    tokenLockedCount: aggregation.tokenLockedCount + 1,
    tokenLocked: aggregation.tokenLocked + amountLocked,
    tokenLockedInUsd:
      aggregation.tokenLockedInUsd + amountLocked * token.usdPrice,
  });

  em.add(aggregation);
  console.log("Lock Added", item.id);
};

export const handleLockVested = async (
  item: VestingLockAdded["item"],
  tx: VestingLockAdded["transaction"],
  em: EntityManager
) => {
  const user = em.get(User, item.owner, false)!;
  let token = em.get(Token, item.token, false)!;
  const lockTemp = await em.get(LockTemp, tx.hash.toString());

  const lock = new Lock({
    id: item.id,
    chainId: CHAIN_ID,
    status: LockStatus.Locked,
    owner: user,
    token,
    unlockedAmount: item.unlockedAmount,
    amount: item.amount,
    unlockDate: item.unlockDate,
    depositDate: new Date(tx.block.timestamp),
    createdAt: new Date(tx.block.timestamp),
    tge: item.TGE,
    cycleShare: item.cycleShare,
    interval: item.interval,
    title: lockTemp?.title,
  });

  em.add(lock);

  const amountLocked = Number(formatUnits(lock.amount, token.decimals));
  const tokenLocked = token.tokenLocked + amountLocked;

  token = new Token({
    ...token,
    tokenLockedCount: token.tokenLockedCount + 1,
    tokenLocked: tokenLocked,
    tokenLockedInUsd: tokenLocked * token.usdPrice,
  });

  em.add(token);
  console.log("Lock Vested", item.id);
};

export const handleLockOwnerChanged = (
  item: LockOwnerChanged["item"],
  em: EntityManager
) => {
  const user = em.get(User, item.newOwner, false)!;
  let lock = em.get(Lock, item.id, false)!;

  lock = new Lock({
    ...lock,
    owner: user,
    updatedAt: new Date(),
  });
  em.add(lock);
  console.log("Locker owner changed", lock.id);
};

export const handleLockUpdated = (
  item: LockUpdatedData["item"],
  em: EntityManager
) => {
  let token = em.get(Token, item.token, false)!;
  let lock = em.get(Lock, item.id, false)!;

  lock = new Lock({
    ...lock,
    amount: item.newAmount,
    unlockDate: item.newUnlockDate,
    updatedAt: new Date(),
  });

  em.add(lock);

  /****** AGGREGATION ******/

  const amountDiff = Number(item.newAmount - lock.amount);
  const tokenLocked = token.tokenLocked + amountDiff;

  token = new Token({
    ...token,
    tokenLocked,
    tokenLockedInUsd: tokenLocked * token.usdPrice,
  });

  em.add(token);

  updateTokenPairCounts(tokenLocked, token, "+", em);

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    tokenLocked: aggregation.tokenLocked + amountDiff,
    tokenLockedInUsd:
      aggregation.tokenLockedInUsd + amountDiff * token.usdPrice,
  });

  em.add(aggregation);
  console.log("Lock updated", lock.id);
};

export const handleLockRemoved = (
  item: LockRemovedData["item"],
  em: EntityManager
) => {
  let token = em.get(Token, item.token, false)!;
  let lock = em.get(Lock, item.id, false)!;

  lock = new Lock({
    ...lock,
    unlockedAmount: lock.unlockedAmount + item.amount,
    status: LockStatus.Withdrawn,
    updatedAt: new Date(),
  });

  em.add(lock);

  const lockedAmount = Number(formatUnits(lock.amount || 0, token.decimals));

  /****** AGGREGATION ******/

  const tokenLocked = token.tokenLocked - lockedAmount;

  token = new Token({
    ...token,
    tokenLockedCount: token.tokenLockedCount - 1,
    tokenLocked: tokenLocked,
    tokenLockedInUsd: tokenLocked * token.usdPrice,
  });

  em.add(token);

  updateTokenPairCounts(tokenLocked, token, "-", em);

  let aggregation = em.get(Aggregation, "1", false)!;
  aggregation = new Aggregation({
    ...aggregation,
    tokenLockedCount: aggregation.tokenLockedCount - 1,
    tokenLocked: aggregation.tokenLocked - lockedAmount,
    tokenLockedInUsd:
      aggregation.tokenLockedInUsd - lockedAmount * token.usdPrice,
  });

  em.add(aggregation);

  console.log("Lock removed", lock.id);
};
