import {
  AirdropEventData,
  AntibotEventData,
  EventData,
  GemlaunchTokenEventData,
  LaunchPadsEventData,
  LockerEventData,
  PrivateSaleEventData,
} from "../types";

export const extractAirdropEventData = (
  ed: ReadonlyArray<EventData>
): AirdropEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "AirdropCreated":
      case "AirdropCancelled":
      case "AirdropVestingInfoSet":
      case "AirdropAddParticipants":
      case "AirdropStarted":
      case "AirdropTokensClaimed":
      case "AirdropAllocationsRemoved":
        return true;
      default:
        return false;
    }
  }) as AirdropEventData[];
};

export const extractLockerEventData = (
  ed: ReadonlyArray<EventData>
): LockerEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "LockAdded":
      case "LockUpdated":
      case "LockRemoved":
      case "LockTransfer":
      case "LockOwnerChanged":
      case "VestingLockAdded":
        return true;
      default:
        return false;
    }
  }) as LockerEventData[];
};

export const extractPrivateSaleEventData = (
  ed: ReadonlyArray<EventData>
): PrivateSaleEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "PrivateSaleAdded":
      case "PrivateSaleWhitelistAdded":
      case "PrivateSaleWhitelistRemoved":
      case "PrivateSaleFundsDeposited":
      case "PrivateSaleCancelled":
        return true;
      default:
        return false;
    }
  }) as PrivateSaleEventData[];
};

export const extractAntibotEventData = (
  ed: ReadonlyArray<EventData>
): AntibotEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "AddRemoveToBlacklist":
      case "AddRemoveToWhitelist":
        return true;
      default:
        return false;
    }
  }) as AntibotEventData[];
};

export const extractGemlaunchTokenEventData = (
  ed: ReadonlyArray<EventData>
): GemlaunchTokenEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "GemlaunchTokenCreated":
        return true;
      default:
        return false;
    }
  }) as GemlaunchTokenEventData[];
};

export const extractLaunchpadsEventData = (
  ed: ReadonlyArray<EventData>
): LaunchPadsEventData[] => {
  return ed.filter((e) => {
    switch (e.type) {
      case "LaunchpadCreated":
      case "FairlaunchCreated":
      case "DutchAuctionCreated":
      case "SubscriptionPoolCreated":
      case "TokenPurchasedLaunchpad":
      case "TokenPurchasedDutch":
      case "TokenPurchasedFairlaunch":
      case "TokenPurchasedSubscription":
      case "PoolFinalizedLaunchpad":
      case "PoolCancelledLaunchpad":
        return true;
      default:
        return false;
    }
  }) as LaunchPadsEventData[];
};
