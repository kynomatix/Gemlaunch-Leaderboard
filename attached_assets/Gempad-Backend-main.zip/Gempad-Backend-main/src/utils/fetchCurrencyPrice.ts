import axios from "axios";

// Function to fetch Ethereum price from CoinGecko
export const fetchEthPrice = async () => {
  try {
    const response = await axios.get(
      "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd"
    );
    return response.data.ethereum.usd;
  } catch (e: any) {
    console.error("Error fetching Ethereum price:", e?.message);
    return null;
  }
};
