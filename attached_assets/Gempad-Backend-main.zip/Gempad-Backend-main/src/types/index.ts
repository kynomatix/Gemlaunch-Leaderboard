import { KnownArchivesEVM } from "@subsquid/archive-registry";
import { Transaction } from "../processor";
import { LiquidityDetails, Status, VestingDetails } from "../model";
import {
  EvmLog,
  EvmTransaction,
} from "@subsquid/evm-processor/lib/interfaces/evm";
import { BlockData, DataHandlerContext } from "@subsquid/evm-processor";
import { Address } from "cluster";
import { Store } from "@subsquid/typeorm-store";
import { EntityManager } from "../utils/entityManager";

export interface EVM extends EvmLog {
  transaction: Transaction;
}

export enum GemTokenAbi {
  STANDARD,
  LIQUIDITY,
  BABY,
  BUYBACK,
}

export type Archives<T = string> = Partial<Record<KnownArchivesEVM, T>>;

export interface RawClaimer {
  index: number;
  amount: string;
  start: number;
  end: number;
  merkleProof: string[];
  token: string | undefined;
  user: string;
  cadance: number;
  revocable: boolean;
  cliff: number;
  percentageOnStart: number;
}

export interface BaseEventData {
  topic: string;
  transaction: Transaction;
  // block: BlockData<Fields>;
}

export interface LockAddedData extends BaseEventData {
  type: "LockAdded";
  item: {
    id: string;
    token: string;
    owner: string;
    amount: bigint;
    unlockedAmount: bigint;
    isLpToken: boolean;
    unlockDate: Date;
  };
}

export interface LockUpdatedData extends BaseEventData {
  type: "LockUpdated";
  item: {
    id: string;
    owner: string;
    token: string;
    newAmount: bigint;
    newUnlockDate: Date;
  };
}

export interface LockRemovedData extends BaseEventData {
  type: "LockRemoved";
  item: {
    id: string;
    owner: string;
    token: string;
    amount: bigint;
    unlockedAt: Date;
  };
}

export interface LockTransferData extends BaseEventData {
  type: "LockTransfer";
  item: {
    id: string;
    token: string;
    oldOwner: string;
    newOwner: string;
  };
}

export interface VestingLockAdded extends BaseEventData {
  type: "VestingLockAdded";
  item: {
    id: string;
    token: string;
    owner: string;
    amount: bigint;
    isLpToken: boolean;
    TGE: bigint;
    unlockedAmount: bigint;
    cycleShare: bigint;
    interval: bigint;
    unlockDate: Date;
  };
}

export interface LockOwnerChanged extends BaseEventData {
  type: "LockOwnerChanged";
  item: {
    id: string;
    token: string;
    oldOwner: string;
    newOwner: string;
  };
}

export interface AirdropCreationData extends BaseEventData {
  type: "AirdropCreated";
  item: {
    id: string;
    owner: string;
    name: string;
    token: string;
    tge: bigint;
    cycle: bigint;
    interval: bigint;
    isVesting: boolean;
    contractAddress: string;
    status: Status;
    isCancelled: boolean;
    isEnded: boolean;
  };
}

export interface AirdropAddParticipantsData extends BaseEventData {
  type: "AirdropAddParticipants";
  item: {
    id: string;
    receivers: string[];
    tokenAmounts: bigint[];
    token: string;
  };
}

export interface AirdropTokensClaimedData extends BaseEventData {
  type: "AirdropTokensClaimed";
  item: {
    id: string;
    amount: bigint;
    claimTime: bigint;
    token: string;
  };
}

export interface AirdropAllocationsRemovedData extends BaseEventData {
  type: "AirdropAllocationsRemoved";
  item: {
    id: string;
    sender: string;
    participants: string[];
    token: string;
  };
}

export interface AirdropStartedData extends BaseEventData {
  type: "AirdropStarted";
  item: {
    id: string;
    status: number;
    startTime: bigint;
    token: "";
  };
}

export interface AirdropOwnerChangedData extends BaseEventData {
  type: "AirdropOwnerChanged";
  item: {
    id: string;
    oldOwner: string;
    newOwner: string;
    token: string;
  };
}

export interface AirdropVestingInfoSetData extends BaseEventData {
  type: "AirdropVestingInfoSet";
  item: {
    id: string;
    tge: bigint;
    cycle: bigint;
    interval: bigint;
    isVesting: boolean;
    token: string;
  };
}

export interface AirdropCancelledData extends BaseEventData {
  type: "AirdropCancelled";
  item: {
    id: string;
    status: number;
    timeStamp: bigint;
    tokenBalance: bigint;
    token: string;
  };
}

export interface AirdropParticipantsAdded extends BaseEventData {
  type: "AirdropParticipantsAdded";
  item: {
    id: string;
    addresses: string[];
    amounts: bigint[];
    token: string;
  };
}

export interface PrivateSaleCreationData extends BaseEventData {
  type: "PrivateSaleAdded";
  item: {
    id: string;
    name: string;
    owner: string;
    contractAddress: string;
    softcap: bigint;
    hardcap: bigint;
    minBuyLimit: bigint;
    maxBuyLimit: bigint;
    startTime: bigint;
    endTime: bigint;
    isCancelled: boolean;
    finalizeTime: bigint;
    publicSaleTime: bigint;
    initialRelease: bigint;
    cycleInterval: bigint;
    currency: string;
    cyclePercent: bigint;
    isWhitelist: number;
    status: Status;
    depositedAmount: bigint;
    tokenSymbol: string;
  };
}

export interface AntibotAddRemoveToBlacklistData extends BaseEventData {
  type: "AddRemoveToBlacklist";
  item: {
    id: string;
    users: string[];
    status: boolean;
  };
}
export interface AntibotAddRemoveToWhitelistData extends BaseEventData {
  type: "AddRemoveToWhitelist";
  item: {
    id: string;
    users: string[];
    status: boolean;
  };
}

export interface PrivateSaleWhitelistAdded extends BaseEventData {
  type: "PrivateSaleWhitelistAdded";
  item: {
    id: string;
    users: string[];
  };
}
export interface PrivateSaleFundsDeposited extends BaseEventData {
  type: "PrivateSaleFundsDeposited";
  item: {
    id: string;
    sender: string;
    amount: bigint;
  };
}
export interface PrivateSaleCancelled extends BaseEventData {
  type: "PrivateSaleCancelled";
  item: {
    id: string;
    status: number;
  };
}
export interface PrivateSaleWhitelistRemoved extends BaseEventData {
  type: "PrivateSaleWhitelistRemoved";
  item: {
    id: string;
    users: string[];
  };
}

export interface TokenPurchasedLaunchpad extends BaseEventData {
  type: "TokenPurchasedLaunchpad";
  item: {
    name: string;
    id: string;
    owner: string;
    tokenAmount: bigint;
    currencyAmount: bigint;
    token: string;
  };
}
export interface TokenPurchasedDutch extends BaseEventData {
  type: "TokenPurchasedDutch";
  item: {
    name: string;
    id: string;
    owner: string;
    tokenAmount: bigint;
    currencyAmount: bigint;
    token: string;
  };
}
export interface TokenPurchasedFairlaunch extends BaseEventData {
  type: "TokenPurchasedFairlaunch";
  item: {
    name: string;
    id: string;
    owner: string;
    currencyAmount: bigint;
    token: string;
  };
}

export interface TokenPurchasedSubscription extends BaseEventData {
  type: "TokenPurchasedSubscription";
  item: {
    name: string;
    id: string;
    owner: string;
    currencyAmount: bigint;
    token: string;
  };
}
export interface PoolFinalizedLaunchpads extends BaseEventData {
  type: "PoolFinalizedLaunchpad";
  item: {
    name: string;
    id: string;
    status: number;
    finalizeTime: bigint;
    token: string
  };
}

export interface PoolCancelledLaunchpads extends BaseEventData {
  type: "PoolCancelledLaunchpad";
  item: {
    id: string;
    status: number
    token: string;
  }
}

export interface GemlaunchTokenCreatedData extends BaseEventData {
  type: "GemlaunchTokenCreated";
  item: {
    token: string; //token address
    owner: string;
    tokenType: number;
  };
}

// Launchpad Factory
export interface LaunchpadCreationData extends BaseEventData {
  type: "LaunchpadCreated";
  item: {
    id: string;
    name: string;
    owner: string;
    token: string;
    contractAddress: string;
    isAffiliate: boolean;
    isVestingEnable: boolean;
    tgePercent: bigint;
    cyclePercent: bigint;
    cycleInterval: bigint;
    sellPrice: bigint;
    refundType: boolean;
    listingPrice: bigint;
    softCap: bigint;
    hardCap: bigint;
    minBuyLimit: bigint;
    maxBuyLimit: bigint;
    fundTokenAddress: string;
    investors: string[];
    investedAmount: bigint;
    startTime: bigint;
    endTime: bigint;
    isCancelled: boolean;
    finalizeTime: bigint;
    publicSaleTime: bigint;
    router: string;
    liquidityPercent: bigint;
    lockTime: bigint;
    locker: string;
    liquidityAdded: bigint;
    isAutoListing: boolean;
  };
}

export interface FairlaunchCreationData extends BaseEventData {
  type: "FairlaunchCreated";
  item: {
    id: string;
    token: string;
    owner: string;
    name: string;
    contractAddress: string;
    totalSellTokens: bigint;
    softCap: bigint;
    isMaxLimit: Boolean;
    maxBuyLimit: bigint;
    startTime: bigint;
    endTime: bigint;
    isCancelled: boolean;
    investedAmount: bigint;
    fundTokenAddress: string;
    finalizeTime: bigint;
    investors: string[];
    publicSaleTime: bigint;
    isAffiliate: Boolean;
    affiliateReward: bigint;
    router: string;
    liquidityPercent: bigint;
    lockTime: bigint;
    locker: string;
    liquidityAdded: bigint;
  };
}

export interface DutchCreationData extends BaseEventData {
  type: "DutchAuctionCreated";
  item: {
    id: string;
    token: string;
    owner: string;
    name: string;
    contractAddress: string;
    startTime: bigint;
    endTime: bigint;
    isCancelled: boolean;
    startPrice: bigint;
    endPrice: bigint;
    investedAmount: bigint;
    finalizeTime: bigint;
    refundType: boolean;
    maxBuyLimit: bigint;
    publicSaleTime: bigint;
    fundTokenAddress: string;
    softCap: bigint;
    hardCap: bigint;
    minBuyLimit: bigint;
    investors: string[];
    totalSaleAmount: bigint;
    decreaseInterval: bigint;
    router: string;
    liquidityPercent: bigint;
    lockTime: bigint;
    locker: string;
    liquidityAdded: bigint;
    TGEPercent: bigint;
    cycleInterval: bigint;
    cyclePercent: bigint;
    isVestingEnable: boolean;
  };
}

export interface SubscriptionCreationData extends BaseEventData {
  type: "SubscriptionPoolCreated";
  item: {
    id: string;
    token: string;
    owner: string;
    name: string;
    contractAddress: string;
    startTime: bigint;
    endTime: bigint;
    isCancelled: boolean;
    sellRate: bigint;
    softCap: bigint;
    hardCap: bigint;
    fundTokenAddress: string;
    userHardCap: bigint;
    investedAmount: bigint;
    finalizeTime: bigint;
    refundType: boolean;
    investors: string[];
    listingRate: bigint;
    publicSaleTime: bigint;
    liquidityAdded: bigint;
    liquidityPercent: bigint;
    lockTime: bigint;
    locker: string;
    router: string;
  };
}

// Antibot
export type AntibotEventData =
  | AntibotAddRemoveToBlacklistData
  | AntibotAddRemoveToWhitelistData;

// Gelaunch Tokens: Tokens created by gemlaunch
export type GemlaunchTokenEventData = GemlaunchTokenCreatedData;

// privateSales
export type PrivateSaleEventData =
  | PrivateSaleCreationData
  | PrivateSaleWhitelistAdded
  | PrivateSaleWhitelistRemoved
  | PrivateSaleFundsDeposited
  | PrivateSaleCancelled;

// Locker
export type LockerEventData =
  | LockAddedData
  | LockRemovedData
  | LockUpdatedData
  | LockTransferData
  | VestingLockAdded
  | LockOwnerChanged;

// Airdrops
export type AirdropEventData =
  | AirdropCreationData
  | AirdropVestingInfoSetData
  | AirdropCancelledData
  | AirdropAddParticipantsData
  | AirdropStartedData
  | AirdropTokensClaimedData
  | AirdropAllocationsRemovedData;

// Launchpads Factories
export type LaunchPadsEventData =
  | LaunchpadCreationData
  | FairlaunchCreationData
  | DutchCreationData
  | SubscriptionCreationData
  | TokenPurchasedLaunchpad
  | TokenPurchasedFairlaunch
  | TokenPurchasedSubscription
  | TokenPurchasedDutch
  | PoolFinalizedLaunchpads
  | PoolCancelledLaunchpads;

// All
export type EventData =
  | LockerEventData
  | AirdropEventData
  | PrivateSaleEventData
  | AntibotEventData
  | GemlaunchTokenEventData
  | LaunchPadsEventData;

export type ContextWithEntityManager = DataHandlerContext<Store> & {
  em: EntityManager;
};

export interface Ctx extends DataHandlerContext<Store> { }
