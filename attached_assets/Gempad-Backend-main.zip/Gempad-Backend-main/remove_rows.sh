#!/bin/bash
# Set variables for container and database connection
CONTAINER_NAME="gempad-backend-db-1"  # Change this to the name of your PostgreSQL container
DB_NAME="postgres"                   # Change this to your database name
DB_USER="postgres"                   # Change this to your database username
DB_PASSWORD="postgres"               # Change this to your database password
# Tables you want to remove all rows from
TABLES=("private_sale" "squid_processor.status" "squid_processor.hot_block" "squid_processor.hot_change_log")
# Loop through each table and delete all rows
for table in "${TABLES[@]}"
do
    echo "Deleting all rows from table $table..."
    docker exec -it $CONTAINER_NAME psql -U $DB_USER -d $DB_NAME -c "DELETE FROM $table;"
    echo "All rows deleted from table $table."
done
echo "Script execution completed."